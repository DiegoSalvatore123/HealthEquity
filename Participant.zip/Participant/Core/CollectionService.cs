﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class CollectionService : ICollectionService
    {
        private readonly ILogger<CollectionService> _logger;
        private readonly IUnitOfWork _unitOfWork;

        public CollectionService(ILogger<CollectionService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }

        public async Task<HttpResponseMessage> GetStates(InfoModel searchModel)
        {
            try
            {
                List<StateModel>? search = new();
                search = await _unitOfWork.State.GetStates(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get States: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        public async Task<HttpResponseMessage> GetEmployeeClasses(InfoModel searchModel)
        {
            try
            {
                List<EmployeeClassModel>? search = new();
                search = await _unitOfWork.EmployeeClass.GetEmployeeClasses(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Employee classes: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        public async Task<HttpResponseMessage> GetDivisionLocations(InfoModel searchModel)
        {
            try
            {
                List<AffiliateModel>? search = new();
                search = await _unitOfWork.Affiliate.GetDivisionLocations(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get DivisionLocations: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetQualifyingEventType(QualifyingEventTypeModel model)
        {
            try
            {
                List<QeMetaDatas>? qeMetaDatas = await _unitOfWork.QualifyingEventType.GetQualifyingEventType(model);
                QualifyingEventTypeResultModel qualifyingEventTypeResultModel = new()
                {
                    QeMetaDatas = qeMetaDatas,
                    ResponseDateUtc = DateTime.UtcNow
                };
                return Request.CreateResponse(HttpStatusCode.OK, qualifyingEventTypeResultModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get DivisionLocations: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        public List<string> CheckForBadRequest(InfoModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ParticipantId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }

        public List<string> CheckForBadRequest(QualifyingEventTypeModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            if (!Enum.TryParse<QualifyingEventTypeEnum>(model.QualifyingEventType, out var eventType) || !Enum.IsDefined(typeof(QualifyingEventTypeEnum), eventType))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
    }
}

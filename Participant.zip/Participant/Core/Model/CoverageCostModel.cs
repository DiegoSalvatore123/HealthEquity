﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model;

public class CoverageCostModel: PlatformModel
{
    [DataType(DataType.Text)]
    public string PlanId { get; set; } = string.Empty;
    [DataType(DataType.Text)]
    public string CoverageCode { get; set; } = string.Empty;
}
﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class DocumentModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string SecureId { get; set; } = string.Empty;
    }
}

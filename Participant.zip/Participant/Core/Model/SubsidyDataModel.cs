﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SubsidyDataModel
    {
        [Key]
        public int? ErrorCode { get; set; }
        public int? ClientId { get; set; }
        public string? ErrorMsg { get; set; }
    }
}

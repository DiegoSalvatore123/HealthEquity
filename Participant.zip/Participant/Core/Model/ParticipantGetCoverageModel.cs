﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ParticipantGetCoverageModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Sort { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? Status { get; set; } = string.Empty;    
    }
}

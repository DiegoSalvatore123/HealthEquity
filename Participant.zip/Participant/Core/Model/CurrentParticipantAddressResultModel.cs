﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Model
{
    public class CurrentParticipantAddressResultModel
    {
        public CurrentParticipantAddressModel? CurrentParticipantAddressModel { get; set; }
        public List<StateModel>? States { get; set; }
    }
}

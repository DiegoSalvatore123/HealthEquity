﻿namespace Core.Model
{
    public class DependentOldModel
    {
        public string UserId { get; set; } = string.Empty;
        public int ParticipantId { get; set; }
        public string DependentInfo { get; set; } = string.Empty;
    }
}

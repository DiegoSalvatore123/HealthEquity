﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class AddressModel : PlatformModel
    {
        public int ParticipantId { get; set; }
        public int DependentId { get; set; }
        [DataType(DataType.Text)]
        public string Address1 { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? Address2 { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string City { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string State { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Zip { get; set; } = string.Empty;
       // public string UserId { get; set; } = string.Empty;
    }
}

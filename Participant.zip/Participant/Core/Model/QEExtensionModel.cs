﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class QEExtensionModel
    {
        [Key]
        [Column("EXTENSION_LENGTH")]
        public string? ExtensionLength { get; set; }
        [Column("VARIABLE_EXTENSION")]
        public string? VariableExtension { get; set; }
        public string? Extension { get; set; }
    }
}

﻿namespace Core.Model
{
    public class DBPastDueResponseModel
    {
        public int ParticipantID { get; set; }
        public string? FirstName { get; set; } = string.Empty;
        public string? LastName { get; set; } = string.Empty;
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        public string? LabelValue { get; set; } = string.Empty;
        public string? DisplayValue { get; set; } = string.Empty;
        public string? ClientOptionValue { get; set; } = string.Empty;
        public Decimal? Amount { get; set; }
        public Decimal? ErPaid { get; set; }
        public Decimal? Owed { get; set; }
        public Decimal? Paid { get; set; }
        public string? Status { get; set; } = string.Empty;
        public string? EventName { get; set; } = string.Empty;
        public string? AffiliateName { get; set; } = string.Empty;
        public int TotalCount { get; set; }
        public List<DBPastDueResponseDetailModel>? dBPastDueResponseDetailModels { get; set; }
    }
}

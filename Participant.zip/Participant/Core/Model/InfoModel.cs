﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class InfoModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string AffiliateId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string DivisionLevelAccess { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string UserType { get; set; } = string.Empty;
    }
}
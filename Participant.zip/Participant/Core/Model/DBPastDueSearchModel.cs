﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class DBPastDueSearchModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string? DivisionLevelAccess { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? AffiliateString { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PageSize { get; set; } = string.Empty;
        [DataType(DataType.Text)] 
        public string PageNumber { get; set; } = string.Empty;
    }
}

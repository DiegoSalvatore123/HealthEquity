﻿namespace Core.Model
{
    public class AvailablePlansClientResultModel
    {
        public int PlanId { get; set; }
        public string CoverageType { get; set; } = string.Empty;
        public string RateType { get; set; } = string.Empty;
        public int? Pcid { get; set; }
        public string? CoverageCode { get; set; } = string.Empty;
        public string? CoverageRate { get; set; }
        public Boolean Priority { get; set; } = false;
        public string? CoverageBeginDate { get; set; }
        public string? LastDayPreCobra { get; set; }
        public string CoverageName { get; set; } = string.Empty;
        public string PlanName { get; set; } = string.Empty;
        public string? WaitPeriodType { get; set; } = string.Empty;
        public Int16 WaitPeriodQty { get; set; }
        public string? WaitEndsType { get; set; } = string.Empty;
        public string? CoverageEndType { get; set; } = string.Empty;
        public int PlanIsFutureDated { get; set; }
        public Boolean? IsMNLife { get; set; }
        public string? IsLifeInsuranceRTPlan { get; set; } = string.Empty;
        public List<CoverageAvailablePlan>? CoverageAvailablePlan { get; set; }
        public QEPlanComponentModel? QEPlanComponentModel { get; set; }
        public Boolean PlanIsValid { get; set; }
        public string PlanType { get; set; } = string.Empty;
        public string? PlanOption { get; set; } = string.Empty;
        public bool ShowSubsidy { get; set; } = false;
        public string? IsTobaccoRated { get; set; } = string.Empty;
        public bool IsDirectRateEntry { get; set; }
        public string? CoverageAvailablePlanCode { get; set; } = string.Empty;
        public List<CoverageMemberModel>? CoverageMember { get; set; }
        public List<SubsidyPlanModel>? SubsidyPlan { get; set; }
        public string? ParticipantCoverageId { get; set; }
        public bool IsCafePlan { get; set; } = false;
    }
}

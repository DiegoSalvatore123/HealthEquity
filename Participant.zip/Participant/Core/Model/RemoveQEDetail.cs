﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class RemoveQEDetail
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public Int32 ParticipantId { get; set; }
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        [Column("HIRE_DATE")]
        public DateTime? HireDate { get; set; } 
        [Column("PARTICIPANT_TYPE")]
        public string ParticipantType { get; set; } = string.Empty;
        [Column("QUALIFYING_EVENT_DATE")]
        public DateTime? QualifyingEvenDate { get; set; } 
        [Column("FIRST_PAYMENT_DATE")]
        public DateTime? FirstPaymentDate { get; set; }
        public string TextMessage { get; set; } = string.Empty;
    }
}

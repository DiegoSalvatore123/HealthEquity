﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model;

public class ParticipantDependentCoverageResultModel
{
    [Key]
    [Column("PARTICIPANT_ID")]
    public int ParticipantId { get; set; }
    [Column("SOCIAL_SECURITY_NUMBER")]
    public string? SocialSecurityNumber { get; set; }
    [Column("FIRST_NAME")]
    public string? FirstName { get; set; }
    [Column("LAST_NAME")]
    public string? LastName { get; set; }
    [Column("Middle_Initial")]
    public string? MiddleInitial { get; set; }
    [Column("BIRTH_DATE")]
    public DateTime? BirthDate { get; set; }
    [Column("LabelValue")]
    public string? SsnLabelValue { get; set; }
    [Column("DisplayValue")]
    public string? SsnDisplayValue { get; set; }
    [Column("ClientOptionValue")]
    public string? SsnClientOptionValue { get; set; }
    public string? Relationship { get; set; }
    [Column("PARTICIPANT_STATUS")]
    public string? ParticipantStatus { get; set; }
    [Column("QUALIFYING_EVENT_DATE")]
    public DateTime? QualifyingEventDate { get; set; }
    [Column("PARENT_STATUS")]
    public string? ParentStatus { get; set; }
    [Column("RELATIONSHIP_DESC")]
    public string? RelationshipDescription { get; set; }
}
﻿namespace Core.Model
{
    public class DependentNewViewModel
    {
        public int? ParticipantId { get; set; } = 0;
        public int? ParticipantNewId { get; set; } = 0;
        public int? Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string? MiddleInitial { get; set; }
        public string? SocialSecurityNumber { get; set; }
        public string BirthDate { get; set; } = string.Empty;
        public string ParticipantStatus { get; set; } = string.Empty;
        public string QualifiedBeneficiary { get; set; } = string.Empty;
        public string Student { get; set; } = string.Empty;
        public string Relationship { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        public string WaitingStartDate { get; set; } = string.Empty;
        public string CoverageStartDate { get; set; } = string.Empty;
        public string ParticipantType { get; set; } = string.Empty;
        public string GenderDesc { get; set; } = string.Empty;
        public string? RelationshipDesc { get; set; } = string.Empty;
        public string? StudentDesc { get; set; } = string.Empty;
        public string? StatusDesc { get; set; } = string.Empty;
        public string? EmployeeNumber { get; set; } = string.Empty;

    }
}

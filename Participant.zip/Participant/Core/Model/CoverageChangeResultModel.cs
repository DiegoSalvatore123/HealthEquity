﻿namespace Core.Model
{
    public class CoverageChangeResultModel : OperationResultModel
    {
        public List<string>? PlanName { get; set; }
    }
}

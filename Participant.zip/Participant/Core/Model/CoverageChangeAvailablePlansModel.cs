﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CoverageChangeAvailablePlansModel : PlatformModel
    {
        public List<UpdateCoverageChangeModel>? UpdateCoverageChanges { get; set; }
        public List<CoverageChangeModel>? DropCoverageChanges { get; set; }
        public List<NewCoverageChangeModel>? NewCoverageChanges { get; set; }
        [DataType(DataType.Text)]
        public string? Name { get; set; }
        public int ParticipantId { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class EmployeeClassModel
    {
        [Key]
        [Column("EMPLOYEE_CLASS_ID")]
        public int EmployeeClassId { get; set; }

        [Column("CLASS_NAME")]
        public string ClassName { get; set; } = string.Empty;
    }
}

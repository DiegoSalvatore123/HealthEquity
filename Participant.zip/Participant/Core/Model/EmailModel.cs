﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class EmailModel
    {
        [Key]
        [Column("DOC_ID")]
        public Int32 DocId { get; set; } 
        [Column("DESCRIPTION")]
        public string? Description { get; set; } = string.Empty;
        [Column("REQUEUE")]
        public int Requeue { get; set; } 
        [Column("DOC_STATUS")]
        public string? DocStatus { get; set; } = string.Empty;
        [Column("DATE_MAILED")]
        public string? DateMailed { get; set; } = string.Empty;
        [Column("DATE_RETURNED")]
        public string? DateReturned { get; set; } = string.Empty;
    }
}

﻿namespace Core.Model
{
    public class SpecificFieldsModel
    {
        public string? FieldName { get; set; }
        public string? FieldValue { get; set; }
        public bool ShowOnWeb { get; set; }
        public int? CustomFieldId { get; set; }
    }
}

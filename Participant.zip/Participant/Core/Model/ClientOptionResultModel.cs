﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ClientOptionResultModel
    {
        [Key]
        [Column("OPTION_VALUE")]
        public string OptionValue { get; set; } = string.Empty;
    }
}
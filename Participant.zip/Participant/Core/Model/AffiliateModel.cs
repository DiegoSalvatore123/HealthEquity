﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class AffiliateModel
    {
        [Key]
        [Column("AFFILIATE_ID")]
        public int AffiliateId { get; set; }

        [Column("AFFILIATE_NAME")]
        public string AffiliateName { get; set; } = string.Empty;
    }
}

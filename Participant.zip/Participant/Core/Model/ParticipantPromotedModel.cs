﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class ParticipantPromotedModel
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }
        [Column("QUALIFYING_EVENT_TYPE")]
        public string? QualifyngEventType { get; set; } = string.Empty;
    }
}

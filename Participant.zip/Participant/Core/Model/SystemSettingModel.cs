﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class SystemSettingModel
    {
        [Key]
        public string SettingNameId { get; set; } = string.Empty;
        [Column("EXPLANATION")]
        public string? Explanation { get; set; } = string.Empty;
        [Column("SETTING_VALUE")]
        public string? SettingValue { get; set; } = string.Empty;
        [Column("USED_BY")]
        public string? UsedBy { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class GenericUniqueValue
    {
        [Key]
        public string? Value { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("PARTICIPANT_COVERAGE")]
    public class ParticipantCoverageModel
    {
        [Key]
        [Column("PARTICIPANT_COVERAGE_ID")]
        public int ParticipantCoverageId { get; set; }

        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("COVERAGE_STATE")]
        public char CoverageState { get; set; }
    }
}

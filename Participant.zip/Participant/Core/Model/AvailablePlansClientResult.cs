﻿using System.ComponentModel.DataAnnotations.Schema;
namespace Core.Model
{
    public class AvailablePlansClientResult
    {
        [Column("Plan_ID")]
        public int PlanId { get; set; }
        [Column("Coverage_Type")]
        public string CoverageType { get; set; } = string.Empty;
        [Column("Rate_Type")]
        public string RateType { get; set; } = string.Empty;
        [Column("PCID")]
        public int? Pcid { get; set; }
        [Column("CovCode")]
        public string CoverageCode { get; set; } = string.Empty;
        [Column("CovRate")]
        public decimal? CoverageRate { get; set; }
        [Column("Priority")]
        public Boolean Priority { get; set; } = false;
        [Column("CovBeginDate")]
        public DateTime? CoverageBeginDate { get; set; }
        [Column("CovName")]
        public string CoverageName { get; set; } = string.Empty;
        [Column("Plan_Name")]
        public string PlanName { get; set; } = string.Empty;
        [Column("wait_period_type")]
        public string WaitPeriodType { get; set; } = string.Empty;
        [Column("wait_period_qty")]
        public Int16 WaitPeriodQty { get; set; }
        [Column("wait_ends_type")]
        public string WaitEndsType { get; set; } = string.Empty;
        [Column("coverage_end_type")]
        public string CoverageEndType { get; set; } = string.Empty;
        [Column("PlanIsFutureDated")]
        public int PlanIsFutureDated { get; set; }
        [Column("IsMNLife")]
        public Boolean? IsMNLife { get; set; }
    }
}
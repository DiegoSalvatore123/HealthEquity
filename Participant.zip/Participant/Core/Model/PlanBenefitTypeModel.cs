﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class PlanBenefitTypeModel
    {
        [Key]
        [Column("plan_ID")]
        public int PlanId { get; set; }
        [Column("plan_name")]
        public string? PlanName { get; set; }
        [Column("component_plan_id")]
        public int ComponentPlanId { get; set; }
        [Column("rate_type")]
        public string? RateType { get; set; }
        [Column("benefittypesubtypeid")]
        public string? BenefitTypeSubtypeId { get; set; }
    }
}

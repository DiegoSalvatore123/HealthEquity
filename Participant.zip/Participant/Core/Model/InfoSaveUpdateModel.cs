﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class InfoSaveUpdateModel : PlatformModel
    {
        public InfoResultViewModel? ParticipantInfo { get; set; }
        public InfoResultViewModel? ParticipantInfoOld { get; set; }
        public List<SpecificFieldsModel>? SpecificFields { get; set; }
        public List<DependentNewViewModel>? Dependents { get; set; }
        public List<DependentNewViewModel>? DependentsOld { get; set; }
        public List<EmailReSendModel>? Email { get; set; }
        public AddressModel Address { get; set; } = new();
        public List<DocumentOptionModel>? Documents { get; set; }
        [DataType(DataType.Text)]
        public string UserType { get; set; } = String.Empty;
  //      public string? OldEmployeeClassId { get; set; }
    }
}

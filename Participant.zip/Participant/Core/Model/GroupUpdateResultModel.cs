﻿namespace Core.Model;

public class GroupUpdateResultModel
{
    public int? TotalCount { get; set; } = 0;
    public int PageSize { get; set; } = 0;
    public int PageNumber { get; set; } = 0;
    public string? Order { get; set; }
    public string? OrderDirection { get; set; }
    public List<GroupUpdateDropDownListModel>? DropDownList { get; set; } = new();
    public GroupUpdateModel GroupUpdate { get; set; } = new();
    public List<GroupUpdateDataResultModel> GroupUpdateData { get; set; } = new();
}
﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model;

public class ParticipantInfoResultModel
{
    [Column("PARTICIPANT_ID")]
    public int ParticipantId { get; set; }
    [Column("FIRST_NAME")]
    public string FirstName { get; set; } = string.Empty;
    [Column("LAST_NAME")]
    public string LastName { get; set; } = string.Empty;
    [Column("SOCIAL_SECURITY_NUMBER")] 
    public string SSN { get; set; } = string.Empty;
    [Column("LabelValue")]
    public string LabelValue { get; set; } = string.Empty;
    [Column("DisplayValue")]
    public string DisplayValue { get; set; } = string.Empty;
    [Column("ClientOptionValue")]
    public string ClientOptionValue { get; set; } = string.Empty;
    [Column("Option441")]
    public int Option441 { get; set; }
}
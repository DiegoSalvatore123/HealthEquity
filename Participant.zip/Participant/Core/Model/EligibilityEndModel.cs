﻿namespace Core.Model
{
    public class EligibilityEndModel
    {
        public string? EligibilityEnd { get; set; } = string.Empty;
    }
}

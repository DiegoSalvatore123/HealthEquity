﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CurrentParticipantAddressModel
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public int Id { get; set; }
        [Column("ADDRESS_1")]
        public string? Address1 { get; set; }
        [Column("ADDRESS_2")]
        public string? Address2 { get; set; }
        [Column("CITY")]
        public string? City { get; set; }
        [Column("STATE")]
        public string? State { get; set; }
        [Column("ZIP")]
        public string? ZIP { get; set; }

    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
 
namespace Core.Model
{
    public class BillingModel  
    {
        [Column("CovPeriodDesc")]
        public string CovPeriodDesc { get;  set; } = string.Empty;
        [Column("Due_Date")]
        public string DueDate { get;  set; } = string.Empty;
        [Column("Deadline_Date")]
        public string DeadlineDate { get;  set; } = string.Empty;
        [Column("ER_CODE")]
        public string ERCode { get;  set; } = string.Empty;
        [Column("ER_STATUS")]
        public string ERStatus { get;  set; } = string.Empty;
        [Column("EE_Status")]
        public string EEStatus { get;  set; } = string.Empty;
        [Column("EE_Status_Description")]
        public string EEStatusDescription { get;  set; } = string.Empty;
        [Column("Participant_Paid")]
        public string ParticipantPaid { get;  set; } = string.Empty;
        [Column("Participant_Owed")]
        public string ParticipantOwed { get;  set; } = string.Empty;
        [Column("Amount_Due")]
        public string AmountDue { get;  set; } = string.Empty;
        [Column("ER_Sev")]
        public string ERSev { get;  set; } = string.Empty;
        [Column("Fed_Sub")]
        public string FedSub { get;  set; } = string.Empty;
        [Column("ER_Paid")]
        public string ERPaid { get;  set; } = string.Empty;
        [Column("ER_Owed")]
        public string EROwed { get;  set; } = string.Empty;
        [Column("Paid_Total")]
        public string PaidTotal  { get;  set; } = string.Empty;
        [Column("Admin_Fee")]
        public string AdminFee { get;  set; } = string.Empty;
        [Column("Prorated_Premium")]
        public string ProratedPremium { get;  set; } = string.Empty;
        [Column("Monthly_Premium")]
        public string MonthlyPremium { get;  set; } = string.Empty;
        public int TotalCount { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
 
namespace Core.Model
{
    public class CobraHipaaViewModel 
    { 
        [Key]
        public int Cobra { get; set; }
        public int Hipaa { get; set; }
    }
}

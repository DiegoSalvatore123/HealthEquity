﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DocumentOptionModel
    {
        [Key]
        [Column("DOC_ID")]
        public int DocId { get; set; }
        [Column("COUPON_START_DATE")]
        public string? CouponStartDate { get; set; } = string.Empty;
        [Column("OPTION_VALUE")]
        public int OptionValue { get; set; }
        [Column("EVENT_TYPE")]
        public string EventType { get; set; } = string.Empty;
        [Column("FORM_NUMBER")]
        public string FormNumber { get; set; } = string.Empty;
        [Column("RETURNED_MAIL_ID")]
        public int ReturnedMailId { get; set; }
    }
}

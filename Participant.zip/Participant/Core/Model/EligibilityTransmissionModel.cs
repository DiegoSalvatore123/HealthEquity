﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model;
public class EligibilityTransmissionModel
{
    [Column("PARTICIPANT_ID")]
    public int ParticipantId { get; set; }
    [Column("REFERENCE_NUMBER")]
    public int RerefenceNumber { get; set; }
    [Column("SENT_TO")]
    public string SentTo { get; set; } = string.Empty;
    [Column("CONTACT_ID")]
    public int ContactId { get; set; }

    [Column("REPORT_DATA_START")] 
    public string ReportDataStart { get; set; } = string.Empty;
    [Column("DOC_ID")]
    public int DocId { get; set; }
    [Column("DOC_IMAGE_ID")]
    public int DocImageId { get; set; }
    [Column("SEND_DATE")]
    public string SendDate { get; set; } = string.Empty;
    [Column("REPORT_DATA_END")]
    public string ReportDataEnd { get; set; } = string.Empty;
    [Column("PLAN_NAME")]
    public string PlanName { get; set; } = string.Empty;
    [Column("COVERAGE_CODE")]
    public string CoverageCode { get; set; } = string.Empty;
    [Column("COVERAGE_DESCRIPTION")]
    public string CoverageDescription { get; set; } = string.Empty;
    [Column("EFFECTIVE_DATE")]
    public DateTime? EffectiveDate { get; set; }
    [Column("TERMINATION_DATE")]
    public DateTime? TerminationDate { get; set; }
    [Column("PAID_THRU")]
    public DateTime? PaidThru { get; set; }
    [Column("ALLOW_VIEW")]
    public int AllowView { get; set; }
}
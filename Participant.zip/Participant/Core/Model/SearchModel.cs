﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SearchModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string? SSN { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? EmployeeNumber { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? LastName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? FirstName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? HireFrom { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? HireTo { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? Account { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? DocumentId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ImageName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? OptionSearch { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string AffiliateId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? DivisionLevelAccess { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Sort { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PageSize { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PageNumber { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ViewOption { get; set; } = string.Empty;
    }
}
﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
 
namespace Core.Model
{
    public class SearchResultModel  
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public Int32 ParticipantId { get; set; }
        [Column("PARENT_PARTICIPANT_ID")]
        public string? ParentParticipantId { get; set; } = string.Empty;
        [Column("RELATIONSHIP")]
        public string? Relationship { get; set; } = string.Empty;
        [Column("FIRST_PAYMENT_DATE")]
        public DateTime? FirtPaymentDate { get; set; }
        [Column("COBRA_STATUS")]
        public string? CobraStatus { get; set; } = string.Empty;
        [Column("QUALIFYING_EVENT_TYPE")]
        public string? QualifyingEventType { get; set; } = string.Empty;
        [Column("QUALIFYING_EVENT_DATE")]
        public DateTime? QualifyingEventDate { get; set; }
        [Column("FIRST_NAME")]
        public string? FirstName { get; set; } = string.Empty;
        [Column("LAST_NAME")]
        public string? LastName { get; set; } = string.Empty;
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        [Column("HIRE_DATE")]
        public DateTime? HireDate { get; set; }
        [Column("PARTICIPANT_STATUS")]
        public string? ParticipantStatus { get; set; } = string.Empty;
        [Column("FORMER_DEPENDENT_ID")]
        public Int32? FormerDependentId { get; set; }
        [Column("ELIGIBILITY_START_DATE")]
        public DateTime? EligibilityStartDate { get; set; }
        [Column("ELECTION_DATE")]
        public DateTime? ElectionDate { get; set; }
        [Column("BILLING_START_DATE")]
        public DateTime? BillingStartDate { get; set; }
        [Column("AFFILIATE_NAME")]
        public string? AffiliateName { get; set; } = string.Empty;
        [Column("AFFILIATE_ID")]
        public int? AffiliateID { get; set; }
        [Column("Participant_type")]
        public string? ParticipantType { get; set; } = string.Empty;
        public string? LabelValue { get; set; } = string.Empty;
        public string? ClientOptionValue { get; set; } = string.Empty;
        public string? DisplayValue { get; set; } = string.Empty;
        public int YearDifference { get; set; }
        public string? Status { get; set; } = string.Empty;
        public string? StatusDB { get; set; } = string.Empty;
        public string? StatusDescription { get; set; } = string.Empty;
        public string? StatusDescriptionDB { get; set; } = string.Empty;
        public string? HireDateDescription { get; set; } = string.Empty;
        public int TotalCount { get; set; }
        public int AddDB { get; set; }
        //public int IsProcessQE { get; set; }
    }
}

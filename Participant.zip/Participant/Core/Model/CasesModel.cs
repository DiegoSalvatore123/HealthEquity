﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("CASES",Schema = "dbo")]
    public class CasesModel
    {
        [Key]
        [Column("Case_Number")]
        public int CaseNumber { get; set; }  
        
        [Column("Participant_ID")]
        public int ParticipantId { get; set; }

        [Column("CASE_STATUS")]
        public char CaseStatus { get; set; }

        [Column("Closed")]
        public bool Closed { get; set; }
    }
}

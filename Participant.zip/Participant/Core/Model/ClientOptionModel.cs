﻿namespace Core.Model
{
    public class ClientOptionModel : PlatformModel
    {
        public int ClientOptionId { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("BANK_CHECK", Schema ="dbo")]
    public class BankCheck
    {
        [Key]
        [Column("CHECK_ID")]
        public int CheckId { get; set; }

        [Column("BANK_ACCOUNT_ID")]
        public int BankAccountId { get; set; }

        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("CLIENT_ID")]
        public int ClientId { get; set; }

        [Column("CHECK_STATUS")]
        public char Status { get; set; }
    }
}

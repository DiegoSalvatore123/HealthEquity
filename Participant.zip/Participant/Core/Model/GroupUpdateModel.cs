﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model;

public class GroupUpdateModel
{
    [Key]
    [Column("ID_NUMBER")]
    public int IdNumber { get; set; }
    [Column("TABLE_NAME")]
    public string? TableName { get; set; }
    [Column("COLUMN_NAME")]
    public string? ColumnName { get; set; }
    [Column("COLUMN_TYPE")]
    public string? ColumnType { get; set; }
    public int Length { get; set; }
    [Column("LOOP_COUNT")]
    public int LoopCount { get; set; }
    public string? Title { get; set; }
    [Column("ALLOW_NULLS")]
    public bool AllowNulls { get; set; }
    public string? Criteria { get; set; }
    [Column("ORDER_BY")]
    public string? OrderBy { get; set; }
    [Column("UPDATE_TYPE")]
    public string? UpdateType { get; set; }
    [Column("USE_QUOTES")]
    public bool UseQuotes { get; set; }
}

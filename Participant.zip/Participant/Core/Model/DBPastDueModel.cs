﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DBPastDueModel
    {
        [Column("PARTICIPANT_ID")]
        public int ParticipantID { get; set; }
        [Column("FIRST_NAME")]
        public string? FirstName { get; set; } = string.Empty;
        [Column("LAST_NAME")]
        public string? LastName { get; set; } = string.Empty;
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        [Column("COVERAGE_START")]
        public DateTime? CoverageStart { get; set; }
        [Column("LabelValue")]
        public string? LabelValue { get; set; } = string.Empty;
        [Column("DisplayValue")]
        public string? DisplayValue { get; set; } = string.Empty;
        [Column("ClientOptionValue")]
        public string? ClientOptionValue { get; set; } = string.Empty;
        [Column("COVERAGE_END")]
        public DateTime? CoverageEnd { get; set; }
        [Column("AMOUNT")]
        public Decimal? Amount { get; set; }
        [Column("DUE_DATE")]
        public DateTime? DueDate { get; set; }
        [Column("ER_PAID")]
        public Decimal? ErPaid { get; set; }
        [Column("OWED")]
        public Decimal? Owed { get; set; }
        [Column("PAID")]
        public Decimal? Paid { get; set; }
        [Column("STATUS")]
        public string? Status { get; set; } = string.Empty;
        [Column("EVENT_NAME")]
        public string? EventName { get; set; } = string.Empty;
        [Column("AFFILIATE_NAME")]
        public string? AffiliateName { get; set; } = string.Empty;
        public int TotalCount { get; set; }
    }
}

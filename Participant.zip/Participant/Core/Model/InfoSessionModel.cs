﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class InfoSessionModel : PlatformModel
    {
        public InfoResultViewModel? ParticipantInfo { get; set; }
        public InfoResultViewModel? ParticipantInfoOld { get; set; }
        public List<SpecificFieldsModel>? SpecificFields { get; set; }
        public List<DependentNewViewModel>? Dependents { get; set; }
        public List<DependentNewViewModel>? DependentsOld { get; set; }
        public AvailablePlansClientModel? AvailablePlans { get; set; }
        public ProcessQEInfoModel? ProcessQE { get; set; }
        public AddressModel? Address { get; set; }
        [DataType(DataType.Text)]
        public string UserType { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string? EventType { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string? FormNumber { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string? EventTypeQE { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string? UserName { get; set; } = String.Empty;
    }
}

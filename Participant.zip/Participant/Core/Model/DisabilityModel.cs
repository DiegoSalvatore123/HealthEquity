﻿namespace Core.Model
{
    public class DisabilityModel
    {
        public InfoResultModel? ParticipantInfo { get; set; }
        public string? SurchargePercent { get; set; }
        public string? EligibilityEnd { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ClientModel
    {
        [Key]
        [Column("CLIENT_ID")]
        public int? ClientId { get; set; }
        [Column("EMPLOYER_NAME")]
        public string? EmployerName { get; set; }
        [Column("EIN")]
        public string? Ein { get; set; }
    }
}

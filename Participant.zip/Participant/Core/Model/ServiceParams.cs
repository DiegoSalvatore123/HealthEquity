﻿
namespace Core.Model
{
    public class ServiceParams
    {
        public string ServiceName { get; set; } = string.Empty;
        public int Port { get; set; } = 0;
        public string HealthCheckUri { get; set; } = string.Empty;
    }
}

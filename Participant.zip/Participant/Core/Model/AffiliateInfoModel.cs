﻿namespace Core.Model
{
    public class AffiliateInfoModel:PlatformModel
    {
        public string AffiliateName { get; set; } = string.Empty;
    }
}

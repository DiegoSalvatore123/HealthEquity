﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CoveragePlanDataModel:PlatformModel
    {
        [DataType(DataType.Text)]
        public string BillingStartDate { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string QualifyingEventDate { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string HireDate { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Zip { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string State { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string DateOfBirth { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string AffiliateName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string UserType { get; set; } = string.Empty;
        public List<SpecificFieldsModel>? ParticipantSpecificFields { get; set; }
        [DataType(DataType.Text)]
        public string? Xml { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? AffiliateId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? QualifiedCode { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string FirstName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string LastName { get; set; } = string.Empty;
        public List<DependentNewViewModel>? Dependents { get; set; }
        [DataType(DataType.Text)]
        public string Action { get; set; } = string.Empty;
    }
}

﻿namespace Core.Model
{
    public class CoverageAcceptable : PlatformModel
    {
        public string ParticipantId { get; set; } = string.Empty;
        public string PlanName { get; set; } = string.Empty;
    }
}

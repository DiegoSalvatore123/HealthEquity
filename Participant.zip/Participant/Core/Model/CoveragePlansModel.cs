﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CoveragePlansModel
    {
        [Column("PARTICIPANT_COVERAGE_ID")]
        public int ParticipantCoverageId { get; set; }
        public int CoveredIndividualId { get; set; }
        [Column("PARTICIPANT_NAME")]
        public string ParticipantName { get; set; } = string.Empty;
        public Decimal CoverageAmount { get; set; }
        public string PolicyNumber { get; set; } = string.Empty;
        [Column("PLAN_ID")]
        public int PlanId { get; set; }
        [Column("PLAN_NAME")]
        public string PlanName { get; set; } = string.Empty;
    }
}



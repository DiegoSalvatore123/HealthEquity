﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DependentDetailModel  
    {
        [Column("DependentModelId")]
        public int DependentModelId { get; set; }
        [Column("PLAN_NAME")]
        public string Name { get; set; } = string.Empty;
        [Key]
        [Column("COVERAGE_ID")]
        public int CoverageId { get; set; }
        [Column("EFFECTIVE_DATE")]
        public string? EfectiveDate { get; set; }
        [Column("TERMINATION_DATE")]
        public string? TerminationDate { get; set; }
        [Column("FIXED_PREMIUM")]
        public decimal? FixedPremium { get; set; }
        [Column("IsTobaccoRated")]
        public bool IsTobaccoRated { get; set; }
        [Column("TobaccoUse")]
        public string? TobaccoUse { get; set; }
        [Column("RateDescription")]
        public string RateDescription { get; set; } = string.Empty;
    }
}

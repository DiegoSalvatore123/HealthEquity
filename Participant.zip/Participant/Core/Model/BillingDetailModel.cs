﻿namespace Core.Model
{
    public class BillingDetailModel 
    {
        public  int ErrorCount { get;  set; }
        public List<BillingModel>? Billing { get;  set;}
    }
}

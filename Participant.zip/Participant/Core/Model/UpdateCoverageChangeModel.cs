﻿namespace Core.Model
{
    public class UpdateCoverageChangeModel : CoverageChangeModel
    {
        public string? NewCoverageCode { get; set; }
        public string? OldCoverageCode { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model;

public class ParticipantCoveragePlanOptionResultModel
{
    [Column("PLAN_NAME")]
    public string? PlanName { get; set; }
    [Key]
    [Column("PLAN_ID")]
    public int? PlanId { get; set; }
    [Column("FIRST_NAME")]
    public string? FirstName { get; set; }
    [Column("LAST_NAME")]
    public string? LastName { get; set; }
    [Column("EFFECTIVE_DATE")]
    public DateTime? EffectiveDate { get; set; }
}
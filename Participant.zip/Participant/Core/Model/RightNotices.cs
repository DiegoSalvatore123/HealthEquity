﻿namespace Core.Model
{
    public class RightNotices
    {
        public string CobraYN { get; set; } = string.Empty;
        public string HipaaYN { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class GroupUpdateSearchModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string? GroupUpdateIdNumber { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? DivisionLevelAccess { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? AffiliateString { get; set; } = string.Empty;
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 0;
        [DataType(DataType.Text)]
        public string? Order { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? OrderDirection { get; set; } = string.Empty;
        public bool IsPaginationSort { get; set; } = false;
    }
}

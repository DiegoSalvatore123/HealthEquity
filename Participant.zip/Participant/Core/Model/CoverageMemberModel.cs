﻿namespace Core.Model
{
    public class CoverageMemberModel
    {
        public int? ParticipantId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? ParticipantCoverageId { get; set; } = string.Empty;
        public string? FixedPremiun { get; set; } = string.Empty;
        public string? TobaccoUse { get; set; } = string.Empty;
        public string? Amount { get; set; } = string.Empty;
        public string? PolicyNumber { get; set; } = string.Empty;
    }
}

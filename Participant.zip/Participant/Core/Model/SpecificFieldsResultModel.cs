﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class SpecificFieldsResultModel
    {
        [Column("ClientId")]
        public int ClientId { get; set; }
        [Column("CustomFieldId")]
        public int CustomFieldId { get; set; }
        [Key]
        [Column("FieldName")]
        public string? FieldName { get; set; }
        [Column("FieldValue")]
        public string? FieldValue { get; set; }
        [Column("IntegrationName")]
        public string? IntegrationName { get; set; }
        [Column("ShowOnWeb")]
        public bool ShowOnWeb { get; set; }
        [Column("ShowOnReports")]
        public bool ShowOnReports { get; set; }
        [Column("IsRequired")]
        public bool IsRequired { get; set; }
        [Column("ValidTypeId")]
        public byte ValidTypeId { get; set; }
        [Column("HasValidation")]
        public bool HasValidation { get; set; }
        public int HasDomainList { get; set; }
        [NotMapped]
        public List<CustomFieldDomain>? CustomFieldDomain { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class DisabilityUpdateModel : PlatformModel
    {
        public int? ParticipantId { get; set; }
        [DataType(DataType.Text)]
        public string? Name { get; set; }
        public decimal? SurchargePercent { get; set; }
        public DateTime? EligibilityEnd { get; set; }
        public DateTime? DeterminationDate { get; set; }
    }
}

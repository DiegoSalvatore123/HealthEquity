﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ProcessQEInfoModel
    {
        public string? QEEventDate { get; set; }
        public string? QeReason { get; set; }
        public string? ElectionNoticeMailedDate { get; set; }
        public string? ElectionDate { get; set; }
        public string? WaitingStartDate { get; set; }
        public string? BillingStartDate { get; set; }
        public string? SeverancePackageCode { get; set; } = string.Empty;
        public string? SeverancePackageDescription { get; set; } = string.Empty;
        public string? QeReasonDescription { get; set; }
       // public string? OptionValue { get; set; } = string.Empty;
        public string? ExtensionLength { get; set; }
        public string? Sev1Time { get; set; } = string.Empty;
        public string? SevThrough { get; set; } = string.Empty;
        public string? SevPercent { get; set; } = string.Empty;
        public string? SevMonthly { get; set; } = string.Empty;
        //public string? Extension { get; set; } = string.Empty;
        public string? EligiibilityEndDate { get; set; } = string.Empty;
        public string? LastDayPreCobraCoverage { get; set; } = string.Empty;
        public string? LastDayPreCobraCoverage2 { get; set; } = string.Empty;
        public string? CoverageBeginDate { get; set; } = string.Empty;
        public string? EligibilityStart { get; set; } = string.Empty;
    }
}

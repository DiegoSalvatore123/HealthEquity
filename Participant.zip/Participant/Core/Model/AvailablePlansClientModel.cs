﻿namespace Core.Model
{
    public class AvailablePlansClientModel
    {
        public List<AvailablePlansClientResultModel>? AvailablePlansClient { get; set; }
        public List<AvailablePlansClientResultModel>? ExistingPlansClient { get; set; }
        public bool IsFeatureOn { get; set; }
        public string QEExtension { get; set; } = string.Empty;
        public bool IsSubsidy { get; set; }
    }
   
}

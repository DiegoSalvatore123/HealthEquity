﻿namespace Core.Model
{
    public class SubsidyPlanModel
    {
        public int Id { get; set; }
        public string? StartDate { get; set; } = string.Empty;
        public string? EndDate { get; set; } = string.Empty;
        public string? Type { get; set; } = string.Empty;
        public string? Monthly { get; set; } = string.Empty;
        public bool PaysAdminFee { get; set; } = false;
        public string? TypeDescription { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class InfoResultModel 
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public Int32 ParticipantId { get; set; }
        [Column("parent_participant_id")]
        public Int32 ParentParticipantId { get; set; }
        [Column("GENDER")]
        public string? Gender { get; set; } = string.Empty;
        [Column("lgen_descr")]
        public string? LgenDesc { get; set; } = string.Empty;
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        [Column("FIRST_NAME")]
        public string? FirstName { get; set; } = string.Empty;
        [Column("LAST_NAME")]
        public string? LastName { get; set; } = string.Empty;
        [Column("MIDDLE_INITIAL")]
        public string? MiddleInitial { get; set; } = string.Empty;
        [Column("EMPLOYER_NAME")]
        public string? EmployerName { get; set; } = string.Empty;
        [Column("EMPLOYEE_NUMBER")]
        public string? EmployeeNumber { get; set; } = string.Empty;
        [Column("HIRE_DATE")]
        public string? HireDate { get; set; } = string.Empty;
        [Column("BIRTH_DATE")]
        public string? BirthDate { get; set; } = string.Empty;
        [Column("cancellation_effective_date")]
        public string? CancelationEffectiveDate { get; set; } = string.Empty;
        [Column("PARTICIPANT_TYPE")]
        public string? ParticipantType { get; set; } = string.Empty;
        [Column("PARTICIPANT_STATUS")]
        public string? ParticipantStatus { get; set; } = string.Empty;
        [Column("FORMER_DEPENDENT_ID")]
        public string? FormerDependenId { get; set; } = string.Empty;
        [Column("ELIGIBLE")]
        public string? Eligible { get; set; } = string.Empty;
        [Column("ELIGIBILITY_START_DATE")]
        public string? EligibilityStartDate { get; set; } = string.Empty;
        [Column("ELIGIBILITY_END_DATE")]
        public string? EligibilityEndDate { get; set; } = string.Empty;
        [Column("ELECTION_DATE")]
        public string? ElectionDate { get; set; } = string.Empty;
        [Column("COBRA_STATUS")]
        public string? CobraStatus { get; set; } = string.Empty;
        [Column("ELECTION_EXPIRATION_DATE")]
        public string? ElectionExpirationDate { get; set; } = string.Empty;
        [Column("SEVERANCE_THROUGH")]
        public string? SeveranceThrough { get; set; } = string.Empty;
        [Column("EIN")]
        public string? Ein { get; set; } = string.Empty;
        [Column("AFFILIATE_NAME")]
        public string? AffiliateName { get; set; } = string.Empty;
        [Column("QUALIFYING_EVENT_TYPE")]
        public string? QualifyngEventType { get; set; } = string.Empty;
        [Column("QUALIFYING_EVENT_DATE")]
        public string? QualifyngEventDate { get; set; } = string.Empty;
        [Column("WAITING_START_DATE")]
        public string? WaitingStartDate { get; set; } = string.Empty;
        [Column("COVERAGE_START_DATE")]
        public string? CoverageStartDate { get; set; } = string.Empty;
        [Column("LAST_PRECOBRA_COVERED_DATE")]
        public string? LastPrecobraCoveredDate { get; set; } = string.Empty;
        [Column("QUALIFIED_BENEFICIARY")]
        public string? QualifiedBeneficiary { get; set; } = string.Empty;
        [Column("BILLING_START_DATE")]
        public string? BillingStartDate { get; set; } = string.Empty;
        [Column("KEY_EMPLOYEE")]
        public bool KeyEmployee { get; set; }
        [Column("SHARE_HOLDER5")]
        public bool ShareHolders { get; set; }
        [Column("HIGHLY_COMP_MFSA")]
        public bool HighlyCompMfsa { get; set; }
        [Column("HIGHLY_COMP_POP")]
        public bool HighlyCompPop { get; set; }
        [Column("SALARY_UNDER_25K")]
        public bool SalaryUnder25K { get; set; }
        [Column("PAY_SCHEDULE_ID")]
        public int? PayScheduleId { get; set; }
        [Column("PHONE_NUMBER")]
        public string? PhoneNumber { get; set; } = string.Empty;
        [Column("PREFERRED_LANGUAGE")]
        public string? PreferredLanguage { get; set; } = string.Empty;
        [Column("CLASS_NAME")]
        public string? ClassName { get; set; } = string.Empty;
        [Column("EMPLOYEE_CLASS_ID")]
        public int? EmployeeClassId { get; set; }
        [Column("AFFILIATE_ID")]
        public int? AffiliateId { get; set; }
        [Column("PAID_THRU_DATE")]
        public string? PaidThruDate { get; set; } = string.Empty;
        [Column("PayPolicy")]
        public string? PayPolicy { get; set; } = string.Empty;
        [Column("NOTICE_HOLD")]
        public bool NoticeHold { get; set; }
        [Column("LabelValue")]
        public string? ParticipantLabel { get; set; } = string.Empty;
        [Column("DisplayValue")]
        public string? ParticipantValue { get; set; } = string.Empty;
        [Column("ClientOptionValue")]
        public string? ClientOptionValue { get; set; } = string.Empty;
        [Column("NoticeHoldReason")]
        public string? NoticeHoldReason { get; set; } = string.Empty;
        [Column("LANGUAGE_NAME")]
        public string? LanguageName { get; set; } = string.Empty;
        [Column("EMAIL_ADDRESS")]
        public string? EmailAddress { get; set; } = string.Empty;
        public string? Status { get; set; } = string.Empty;
        [Column("LOOKUP_DESCRIPTION")]
        public string? LookupDescription { get; set; } = string.Empty;
        [Column("Address_1")]
        public string? Address1 { get; set; } = string.Empty;
        [Column("Address_2")]
        public string? Address2 { get; set; } = string.Empty;
        [Column("State")]
        public string? State { get; set; } = string.Empty;
        [Column("Zip")]
        public string? Zip { get; set; } = string.Empty;
        [Column("StateZip")]
        public string? StateZip { get; set; } = string.Empty;
        public string? OptionValue { get; set; } = string.Empty;
        public string? Name { get; set; } = string.Empty;
        [Column("EVENT_NAME")]
        public string? EventName { get; set; } = string.Empty;
        [Column("Medicare_Eligible")]
        public string? MedicareEligible { get; set; } = string.Empty;
        [Column("CITY")]
        public string? City { get; set; } = string.Empty;
        public string? DisplayCases { get; set; } = string.Empty;
        public int Option441 { get; set; }
        public string? StatusCode { get; set; } = string.Empty;
        public int ACH { get; set; }
        [Column("RELATIONSHIP")]
        public string? Relationship { get; set; } = string.Empty;
        public int IsProcessQE { get; set; }
        public string? CobraPlanDescription { get; set; } = string.Empty;
        public int IsCobraPlan { get; set; }

    }
}

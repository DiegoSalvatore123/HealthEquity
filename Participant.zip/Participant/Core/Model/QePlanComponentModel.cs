﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class QEPlanComponentModel
    {
        public int DisablePLS { get; set; }
        public int Bentypecnt { get; set; }
        public int Salary { get; set; }
        [Column("benefittypesubtypeid")]
        public int BenType { get; set; }
    }
}

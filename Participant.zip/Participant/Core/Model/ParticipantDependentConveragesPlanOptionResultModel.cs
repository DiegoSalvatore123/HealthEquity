﻿namespace Core.Model;

public class ParticipantDependentCoveragesPlanOptionResultModel
{
    public ParticipantCoveragePlanOptionResultModel? planOption { get; set; }
    public List<ParticipantDependentCoverageResultModel>? DependentCoverages { get; set; }
}
﻿namespace Core.Model
{
    public class QueueAchModel
    {
        public string ParticipantId {  get; set; }=string.Empty; 
        public string UserId { get; set;} = string.Empty;
        public string EventType { get; set;} = string.Empty;
        public string EventDate { get; set; } = string.Empty;
        public string FormNumber { get; set; } = string.Empty;
        public string EventSource { get; set; } = string.Empty;
        public string DueDate { get; set; } = string.Empty;
        public string EventDescription { get; set; } = string.Empty;
        public string CouponStartDate { get; set; } = string.Empty;
        public int OptionValue { get; set; } 
    }
}

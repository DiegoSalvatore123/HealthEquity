﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("EMAIL_NOTIFICATIONS")]
    public class EmailNotificationModel
    {
        [Key]
        [Column("NOTIFICATION_ID")]
        public Int32 NotificacionId { get; set; }
        [Column("QUEUED_BY")]
        public Int32? QueuedBy { get; set; }
        [Column("NOTIFICATION_TYPE")]
        public string NotificacionType { get; set; } = string.Empty;
        [Column("LINK_TO")]
        public Int32? LinkTo { get; set; }
        [Column("DATE_QUEUED")]
        public DateTime DateQueued { get; set; }
        [Column("DATE_STARTED")]
        public DateTime? Date_Started { get; set; }
        [Column("DATE_SENT")]
        public DateTime? DateSent { get; set; }
        [Column("NOTIFICATION_STATUS")]
        public string NotificacionStatus { get; set; } = string.Empty;
        [Column("RETRY_COUNTER")]
        public int RetryCounter { get; set; }
        [Column("SUBJECT")]
        public string Subject { get; set; } = string.Empty;
        [Column("EMAIL_ADDRESS")]
        public string? EmailAddress { get; set; }
        [Column("TEXT_MESSAGE")]
        public string? TextMessage { get; set; }
        [Column("HTML_MESSAGE")]
        public string? HTMLMessage { get; set; }
        [Column("FROM_ADDRESS")]
        public string? FromAddress { get; set; }
    }
}

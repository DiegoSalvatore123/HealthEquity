﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    [Table("PARTICIPANT", Schema = "dbo")]
    public class Participant
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("CLIENT_ID")]
        public int ClientId { get; set; }

        [Column("AFFILIATE_ID")]
        public int AffiliateId { get; set; }

        [Column("EMPLOYEE_CLASS_ID")]
        public int EmployeeClassId { get; set; }

        [Column("PARTICIPANT_STATUS")]
        public char Status { get; set; }

        [Column("LAST_NAME")]
        public string? LastName { get; set; }

        [Column("FIRST_NAME")]
        public string? FirstName { get; set; }

        [Column("COMMENTS")]
        public string? Comments { get; set; }

        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SSN { get; set; }
    }
}
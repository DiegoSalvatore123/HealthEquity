﻿namespace Core.Model
{
    public class PlanMLRModel:PlatformModel
    {
        public int PlanId { get; set; }
    }
}

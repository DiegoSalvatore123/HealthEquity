﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ValidateHireDataModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string SSN { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string HireDate { get; set; } = string.Empty;
    }
}

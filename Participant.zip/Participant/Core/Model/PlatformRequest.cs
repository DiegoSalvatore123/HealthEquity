﻿namespace Core.Model
{
    public class PlatformRequest
    {
        public string Platform { get; set; } = string.Empty;
        public string ResourceName { get; set; } = string.Empty;
    }
}

﻿
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class QeCodeExtensionModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string QeCode { get; set; } = string.Empty;
    }
}

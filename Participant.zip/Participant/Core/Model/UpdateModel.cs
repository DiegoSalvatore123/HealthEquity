﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class UpdateModel : PlatformModel
    {
        public List<GroupUpdateDataSaveModel>? GroupUpdateResult { get; set; }
        [DataType(DataType.Text)]
        public string OptionToShow { get; set; } = String.Empty;
        public GroupUpdateSaveModel GroupUpdate { get; set; } = new();
    }
}

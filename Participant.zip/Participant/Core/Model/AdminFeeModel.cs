﻿namespace Core.Model;

public class AdminFeeModel
{
    public decimal AdminFee { get; set; } = new decimal(0.00);
}
﻿namespace Core.Model
{
    public class EmailReSendModel
    {
        public string DocId { get; set; } = string.Empty;
    }
}

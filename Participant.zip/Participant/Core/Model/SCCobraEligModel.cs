﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SCCobraEligModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string Statement { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string CallingPage { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("PARTICIPANT_PAYMENT")]
    public class PaymentModel
    {
        [Key]
        [Column("PAYMENT_ID")]
        public int ParymentId { get; set; }

        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("PAYMENT_STATUS")]
        public char Status { get; set; }
    }
}

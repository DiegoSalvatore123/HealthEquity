﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class GenericGuidValue
    {
        [Key]
        public Guid Value { get; set; }
    }
}

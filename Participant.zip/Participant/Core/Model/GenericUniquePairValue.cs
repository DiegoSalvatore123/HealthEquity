﻿using System.ComponentModel.DataAnnotations;
 
namespace Core.Model
{
    public class GenericUniquePairValue
    {
        [Key]
        public string? Code { get; set; }
        public string? Description { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class QualifyingEventTypeModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string QualifyingEventType { get; set; } = string.Empty;
    }
}

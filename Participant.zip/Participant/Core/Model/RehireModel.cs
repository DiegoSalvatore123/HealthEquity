﻿
namespace Core.Model
{
    public class RehireModel
    {
        public string ClientId { get; set; } = string.Empty;
        public int ParticipantId { get; set; }
        public string SSN { get; set; } = string.Empty;
        public string BeneficiaryDate { get; set; } = string.Empty;
        public string? HireDate { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;
        public string Debug { get; set; } = string.Empty;
        public string DirectBill { get; set; } = string.Empty;
    }
}

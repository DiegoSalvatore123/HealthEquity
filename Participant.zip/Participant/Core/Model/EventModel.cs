﻿namespace Core.Model
{
    public class EventModel
    {
        public int ParticipantId { get; set; }
        public string EventType { get; set; } = string.Empty;
        public string EventSource { get; set; } = string.Empty;
        public string Comment { get; set; } = string.Empty;
        public string UserId { get; set; } = string.Empty;

    }
}

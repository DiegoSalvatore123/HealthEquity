﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class CoverageModel  
    {
       
        [Column("PLAN_NAME")]
        public string PlanName { get; set; } = string.Empty;
        [Column("COVERAGE_DESCRIPTION")]
        public string CoverageDescription { get; set; } = string.Empty;
        [Key]
        [Column("PARTICIPANT_COVERAGE_ID")]
        public int ParticipantCoverageId { get; set; }
        [Column("EFFECTIVE_DATE")]
        public string EffectiveDate { get; set; } = string.Empty;
        [Column("TERMINATION_DATE")]
        public string TerminationDate { get; set; } = string.Empty;
        [Column("LOOKUP_DESCRIPTION")]
        public string LookupDescription { get; set; } = string.Empty;
        [Column("TobaccoUse")]
        public string? TobaccoUse { get; set; }
        [Column("IsInsurancePlan")]
        public string IsInsurancePlan { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}

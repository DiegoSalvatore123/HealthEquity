﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class ClientPlansModel
    {
        [Key]
        [Column("PLAN_ID")]
        public int PlanId { get; set; }
        [Column("PLAN_NAME")]
        public string PlanName { get; set; } = string.Empty;
        [Column("PLAN_TYPE")]
        public string PlanType { get; set; } = string.Empty;
        [Column("COVERAGE_END_TYPE")]
        public string CoverageEndType { get; set; } = string.Empty;
        [Column("WAIT_PERIOD_QTY")]
        public Int16 WaitPeriodoQty { get; set; }
        [Column("WAIT_ENDS_TYPE")]
        public string WaitEndsType { get; set; } = string.Empty;
    }
}

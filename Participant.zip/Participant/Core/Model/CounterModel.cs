﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CounterModel { 
        [Key]
        public int Count { get; set; }
    }
}

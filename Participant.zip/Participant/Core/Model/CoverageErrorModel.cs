﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class CoverageErrorModel
    {
        [Key]
        [Column("PARTICIPANT_COVERAGE_ID")]
        public int ParticipantCoverageId { get; set; }
        [Column("DEPENDENT_ERROR")]
        public string? DependentError { get; set; } = string.Empty;
        [Column("PLAN_NAME")]
        public string PlanName { get; set; } = string.Empty;
        [Column("COVERAGE_DESCRIPTION")]
        public string CoverageDescription { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}

﻿namespace Core.Model
{
    public class AvailablePlans : PlatformModel
    {
        public string QEventDate { get; set; } = string.Empty;
        public string ParticipantId { get; set; } = string.Empty;
        public bool IsDependentProcessQE { get; set; }
        public List<AvailablePlansClientResultModel>? AvailablePlansClient { get; set; }
        public int NewMemberCount { get; set; }
        public string PlanData { get; set; } = string.Empty;
        public string MemberData { get; set; } = string.Empty;
        public int QuoteRateCount { get; set; }
        public string? Guids { get; set; } = string.Empty;
        public int RateCount { get; set; }
    }
}

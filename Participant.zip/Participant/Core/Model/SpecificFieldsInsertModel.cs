﻿
namespace Core.Model
{
    public class SpecificFieldsInsertModel
    {
        public string Xml { get; set; }=string.Empty;
        public string UserId { get; set; } = string.Empty;    
    }
}

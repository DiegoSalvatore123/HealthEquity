﻿namespace Core.Model
{
    public class DependentProcessQEModel : InfoSessionModel
    {
        public ClientOptionResultModel? CO709 { get; set; } 
    }
}

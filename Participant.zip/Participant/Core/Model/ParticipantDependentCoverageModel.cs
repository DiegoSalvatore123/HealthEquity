﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model;

public class ParticipantDependentCoverageModel:PlatformModel
{
    [DataType(DataType.Text)]
    public string ParticipantCoverageId { get; set; } = string.Empty;
}
﻿
namespace Core.Model
{
    public class PopFlexLanModel
    {
        public string? Pop { get; set; }
        public string? Flex { get; set; }
        public string Lan { get; set; } = string.Empty;
    }
}

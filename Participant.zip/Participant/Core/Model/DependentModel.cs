﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DependentModel  
    {
        
        [Key]
        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }
        [Column("FIRST_NAME")]
        public string FirstName { get; set; } = string.Empty;
        [Column("LAST_NAME")]
        public string LastName { get; set; } = string.Empty;
        [Column("MIDDLE_INITIAL")]
        public string? MiddleInitial { get; set; }
        [Column("FULL_NAME")]
        public string FullName { get; set; } = string.Empty;
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; }
        [Column("BIRTH_DATE")]
        public string? BirthDate { get; set; }
        [Column("PARTICIPANT_STATUS")]
        public string ParticipantStatus { get; set; } = string.Empty;
        [Column("QUALIFIED_BENEFICIARY")]
        public string QualifiedBeneficiary { get; set; } = string.Empty;
        [Column("STUDENT")]
        public string Student { get; set; } = string.Empty;
        [Column("RELATIONSHIP")]
        public string Relationship { get; set; } = string.Empty;
        [Column("DepRelation")]
        public string DepRelation { get; set; } = string.Empty;
        [Column("DepStudent")]
        public string DepStudent { get; set; } = string.Empty;
        [Column("DepStatus")]
        public string DepStatus { get; set; } = string.Empty;
        [Column("MedicareEligible")]
        public string MedicareEligible { get; set; } = string.Empty;
        [Column("HasTabaccoReated")]
        public bool HasTabaccoReated { get; set; } = false;
        [Column("GENDER")]
        public string? Gender { get; set; } = string.Empty;
        [Column("GENDER_DESCRIPTION")]
        public string? GenderDescription { get; set; } = string.Empty;
        [Column("WAITING_START_DATE")]
        public string? WaitingStartDate { get; set; } = string.Empty;
        [Column("COVERAGE_START_DATE")]
        public string? CoverageStartDate { get; set; } = string.Empty;
        [Column("EMPLOYEE_NUMBER")]
        public string? EmployeeNumber { get; set; } = string.Empty;
        public List<DependentDetailModel>? DependentDetailModel { get; set; }
    }
}

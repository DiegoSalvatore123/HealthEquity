﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class RemoveQEModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Reason { get; set; } = string.Empty;
    }
}

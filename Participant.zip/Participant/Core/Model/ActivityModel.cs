﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class ActivityModel  
    {
        [Column("LOOKUP_DESCRIPTION")]
        public string? LookupDescription { get; set; } = string.Empty;
        [Column("USER_NAME")]
        public string? UserName { get; set; } = string.Empty;
        [Column("COMMENTS")]
        public string? Comments { get; set; } = string.Empty;        
        [Column("LOG_DATE")]
        public string? Log_Date { get; set; } = string.Empty;
        public string? LogDate { get; set; } = string.Empty;
        public int TotalCount { get; set; }
    }
}

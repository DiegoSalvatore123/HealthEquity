﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Core.Model
{
    public class PaymentHistoryModel
    {
        [Key]
        [Column("PAYMENT_ID")]
        public Int32 PaymentId { get; set; }
        [Column("CHECK_NO")]
        public string? CheckNumber { get; set; } = string.Empty;
        [Column("AMOUNT")]
        public Decimal Amount { get; set; }
        [Column("PAYMENT_TYPE")]
        public string PaymentType { get; set; } = string.Empty;
        [Column("DOC_IMAGE_ID")]
        public string? DocumentImageId { get; set; } = string.Empty;
        [Column("POSTMARK_DATE")]
        public DateTime? PostMark { get; set; }
        [Column("PAYMENT_STATUS")]
        public string PaymentStatus { get; set; } = string.Empty;
        [Column("PTypeDesc")]
        public string TypeDescription { get; set; } = string.Empty;
        [Column("PStatusDesc")]
        public string StatusDescription { get; set; } = string.Empty;
        [Column("period_start_date")]
        public string PeriodStartDate { get; set; } = string.Empty;
        public int TotalCount { get; set; }
    }
}

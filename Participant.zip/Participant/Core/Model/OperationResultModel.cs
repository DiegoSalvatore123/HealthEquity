﻿namespace Core.Model
{
    public class OperationResultModel
    {
        public bool Success { get; set; }
        public string ResultDescription { get; set; } = string.Empty;
        public string ErrorDetails { get; set; } = string.Empty;
        public string ParticipantId { get; set; } = string.Empty;
        public bool DependentError { get; set; }
    }
}

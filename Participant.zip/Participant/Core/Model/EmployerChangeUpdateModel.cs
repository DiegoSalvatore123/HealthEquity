﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class EmployerChangeUpdateModel : PlatformModel
    {
        public int? ParticipantId { get; set; }
        [DataType(DataType.Text)]
        public string? Name { get; set; }
        [DataType(DataType.Text)]
        public string? NewClientId { get; set; }
        [DataType(DataType.Text)]
        public string? Reason { get; set; }
    }
}

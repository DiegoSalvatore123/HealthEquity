﻿
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SCCobraEligViewModel { 
        [Key]
        public int IncludeSC { get; set; }
        public int IncludeCobraElig { get; set; }
    }
}

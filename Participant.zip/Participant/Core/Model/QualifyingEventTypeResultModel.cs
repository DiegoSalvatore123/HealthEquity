﻿using System.Text.Json.Serialization;

namespace Core.Model
{
    public class QualifyingEventTypeResultModel
    {
        [JsonPropertyName("QeMetaDatas")]
        public List<QeMetaDatas>? QeMetaDatas { get; set; }
        [JsonPropertyName("ResponseDateUtc")]
        public DateTime? ResponseDateUtc { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model;

public class ParticipantInfoModel : PlatformModel
{
    [DataType(DataType.Text)]
    public string ParticipantId { get; set; } = string.Empty;
}
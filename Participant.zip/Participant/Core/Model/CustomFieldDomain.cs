﻿namespace Core.Model
{
    public class CustomFieldDomain
    {
        public string? DomainValue { get; set; } = string.Empty;
        public bool IsDefault { get; set; }
        public int CustomFieldId { get; set; }
    }
}

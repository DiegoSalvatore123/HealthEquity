﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ParticipantIdModel : PlatformModel
    {
        [DataType(DataType.Text)]
        public string ParticipantId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string Sort { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PageSize { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PageNumber { get; set; } = string.Empty;
        public Dictionary<string, string>? FilterConditions { get; set; }
    }
}
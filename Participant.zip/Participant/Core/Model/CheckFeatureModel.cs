﻿
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CheckFeatureModel:PlatformModel
    {
    }
}

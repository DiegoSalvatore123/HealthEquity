﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DBImpendingMedicareReportModel
    {
        [Column("PARTICIPANT_ID")]
        public int ParticipantID { get; set; }
        [Column("LAST_NAME")]
        public string LastName { get; set; } = string.Empty;
        [Column("FIRST_NAME")]
        public string FirstName { get; set; } = string.Empty;
        [Column("AGE")]
        public int Age { get; set; }
        [Column("QUALIFYING_EVENT_DATE")]
        public string? QualifyingEventDate { get; set; } = string.Empty;
        [Column("ELIGIBILITY_START_DATE")]
        public string? EligibilityStartDate { get; set; } = string.Empty;
        [Column("ELIGIBILITY_END_DATE")]
        public string? EligibilityEndDate { get; set; } = string.Empty;
    }
}

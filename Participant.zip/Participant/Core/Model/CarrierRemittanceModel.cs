﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class CarrierRemittanceModel
    {
        [Column("STATEMENT_ID")]
        public Int32 StatementId { get; set; }
        [Column("PARTICIPANT_ID")]
        public Int32 ParticipantId { get; set; }
        [Column("PERIOD_END_DATE")]
        public DateTime PeriodEndDate { get; set; }
        [Column("COVERAGE_START_DATE")]
        public DateTime? CoverageStartDate { get; set; } 
        [Column("STATEMENT_PERIOD")]
        public string? StatementPeriod { get; set; }
        [Column("COVERAGE_PERIOD")]
        public string? CoveragePeriod { get; set; }
        [Column("CARRIER_NAME")]
        public string CarrierName { get; set; } = string.Empty;
        [Column("PLAN_NAME")]
        public string PlanName { get; set; } = string.Empty;
        [Column("COVERAGE_DESCRIPTION")]
        public string CoverageDescription { get; set; } = string.Empty;
        [Column("AMOUNT")]
        public Decimal Amount { get; set; }
        [Column("COMMENTS")]
        public string? Comments { get; set; }
        [Column("FINAL")]
        public Boolean Final { get; set; }
        [Column("FIRST_NAME")]
        public string FirstName { get; set; } = string.Empty;
        [Column("LAST_NAME")]
        public string LastName { get; set; } = string.Empty;
        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; }
        [Column("STATUS_DESCRIPTION")]
        public string StatusDescription { get; set;} = string.Empty;
        public int TotalCount { get; set; }
    }
}

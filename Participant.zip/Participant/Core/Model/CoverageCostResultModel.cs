﻿namespace Core.Model;

public class CoverageCostResultModel
{
    public decimal CoverageCost { get; set; } = new decimal(0.00);
}
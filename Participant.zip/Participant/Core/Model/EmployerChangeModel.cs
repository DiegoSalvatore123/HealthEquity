﻿namespace Core.Model
{
    public class EmployerChangeModel
    {
        public InfoResultModel? ParticipantInfo { get; set; }
        public List<ClientModel>? ClientList { get; set; }
        public List<string>? MessageList { get; set; }
    }
}

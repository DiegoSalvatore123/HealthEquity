﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
 
namespace Core.Model
{
    public class PlanModel 
    {
        [Key]
        [Column("PlanName")]
        public string? PlanName { get; set; } = string.Empty;
    }
}

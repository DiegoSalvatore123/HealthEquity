﻿namespace Core.Model
{
    public class InfoUpdateModel
    {
        public InfoResultModel? ParticipantInfo { get; set; }
        public List<SpecificFieldsResultModel>? ParticipantSpecificFields { get; set; }
        public List<DependentModel>? Dependents { get; set; }
        public List<AffiliateModel>? Divisions { get; set; }
        public List<EmployeeClassModel>? EmployeeClasses { get; set; }
        public List<StateModel>? States { get; set; }
        public List<RelationModel>? Relations { get; set; }
        public bool ShowCoverage { get; set; } = false;
    }
}

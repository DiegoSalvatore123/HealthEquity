﻿namespace Core.Model
{
    public class DBPastDueResponseDetailModel
    {
        public DateTime? CoverageStart { get; set; }
        public DateTime? CoverageEnd { get; set; }
        public DateTime? DueDate { get; set; }
        public Decimal? Amount { get; set; }
        public Decimal? Owed { get; set; }
        public string? Status { get; set; } = string.Empty;
    }
}

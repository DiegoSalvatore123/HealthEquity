﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class PlatformModel
    {
        [DataType(DataType.Text)]
        public string ClientId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string UserId { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string PlatformName { get; set; } = string.Empty;
    }
}
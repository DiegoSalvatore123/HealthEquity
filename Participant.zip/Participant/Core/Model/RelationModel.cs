﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class RelationModel
    {
        [Key]
        [Column("LOOKUP_CODE")]
        public string? LookupCode { get; set; }

        [Column("LOOKUP_DESCRIPTION")]
        public string LookupDescription { get; set; } = string.Empty;
        
    }
}

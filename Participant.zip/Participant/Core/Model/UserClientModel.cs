﻿namespace Core.Model
{
    public class UserClientModel:PlatformModel
    {
    }
}

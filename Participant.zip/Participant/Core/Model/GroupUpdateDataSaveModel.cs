﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
 
namespace Core.Model
{
    public class GroupUpdateDataSaveModel
    {
        public int ParticipantId { get; set; }
        [DataType(DataType.Text)]
        public string? EmployeeNumber { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? Student { get; set; } = string.Empty;
        public bool? KeyEmployee { get; set; }
        public bool? ShareHolder5 { get; set; }
        public bool? HighlyCompPop { get; set; }
        public bool? HighlyCompMFSA { get; set; }
        public bool? SalaryUnder25K { get; set; }
        public int? AffiliateId { get; set; }
        public DateTime? HireDate { get; set; }
        [DataType(DataType.Text)]
        public string? QualifiedBeneficiary { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? PhoneNumber { get; set; } = string.Empty;
        public int? PayScheduleId { get; set; }
        [DataType(DataType.Text)]
        public string? FirstName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? LastName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? MiddleInitial { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? SocialSecurityNumber { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? AffiliateName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? LabelValue { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? DisplayValue { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ClientOptionValue { get; set; }
        public int? TotalRecords { get; set; }
        [DataType(DataType.Text)]
        public string? UpdateNew { get; set; } = string.Empty;
    }
}

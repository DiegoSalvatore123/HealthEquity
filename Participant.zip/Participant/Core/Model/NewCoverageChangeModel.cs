﻿namespace Core.Model
{
    public class NewCoverageChangeModel : CoverageChangeModel
    {
        public string? NewCoverageCode { get; set; }
        public string? TerminationDate { get; set; }
    }
}

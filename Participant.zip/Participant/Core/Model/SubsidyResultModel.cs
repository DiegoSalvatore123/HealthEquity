﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SubsidyResultModel
    {
        [Column("ParticipantId")]
        public int ParticipantId { get; set; }
        [Column("StartDate")]
        public DateTime? StartDate { get; set; }
        [Column("EndDate")]
        public DateTime? EndDate { get; set; }
        [Column("BenefitTypeName")]
        public string? BenefitTypeName { get; set; }
        [Column("AmountType")]
        public string? AmountType { get; set; }
        [Column("AmountTypeId")]
        public byte? AmountTypeId { get; set; }
        [Column("Amount")]
        public decimal? Amount { get; set; }
        [Column("EmployerPaysAdminFee")]
        public byte? EmployerPaysAdminFee { get; set; }

    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class SearchBySSNModel : PlatformModel
    {
        [RegularExpression(@"^\d{9}|\d{3}-\d{2}-\d{4}$", ErrorMessage = "Invalid Social Security Number")]
        public string SocialSecurityNumber { get; set; } = string.Empty;
        public string DivisionLevelAccess { get; set; } = string.Empty;
        public string AffiliateId { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class StateModel
    {
        [Key]
        [Column("STATE_CODE")]
        public string? StateCode { get; set; }

        [Column("STATE_DESCRIPTION")]
        public string StateDescription { get; set; } = string.Empty;
    }
}

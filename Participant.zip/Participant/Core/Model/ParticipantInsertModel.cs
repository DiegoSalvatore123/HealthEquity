﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class ParticipantInsertModel : PlatformModel
    {
        public InfoResultViewModel ParticipantInfo { get; set; } = new();
        public List<DependentNewViewModel>? Dependents { get; set; }
        public List<SpecificFieldsModel>? SpecificFields { get; set; }
        public PopFlexLanModel? PopFlexLan { get; set; }
        [DataType(DataType.Text)]
        public string Co709 { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string Co713 { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string Status { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string ParticipantType { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string RehireDB { get; set; } = String.Empty;
        [DataType(DataType.Text)]
        public string UserType { get; set; } = String.Empty;
        public RightNotices? RightNotices { get; set; }
    }
}

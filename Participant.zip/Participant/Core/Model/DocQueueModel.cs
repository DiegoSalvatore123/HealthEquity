﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    [Table("DOC_QUEUE")]
    public class DocQueueModel
    {
        [Key]
        [Column("DOC_ID")]
        public int DocId { get; set; }

        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("DOC_STATUS")]
        public char DocStatus { get; set; }
    }
}

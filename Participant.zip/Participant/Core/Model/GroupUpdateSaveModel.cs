﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class GroupUpdateSaveModel
    {
        public int IdNumber { get; set; }
        [DataType(DataType.Text)]
        public string? TableName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ColumnName { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? ColumnType { get; set; } = string.Empty;
        public int Length { get; set; }
        public int LoopCount { get; set; }
        [DataType(DataType.Text)]
        public string? Title { get; set; } = string.Empty;
        public bool AllowNulls { get; set; }
        [DataType(DataType.Text)]
        public string? Criteria { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? OrderBy { get; set; } = string.Empty;
        [DataType(DataType.Text)]
        public string? UpdateType { get; set; } = string.Empty;
        public bool UseQuotes { get; set; }
    }
}

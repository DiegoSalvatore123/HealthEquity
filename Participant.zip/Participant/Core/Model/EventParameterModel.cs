﻿namespace Core.Model
{
    public class EventParameterModel
    {
        public string UserId { get; set; } = string.Empty;
        public int ParticipantId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string SocialSecurityNumber { get; set; } = string.Empty;
        public string HireDate { get; set; } = string.Empty;
        public string BirthDate { get; set; } = string.Empty;
        public string CustomComment { get; set; } = string.Empty;
        public string PlanName { get; set; } = string.Empty;

    }
}

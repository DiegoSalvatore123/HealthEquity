﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class QeMetaDatas
    {
        [Key]
        [Column("QualifyingEventType")]
        public string? Qe_code { get; set; } = string.Empty;
        [Column("QualifyingEventName")]
        public string? Event_name { get; set; } = string.Empty;
        [Column("ContinuationType")]
        public string? continuation_type { get; set; } = string.Empty;
        [Column("ExtensionLength")]
        public int Continuation_months { get; set; }
        [Column("AdminFee")]
        public decimal? Admin_fee_pct { get; set; }
        [Column("QualifyingEventScope")]
        public string? Qe_scope { get; set; } = string.Empty;
    }
}

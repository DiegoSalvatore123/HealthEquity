﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class DocumentResultModel
    {
        [Key]
        [Column("DOC_IMAGE_ID")]
        public Int32 DocumentImageId { get; set; }
        [Column("PATH")]
        public string? Path { get; set; } = string.Empty;
        [Column("EXTENSION")]
        public string? Extension { get; set; } = string.Empty;
        public string? CurrentExtension { get; set; } = string.Empty;
        public string? OldExtension { get; set; } = string.Empty;
        [Column("PARTICIPANT_ID")]
        public string? ParticipantId { get; set; } = string.Empty;
        [Column("CLIENT_ID")]
        public string? ClientId { get; set; } = string.Empty;
        [Column("DOC_IMAGE_TYPE")]
        public string DocumentImageType { get; set; } = string.Empty;
        [Column("DOC_IMAGE_STATUS")]
        public string DocumentImageStatus { get; set; } = string.Empty;
        [Column("NOTATION")]
        public string? Notation { get; set; } = string.Empty;
        [Column("CL_USER_ID")]
        public Int32? ClientUserId { get; set; }
        [Column("LOG_DATE")]
        public DateTime LogDate { get; set; }
        [Column("SECURE_ID")]
        public string SecureId { get; set; } = string.Empty;
        [Column("EVENT_TYPE")]
        public string? EventType { get; set; } = string.Empty;
        [Column("EVENT_ID")]
        public string? EventId { get; set; } = string.Empty;
        [Column("IMAGE_NAME")]
        public string? ImaggeName { get; set; } = string.Empty;
        [Column("IMAGE_ROUTING")]
        public string? ImageRouting { get; set; } = string.Empty;
        [Column("TRANS_START_TIME")]
        public DateTime? TransStarTime { get; set; }
        [Column("BATCH_ID")]
        public string? BatchId { get; set; } = string.Empty;
        [Column("SESSION_ID")]
        public string? SessionId { get; set; } = string.Empty;
        [Column("PARTNER_CODE")]
        public string? PartnerCode { get; set; } = string.Empty;
        public string Base64File { get; set; } = string.Empty;
    }
}

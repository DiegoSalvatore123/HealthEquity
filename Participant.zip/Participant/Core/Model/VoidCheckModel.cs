﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class VoidCheckModel
    {
        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("HIRE_DATE")]
        public DateTime HireDate { get; set; }

        [Column("PARTICIPANT_TYPE")]
        public string? ParticipantType { get; set; }

        [Column("FORMER_DEPENDENT_ID")]
        public string? FormerDependentId { get; set; }

        [Column("PARTICIPANT_STATUS")]
        public string? Status { get; set; }

        [Column("LAST_NAME")]
        public string? LastName { get; set; }

        [Column("FIRST_NAME")]
        public string? FirstName { get; set; }

        [Column("MIDDLE_INITIAL")]
        public string? Middle { get; set; }

        [Column("GENDER")]
        public string? Gender { get; set; }

        [Column("BIRTH_DATE")]
        public DateTime BirthDate { get; set; }

        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SSN { get; set; }

        [Column("EMPLOYEE_NUMBER")]
        public string? Employee { get; set; }

        [Column("PHONE_NUMBER")]
        public string? Phone { get; set; }

        [Column("EMAIL_ADDRESS")]
        public string? Email { get; set; }

        [Column("QUALIFIED_BENEFICIARY")]
        public string? Benificiary { get; set; }

        [Column("WAITING_START_DATE")]
        public DateTime Waiting { get; set; }

        [Column("COVERAGE_START_DATE")]
        public DateTime Coverage { get; set; }
    }
}

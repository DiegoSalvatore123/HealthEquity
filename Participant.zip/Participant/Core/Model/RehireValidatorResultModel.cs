﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class RehireValidatorResultModel
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public int? ParticipantId { get; set; }
    }
}

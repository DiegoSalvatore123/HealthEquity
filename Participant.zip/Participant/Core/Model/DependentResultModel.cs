﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model
{
    public class DependentResultModel
    {
        [Key]
        [Column("PARTICIPANT_ID")]
        public int ParticipantId { get; set; }

        [Column("SOCIAL_SECURITY_NUMBER")]
        public string? SocialSecurityNumber { get; set; } = string.Empty;

        [Column("PARENT_PARTICIPANT_ID")]
        public int? ParentParticipantId { get; set; }

        [Column("LAST_NAME")]
        public string? LastName { get; set; } = string.Empty;

        [Column("FIRST_NAME")]
        public string? FirstName { get; set; } = string.Empty;

        [Column("MIDDLE_INITIAL")]
        public string? MiddleInitial { get; set; } = string.Empty;

        [Column("STUDENT")]
        public string? IsStudent { get; set; } = string.Empty;

        [Column("RELATIONSHIP")]
        public string? Relationship { get; set; } = string.Empty;

        [Column("PARTICIPANT_STATUS")]
        public string? ParticipantStatus { get; set; } = string.Empty;

        [Column("Age")]
        public int? Age { get; set; }

        [Column("BIRTH_DATE")]
        public string? BirthDate { get; set; } = string.Empty;

        [Column("LAST_NAME1")]
        public string? ParentLastName { get; set; } = string.Empty;

        [Column("FIRST_NAME1")]
        public string? ParentFirstName { get; set; } = string.Empty;

        [Column("QUALIFYING_EVENT_DATE")]
        public string? QualifyingEventDate { get; set; } = string.Empty;

        [Column("ELIGIBILITY_END_DATE")]
        public string? EligibilityEndDate { get; set; } = string.Empty;

        [Column("AFFILIATE_ID")]
        public int? AffiliateId { get; set; }

        [Column("AFFILIATE_NAME")]
        public string? AffiliateName { get; set; } = string.Empty;

        [Column("LabelValue")]
        public string? LabelValue { get; set; } = string.Empty;

        [Column("DisplayValue")]
        public string? DisplayValue { get; set; } = string.Empty;

        [Column("ClientOptionValue")]
        public string? ClientOptionValue { get; set; } = string.Empty;
        [Column("DivisionLevelAccess")]
        public string? DivisionLevelAccess { get; set; } = string.Empty;
    }
}

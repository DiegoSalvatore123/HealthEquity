﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class MLRQuoteGetNewRateModel
    {
        [Key]
        [Column("PlanId")]
        public int PlanId { get; set; }
        [Column("MemberId")]
        public int MemberId { get; set; }
        [Column("Rate")]
        public float Rate { get; set; }
        [Column("CCSId")]
        public int CCSId { get; set; }
    }
}

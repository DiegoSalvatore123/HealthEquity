﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model;

public class GroupUpdateDropDownListModel
{
    [Key]
    public string Code { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}
﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class VoidModel : PlatformModel
    {   
        public int ParticipantId { get; set; }
        [DataType(DataType.Text)]
        public string Reason { get; set; } = string.Empty;
    }
}

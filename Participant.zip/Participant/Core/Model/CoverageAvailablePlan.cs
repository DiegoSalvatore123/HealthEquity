﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class CoverageAvailablePlan
    {
        [Key]
        public string Code { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}

﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class MLRQuoteGetRateModel
    {
        [Key]
        [Column("PlanId")]
        public int PlanId { get; set; }
        [Column("MemberId")]
        public int MemberId { get; set; }
        [Column("NonSmokerRate")]
        public float NonSmokerRate { get; set; }
        [Column("NonSmokerCCSId")]
        public int NonSmokerCCSId { get; set; }
        [Column("SmokerRate")]
        public float SmokerRate { get; set; }
        [Column("SmokerCCSId")]
        public int SmokerCCSId { get; set; }
    }
}

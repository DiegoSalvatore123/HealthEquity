﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Model;

public class GroupUpdateDataResultModel
{
    [Column("PARTICIPANT_ID")]
    public int ParticipantId { get; set; }
    [Column("EMPLOYEE_NUMBER")]
    [DataType(DataType.Text)]
    public string? EmployeeNumber { get; set; }
    [DataType(DataType.Text)]
    public string? Student { get; set; } = string.Empty;
    [Column("KEY_EMPLOYEE")]
    public bool? KeyEmployee { get; set; }
    [Column("SHARE_HOLDER5")]
    public bool? ShareHolder5 { get; set; }
    [Column("HIGHLY_COMP_POP")]
    public bool? HighlyCompPop { get; set; }
    [Column("HIGHLY_COMP_MFSA")]
    public bool? HighlyCompMFSA { get; set; }
    [Column("SALARY_UNDER_25K")]
    public bool? SalaryUnder25K { get; set; }
    [Column("AFFILIATE_ID")] 
    public int? AffiliateId { get; set; }
    [Column("HIRE_DATE")]
    public DateTime? HireDate { get; set; }
    [Column("QUALIFIED_BENEFICIARY")]
    [DataType(DataType.Text)]
    public string? QualifiedBeneficiary { get; set; } = string.Empty;
    [Column("PHONE_NUMBER")]
    [DataType(DataType.Text)]
    public string? PhoneNumber { get; set; } = string.Empty;
    [Column("PAY_SCHEDULE_ID")]
    public int? PayScheduleId { get; set; }
    [Column("FIRST_NAME")]
    [DataType(DataType.Text)]
    public string? FirstName { get; set; } = string.Empty;
    [Column("LAST_NAME")]
    [DataType(DataType.Text)]
    public string? LastName { get; set; } = string.Empty;
    [Column("MIDDLE_INITIAL")]
    [DataType(DataType.Text)]
    public string? MiddleInitial { get; set; } = string.Empty;
    [Column("SOCIAL_SECURITY_NUMBER")]
    [DataType(DataType.Text)]
    public string? SocialSecurityNumber { get; set; } = string.Empty;
    [Column("AFFILIATE_NAME")]
    [DataType(DataType.Text)]
    public string? AffiliateName { get; set; } = string.Empty;
    [DataType(DataType.Text)]
    public string? LabelValue { get; set; } = string.Empty;
    [DataType(DataType.Text)]
    public string? DisplayValue { get; set; } = string.Empty;
    [DataType(DataType.Text)]
    public string? ClientOptionValue { get; set; }
    public int? TotalRecords { get; set; }
    [NotMapped]
    [DataType(DataType.Text)]
    public string? UpdateNew { get; set; } = string.Empty;
}

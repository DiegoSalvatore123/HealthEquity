﻿namespace Core.Model
{
    public class CoverageChangeModel
    {
        public string? OldFixedPremium { get; set; }
        public string? NewFixedPremium { get; set; }
        public int ParticipantId { get; set; }
        public int PlanId { get; set; }
        public string EffectiveDate { get; set; } = string.Empty;
        public string RateType { get; set; } = string.Empty;
        public string PlanName { get; set; } = string.Empty;
    }
}

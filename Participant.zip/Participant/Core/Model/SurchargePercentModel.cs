﻿namespace Core.Model
{
    public class SurchargePercentModel
    {
        public string? SurchargePercent { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Core.Model
{
    public class InfoResultViewModel
    {
        public int ParticipantNewId { get; set; }
        public string? ParticipantId { get; set; } = string.Empty;
        public string? Name { get; set; } = string.Empty;
        public string SocialSecurityNumber { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        [MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;
        [MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [MaxLength(1)]
        public string? MiddleInitial { get; set; } = string.Empty;
        [MaxLength(20)]
        public string? EmployeeNumber { get; set; } = string.Empty;
        public string? HireDate { get; set; } = string.Empty;
        public string BirthDate { get; set; } = string.Empty;
        public string Eligible { get; set; } = string.Empty;
        public string? AffiliateName { get; set; } = string.Empty;
        public string? WaitingStartDate { get; set; } = string.Empty;
        public string? CoverageStartDate { get; set; } = string.Empty;
        [MaxLength(100)]
        public string? EmailAddress { get; set; } = string.Empty;
        [MaxLength(50)]
        public string Address1 { get; set; } = string.Empty;
        [MaxLength(50)]
        public string? Address2 { get; set; } = string.Empty;
        public string? State { get; set; } = string.Empty;
        [MaxLength(10)]
        public string? Zip { get; set; } = string.Empty;
        [MaxLength(20)]
        public string City { get; set; } = string.Empty;
        public string? ClassName { get; set; } = string.Empty;
        public string? ReHireDate { get; set; } = string.Empty;
        [MaxLength(50)]
        public string? PhoneNumber { get; set; } = string.Empty;
        public string AffiliateId { get; set; } = string.Empty;
        public string? EmployeeClassId { get; set; } = string.Empty;
        public string? ParticipantStatus { get; set; } = string.Empty;
        public string? Student { get; set; } = string.Empty;
        public string? RelationShip { get; set; } = string.Empty;
        public string QualifiedBeneficiary { get; set; } = string.Empty;
    }
}

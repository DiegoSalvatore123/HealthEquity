﻿namespace Core.Model
{
    public class PastDueCancellationModel
    {
        public InfoUpdateModel? InfoResult { get; set; }
        public BillingDetailModel? BillingDetail { get; set; }
    }
}

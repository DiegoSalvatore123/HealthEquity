﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class PartialService : IPartialService
    {
        private readonly ILogger<PartialService> _logger;     
        private readonly IUnitOfWork _unitOfWork;
        public PartialService(ILogger<PartialService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public async Task<HttpResponseMessage> GetActivityByPid(ParticipantIdModel model)
        {
            try
            {
                List<ActivityModel>? search = new();
                search = await _unitOfWork.Activity.GetActivityByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Activity by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetActivityFilteringByPid(ParticipantIdModel model)
        {
            try
            {
                List<ActivityModel>? search = new();
                search = await _unitOfWork.Activity.GetActivityFilteringByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Activities by PId: {0}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetDependentByParentPid(ParticipantIdModel model)
        {
            try
            {
                List<DependentModel>? searchDependent = new();
                searchDependent = await _unitOfWork.Dependent.GetDependentByParentPid(model);
                if (searchDependent == null)
                    return Request.CreateResponse<List<DependentModel>?>(HttpStatusCode.OK, null);
                // TODO: Is the above what we want to to? Or empty collection (simplifies logic even more)?

                List<DependentDetailModel>? searchDependentDetail = new();
                foreach (var dependentDetail in searchDependent)
                {
                    searchDependentDetail = await _unitOfWork.DependentDetail.GetDependentDetailByParentPidAndPid(model, dependentDetail.ParticipantId.ToString());
                    // TODO: Why would this happen? Seems like an error case? Why would we have
                    //       dependants with no details?
                    if (searchDependentDetail == null)
                        continue;

                    dependentDetail.DependentDetailModel = searchDependentDetail;
                    foreach (DependentDetailModel dependentDetailModel in dependentDetail.DependentDetailModel)
                    {
                        if (dependentDetailModel.IsTobaccoRated)
                            dependentDetail.HasTabaccoReated = true;
                    }
                }
                return Request.CreateResponse(HttpStatusCode.OK, searchDependent);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Dependent by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetCoverageByPid(ParticipantGetCoverageModel model)
        {           
            try
            {
                List<CoverageModel>? searchCoverage = new();
                searchCoverage = await _unitOfWork.Coverage.GetCoverageByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, searchCoverage);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get coverage by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetSpecificFieldsByPid(ParticipantIdModel model)
        {
            try
            {
                List<SpecificFieldsResultModel>? search = new();
                search = await _unitOfWork.SpecificField.GetSpecificFieldsByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get specific fields by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetCarrierRemittanceByPid(ParticipantIdModel model)
        {
            try
            {
                List<CarrierRemittanceModel>? search = new();
                search = await _unitOfWork.CarrierRemittance.GetCarrierRemittanceByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Carrier Remittance by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetPaymentHistoryByPid(ParticipantIdModel model)
        {
            try
            {
                List<PaymentHistoryModel>? search = new();
                search = await _unitOfWork.PaymentHistory.GetPaymentHistoryByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Carrier Remittance by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public List<string> CheckForBadRequest(CoverageCostModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.PlatformName) || string.IsNullOrWhiteSpace(model.CoverageCode) || string.IsNullOrWhiteSpace(model.PlanId))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            var participantId = model?.GetType()?.GetProperty("ParticipantId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(participantId) || string.IsNullOrWhiteSpace(platformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForBadRequest(ParticipantDependentCoverageModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ParticipantCoverageId) || string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForCLientBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            var clientId = model?.GetType()?.GetProperty("ClientId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(platformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public async Task<HttpResponseMessage> GetDependentCoveragesByParticipantCoverageIdAndClientId(ParticipantDependentCoverageModel model)
        {
            try
            {
                List<ParticipantDependentCoverageResultModel>? searchDependentCoverages = new();
                searchDependentCoverages = await _unitOfWork.DependentCoverage.GetParticipantCoverageByParticipantCoverageIdAndClientId(model.ParticipantCoverageId,model.ClientId,model.PlatformName);
                if (searchDependentCoverages != null && searchDependentCoverages.Any())
                    searchDependentCoverages = (List<ParticipantDependentCoverageResultModel>)searchDependentCoverages.Where(p => p.Relationship != "E").ToList();             
                ParticipantCoveragePlanOptionResultModel? dependentCoveragePlanOption = new();
                dependentCoveragePlanOption = await _unitOfWork.ParticipantCoveragePlanOption.GetParticipantCoveragePlanOption(model.ParticipantCoverageId, model.PlatformName);
                searchDependentCoverages ??= new();
                dependentCoveragePlanOption ??= new();
                var result = new ParticipantDependentCoveragesPlanOptionResultModel
                {
                    planOption = dependentCoveragePlanOption,
                    DependentCoverages = searchDependentCoverages
                };
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Dependent by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetParticipantDependentAddress(InfoModel model)
        {
            try
            {
                CurrentParticipantAddressResultModel? search = new();
                search = await _unitOfWork.ParticipantDependentAddress.GetParticipantDependentAddress(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get dependent address: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetEligibilityTransmissionDetailByPid(ParticipantIdModel model)
        {
            try
            {
                List<EligibilityTransmissionModel>? eligibilityTransmission = new();
                eligibilityTransmission = await _unitOfWork.EligibilityTransmission.GetEligibilityTransmissionDetail(model.PlatformName,model.ParticipantId);
                return Request.CreateResponse(HttpStatusCode.OK, eligibilityTransmission);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Eligibility Transmission Detail by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetAdminFeeByClientId(PlatformModel model)
        {
            try
            {
                List<AdminFeeModel>? adminFee = new();
                adminFee = await _unitOfWork.AdminFee.GetAdminFee(model.PlatformName, model.ClientId);
                return Request.CreateResponse(HttpStatusCode.OK, adminFee);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Admin Fee by Client Id: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetCoverageCost(CoverageCostModel model)
        {
            try
            {
                List<CoverageCostResultModel>? coverageCost = new();
                coverageCost = await _unitOfWork.CoverageCost.GetCoverageCost(model.PlatformName, model.PlanId,model.CoverageCode);
                return Request.CreateResponse(HttpStatusCode.OK, coverageCost);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Admin Fee by Client Id: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetParticipantInfoByPid(ParticipantInfoModel model)
        {
            try
            {
                var participantInfoModel = await _unitOfWork.ParticipantInfo.GetParticipantInfo(model.PlatformName, model.ParticipantId);
                return Request.CreateResponse(HttpStatusCode.OK, participantInfoModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Participant Info By Participant Id: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CoveragesPlans(ParticipantDependentCoverageModel model)
        {
            try
            {
                List<CoveragePlansModel>? searchDependentCoverages = new();
                searchDependentCoverages = await _unitOfWork.CoveragePlans.GetCoveragesPlans(model);
                return Request.CreateResponse(HttpStatusCode.OK, searchDependentCoverages);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Dependent by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class DirectBillService : IDirectBillService
    {
        private readonly ILogger<CobraService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public DirectBillService(ILogger<CobraService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForClientBadRequest(PlatformModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again!");

            return result;
        }
        public async Task<HttpResponseMessage> GetClientAcivePlans(PlatformModel model)
        {
            try
            {
                ClientOptionResultModel? search = new();
                search = await _unitOfWork.ClientOptionAll.GetClientAcivePlans(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetClientPlans(PlatformModel model)
        {
            try
            {
                List<ClientPlansModel>? search = new();
                search = await _unitOfWork.ClientPlans.GetClientPlans(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetClientEventName(PlatformModel model)
        {
            try
            {
                List<GenericUniquePairValue>? search = new();
                search = await _unitOfWork.GenericUniquePairValue.GetClientEventName(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        public async Task<HttpResponseMessage> GetPastDue(SearchModel model)
        {
            try
            {
                List<DBPastDueModel>? dBPastDueModels = new();
                List<DBPastDueResponseModel>? dBPastDueResponseModels = new();
                dBPastDueModels = await _unitOfWork.DBPastDue.GetPastDue(model);

                if (dBPastDueModels != null && dBPastDueModels.Count > 0)
                {
                    dBPastDueResponseModels = dBPastDueModels.GroupBy(p => p.ParticipantID)
                        .Select(g => new DBPastDueResponseModel
                    {
                        ParticipantID = g.Key,
                        FirstName = g.First().FirstName,
                        LastName = g.First().LastName,
                        SocialSecurityNumber = g.First().SocialSecurityNumber,
                        LabelValue = g.First().LabelValue,
                        DisplayValue = g.First().DisplayValue,
                        ClientOptionValue = g.First().ClientOptionValue,
                        ErPaid = g.First().ErPaid,
                        Paid = g.First().Paid,
                        EventName = g.First().EventName,
                        AffiliateName = g.First().AffiliateName,
                        TotalCount = g.First().TotalCount,
                        dBPastDueResponseDetailModels = g.Select(p => new DBPastDueResponseDetailModel
                        {
                            CoverageStart = p.CoverageStart,
                            CoverageEnd = p.CoverageEnd,
                            DueDate = p.DueDate,
                            Amount = p.Amount,
                            Owed = p.Owed,
                            Status = p.Status,
                        }).ToList()
                    })
                    .ToList();
                }
                return Request.CreateResponse(HttpStatusCode.OK, dBPastDueResponseModels);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform GetPastDue: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchInfoToCancel(PastDueInfoModel searchModel)
        {
            try
            {
                PastDueCancellationModel? search = new();
                search = await _unitOfWork.Info.SearchInfoToCancel(searchModel);
                if (search == null)
                    Request.CreateResponse(HttpStatusCode.NoContent, "Data not available");
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search by Pid: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

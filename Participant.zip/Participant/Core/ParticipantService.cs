﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class ParticipantService : IParticipantService
    {
        private readonly ILogger<ParticipantService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public ParticipantService(ILogger<ParticipantService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(SearchModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application while performing the Search. Try again!");

            return result;
        }
        public async Task<HttpResponseMessage> Search(SearchModel searchModel)
        {
            try
            {
                List<SearchResultModel>? search = new();               
                search = await _unitOfWork.Participant.Search(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

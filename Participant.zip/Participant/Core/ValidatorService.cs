﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class ValidatorService : IValidatorService
    {
        private readonly ILogger<ValidatorService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public ValidatorService(ILogger<ValidatorService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(ValidateHireDataModel model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName) || string.IsNullOrWhiteSpace(model.SSN) || string.IsNullOrWhiteSpace(model.HireDate))
            {
                result.Add("There was an error in the Application while performing the Search. Try again!");
            }

            return result;
        }
        public List<string> CheckForBadRequest(ClientOptionModel model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            if (string.IsNullOrWhiteSpace(model.ClientId) ||
                string.IsNullOrWhiteSpace(model.PlatformName) ||
                model.ClientOptionId == 0)
            {
                result.Add("There was an error in the Application while performing the Search. Try again!");
            }

            return result;
        }
        public List<string> CheckForCLientBadRequest(UserClientModel model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
            {
                result.Add("There was an error in the Application. Try again.");
            }

            return result;
        }
        public List<string> CheckForBadRequestSCC(SCCobraEligModel model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName) || string.IsNullOrWhiteSpace(model.Statement.ToString()))
            {
                result.Add("There was an error in the Application while performing the Search. Try again!");
            }

            return result;
        }
        public async Task<HttpResponseMessage> SearchBySSNHireDate(ValidateHireDataModel searchModel)
        {
            try
            {
                RehireValidatorResultModel? search = new();
                search = await _unitOfWork.RehireValidator.SearchBySSNHireDate(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchClientOption(ClientOptionModel searchModel)
        {
            try
            {
                ClientOptionResultModel? model = await _unitOfWork.ClientOptionAll.SearchClientOption(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search client option: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchClientOptionLookup(ClientOptionModel searchModel)
        {
            try
            {
                ClientOptionResultModel? model = await _unitOfWork.ClientOptionAll.SearchClientOptionLookup(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search client option: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> IncludeSCCobraElig(SCCobraEligModel searchModel)
        {
            try
            {
                SCCobraEligViewModel? model = await _unitOfWork.SCCobraElig.IncludeSCCobraElig(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CobraHipaaNotice(UserClientModel searchModel)
        {
            try
            {
                CobraHipaaViewModel? model = await _unitOfWork.CobraHipaa.CobraHipaaNotice(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public List<string> CheckForCLientQEBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            var clientId = model?.GetType()?.GetProperty("ClientId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();
            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(platformName))
            {
                result.Add("There was an error in the Application. Try again.");
            }

            return result;
        }
        public async Task<HttpResponseMessage> QeExtension(QeCodeExtensionModel searchModel)
        {
            try
            {
                QEExtensionModel? model = await _unitOfWork.QEExtension.QEExtension(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, model);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public List<string> CheckForBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            var participantId = model?.GetType()?.GetProperty("ParticipantId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(participantId) || string.IsNullOrWhiteSpace(platformName))
            {
                result.Add("There was an error in the Application. Try again.");
            }

            return result;
        }
        public async Task<HttpResponseMessage> CoveragExisting(ParticipantInfoModel searchModel)
        {
            try
            {
                ClientOptionResultModel? coverageCount = await _unitOfWork.ClientOptionAll.GetCoveragExisting(searchModel.PlatformName, searchModel.ParticipantId ?? "");

                return Request.CreateResponse(HttpStatusCode.OK, coverageCount);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SubmitMLRQuoteItRequest(AvailablePlans model)
        {
            try
            {
                OperationResultModel mlrResut = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(model.PlatformName);
                
                List<MlrRate>? mlrRates = new();
                if (model.IsDependentProcessQE && model.NewMemberCount == 0)  
                {
                    mlrRates = await _unitOfWork.MLRQuoteRate.GetMLRQuoteGetRates(model.PlatformName, model.AvailablePlansClient, model.ParticipantId, model.PlanData, platformConection?.Value!);
                    mlrRates ??= null;
                    if (mlrRates!=null && mlrRates.Count() != model.QuoteRateCount)
                        mlrRates = null;
                }
                GenericUniqueValue? quote = await _unitOfWork.GenericGuidValue.GetMLRQuote(model.PlatformName, model.ClientId, model.UserId, model.QEventDate, model.PlanData, model.MemberData, platformConection?.Value!);

                return Request.CreateResponse(HttpStatusCode.OK, quote);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CheckMLRQuoteItStatus(AvailablePlans model)
        {
            int rateCount = 0;
            try
            {
                ClientOptionResultModel? mlrQuotitData = await _unitOfWork.ClientOptionAll.GetMLRQuotitData(model.PlatformName, model.Guids);
                if (mlrQuotitData != null && mlrQuotitData.OptionValue != null)
                    rateCount = int.Parse(mlrQuotitData.OptionValue);
                return Request.CreateResponse(HttpStatusCode.OK, mlrQuotitData);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetMLRQuoteGetRates(AvailablePlans model)
        {
            try
            {
                List<MlrRate>? mlrRates = new();
                OperationResultModel mlrResut = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(model.PlatformName);

                if (model.RateCount == 1)
                {
                    if (model.NewMemberCount == 0)
                        mlrRates = await _unitOfWork.MLRQuoteRate.GetMLRQuoteGetRates(model.PlatformName, model.AvailablePlansClient, model.ParticipantId, model.PlanData, platformConection?.Value!);
                    else
                        mlrRates = await _unitOfWork.MLRQuoteNewRate.GetMLRQuoteGetNewRates(model.PlatformName, model.ParticipantId, model.Guids!, platformConection?.Value!);
                }

                if (model.QuoteRateCount != mlrRates!.Count())
                {
                    mlrResut.Success = false;
                    await _unitOfWork.GenericUniqueValue.MLRProcessEvent(model.PlatformName, model.ClientId, model.UserId, ConstantValues.MLRFAILED, platformConection?.Value!);
                }
                else
                {
                    mlrResut.Success = true;
                    await _unitOfWork.GenericUniqueValue.MLRProcessEvent(model.PlatformName, model.ClientId, model.UserId, ConstantValues.MLRSUCCEDD, platformConection?.Value!);
                }
                return Request.CreateResponse(HttpStatusCode.OK, mlrResut);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetPlansDates(PlanMLRModel model)
        {
            try
            {
                GenericUniquePairValue? mlrResut = await _unitOfWork.GenericUniquePairValue.GetPlansDates(model);
                return Request.CreateResponse(HttpStatusCode.OK, mlrResut);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
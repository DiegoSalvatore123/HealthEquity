﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class InnerService : IInnerService
    {
        private readonly ILogger<InnerService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public InnerService(ILogger<InnerService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            var participantId = model?.GetType()?.GetProperty("ParticipantId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(participantId) || string.IsNullOrWhiteSpace(platformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }

        public async Task<HttpResponseMessage> SearchPlanNameByPid(ParticipantIdModel model)
        {
            try
            {
                List<PlanModel>? search = new();
                search = await _unitOfWork.QE.SearchPlanNameByPid(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                string message = $"Failed to perform search plan name by pid: {ex}";
                _logger.LogError(message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetEmailQueue(DocumentModel model)
        {
            try
            {
                List<EmailModel>? search = new();
                search = await _unitOfWork.EmailQueue.GetEmailQueue(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                string message = $"Failed to perform search plan name by pid: {ex}";
                _logger.LogError(message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IQERepository
    {
        Task<List<PlanModel>?> SearchPlanNameByPid(ParticipantIdModel participant);
    }
}


﻿
using Core.Model;

namespace Core.Interfaces
{
    public interface ICobraHipaaRepository
    {
        Task<CobraHipaaViewModel?> CobraHipaaNotice(UserClientModel participant);
    }
}

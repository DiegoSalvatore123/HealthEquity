﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IEligibilityEndRepository
    {
        Task<string?> CalculateEligibilityEnd(string platformName, InfoResultModel model);
    }
}

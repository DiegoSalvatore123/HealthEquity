﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDBPastDueRepository
    {
        Task<List<DBPastDueModel>?> GetPastDue(SearchModel model);
    }
}

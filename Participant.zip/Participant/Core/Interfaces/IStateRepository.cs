﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IStateRepository
    {
        Task<List<StateModel>?> GetStates(InfoModel searchModel, [Optional] string platformConection);
    }
}

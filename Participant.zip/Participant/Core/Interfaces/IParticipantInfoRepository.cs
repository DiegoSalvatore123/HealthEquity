﻿using Core.Model;

namespace Core.Interfaces;

public interface IParticipantInfoRepository
{
    Task<ParticipantInfoResultModel?> GetParticipantInfo(string platformName, string participantId);
}
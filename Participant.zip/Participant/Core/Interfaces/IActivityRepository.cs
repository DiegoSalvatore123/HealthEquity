﻿using Core.Model;
namespace Core.Interfaces
{
    public interface IActivityRepository
    {
        Task<List<ActivityModel>?> GetActivityByPid(ParticipantIdModel participant);
        Task<List<ActivityModel>?> GetActivityFilteringByPid(ParticipantIdModel participant);
    }
}


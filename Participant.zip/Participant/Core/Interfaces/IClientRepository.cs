﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IClientRepository
    {
        Task<List<ClientModel>?> SearchClientforEmployerChange(InfoModel model);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IQEExtensionRepository
    {
        Task<QEExtensionModel?> QEExtension(QeCodeExtensionModel qe);
    }
}


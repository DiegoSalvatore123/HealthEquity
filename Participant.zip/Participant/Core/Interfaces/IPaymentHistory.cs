﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IPaymentHistory
    {
        Task<List<PaymentHistoryModel>?> GetPaymentHistoryByPid(ParticipantIdModel participant);
    }
}

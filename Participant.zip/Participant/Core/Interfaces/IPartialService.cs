﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IPartialService
    {
        Task<HttpResponseMessage> GetActivityByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetActivityFilteringByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetCoverageByPid(ParticipantGetCoverageModel model);
        Task<HttpResponseMessage> GetDependentByParentPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetSpecificFieldsByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetCarrierRemittanceByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetPaymentHistoryByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetParticipantDependentAddress(InfoModel model);
        Task<HttpResponseMessage> GetDependentCoveragesByParticipantCoverageIdAndClientId(ParticipantDependentCoverageModel model);
        List<string> CheckForBadRequest(CoverageCostModel model);
        List<string> CheckForBadRequest(ParticipantDependentCoverageModel model);
        Task<HttpResponseMessage> GetEligibilityTransmissionDetailByPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetAdminFeeByClientId(PlatformModel model);
        Task<HttpResponseMessage> GetCoverageCost(CoverageCostModel model);
        Task<HttpResponseMessage> GetParticipantInfoByPid(ParticipantInfoModel model);
        List<string> CheckForBadRequest(Object model);
        List<string> CheckForCLientBadRequest(Object model);
        Task<HttpResponseMessage> CoveragesPlans(ParticipantDependentCoverageModel model);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICoverageAvailablePlanRepository
    {
        Task<List<CoverageAvailablePlan>?> GetCoverage(string platformName, string code);
        Task<List<CoverageAvailablePlan>?> GetCoverageWithPlatformConection(string platformConection, string code);
    }
}

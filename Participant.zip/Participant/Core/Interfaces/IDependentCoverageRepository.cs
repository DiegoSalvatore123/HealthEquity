﻿using Core.Model;

namespace Core.Interfaces;

public interface IDependentCoverageRepository
{
    Task<List<ParticipantDependentCoverageResultModel>?> GetParticipantCoverageByParticipantCoverageIdAndClientId(string participantCoverageId, string clientId, string platformName);
}
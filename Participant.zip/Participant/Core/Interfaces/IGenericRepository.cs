﻿using Core.Util;
using System.Linq.Expressions;

namespace Core.Interfaces
{
    public interface IGenericRepository<T> where T : class
    {
        Task<T?> Get(int id);
        IEnumerable<T> GetAll(Expression<Func<T, bool>>? filter = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string? includeProperties = null);
        T? GetFirstOrDefault(Expression<Func<T, bool>>? filter = null, string? includeProperties = null);
        void Add(T entity);
        void Remove(int id);
        void Remove(T entity);
        Task<List<T>?> ExecuteGeneric(string query, Dictionary<string, string>? sqlParams = null);
        TResult? ExecuteGenericRowSpecificOutput<TResult>(QueryT query, string outPutParameterName, int outPutParameterPosition);
        Task<T?> ExecuteGenericRow(Query query);
        Task<List<T>?> ExecuteGeneric(Query query);
        int Save(T entity);
        void SaveAll(IEnumerable<T> entities);
        void AddAll(IEnumerable<T> entities);
    }
}

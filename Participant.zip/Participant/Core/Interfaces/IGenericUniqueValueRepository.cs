﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface  IGenericUniqueValueRepository
    {
        Task<GenericUniqueValue?> GetPlatformConnection(string platformName);
        Task<GenericUniqueValue?> GetLifeInsuranceRTPlan(string platformName, string planId, string rateType);
        Task<GenericUniqueValue?> GetLifeInsuranceRTPlanWithPlatformConection(string platformConection, string planId, string rateType);
        Task<GenericUniqueValue?> IsFeatureOn(string platformName, string clientId, [Optional] string platformConection);
        Task<GenericUniqueValue?> GetQEExtension(string PlatfiormName, string QualifiedCode, [Optional] string platformConection);
        Task<GenericUniqueValue?> GetPlanType(string platformName, string planId);
        Task<GenericUniqueValue?> GetPlanTypeWithPlatformConection(string platformConection, string planId);
        Task<GenericUniqueValue?> GetPlanOptionConection(string platformConection, string planId);
        Task<GenericUniqueValue?> GetTobaccoUse(string platformConecction, string planId);
        Task<GenericUniqueValue?> GetDirectRateEntry(string platformConecction, string clientId);
        Task<GenericUniqueValue?> GetParticipantCoverageId(string platformName, int participantId, int planId, string effectiveDate);
        Task<GenericUniqueValue?> GetTerminationCoverageDate(string platformName, int participantId, int planId, string effectiveDate);
        Task<GenericUniqueValue?> GetPreferredLanguage(string platformName, string clientId, [Optional] string platformConection);
        Task MLRProcessEvent(string platformName, string clientID, string userId, string message, [Optional] string platformConection);
    }
}

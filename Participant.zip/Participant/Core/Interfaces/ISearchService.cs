﻿using Core.Model;
namespace Core.Interfaces
{
    public interface ISearchService
    {
        Task<HttpResponseMessage> SearchByPid(InfoModel searchModel);
        List<string> CheckForBadRequest(InfoModel model);
        List<string> CheckForBadRequest(GroupUpdateSearchModel model);
        List<string> CheckForBadRequest(SearchModel model);
        Task<HttpResponseMessage> SearchInfoComponent(InfoModel searchModel);
        Task<HttpResponseMessage> SearchDisability(InfoModel model);
        Task<HttpResponseMessage> SearchEmployerChangeInfo(InfoModel model);
        Task<HttpResponseMessage> GetUpdateGroupData(GroupUpdateSearchModel model);
    }
}

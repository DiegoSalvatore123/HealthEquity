﻿using Core.Model;
namespace Core.Interfaces
{
    public interface  ITransactionRepository
    {
        Task<OperationResultModel> Insert(ParticipantInsertModel participantInsertModel);
        Task<OperationResultModel> UpdateDisability(DisabilityUpdateModel model);
        Task<OperationResultModel> UpdateEmployerChange(EmployerChangeUpdateModel model);
        Task<OperationResultModel> CreateAddress(AddressModel insertModel);
        Task<CoverageChangeResultModel> UpdateCoverageChange(CoverageChangeAvailablePlansModel model, string platformConnection);
        Task<OperationResultModel> InsertTakeOver(InfoSessionModel searchModel);
        Task<OperationResultModel> InsertProcessQE(InfoSessionModel searchModel);
        Task<OperationResultModel> InsertDependentProcessQE(DependentProcessQEModel searchModel, string? preferredLanguage, ParticipantPromotedModel? participantPromoted);
        Task<OperationResultModel> UpdateGroup(UpdateModel searchModel);
        Task<OperationResultModel> Update(InfoSaveUpdateModel searchModel);
        Task<OperationResultModel> QueueAch(VoidModel searchModel);
        Task<OperationResultModel> CoverageAcceptable(CoverageAcceptable model);
    }
}

﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IRelationRepository
    {
        Task<List<RelationModel>?> GetRelations(InfoModel searchModel, [Optional] string platformConection);
    }
}

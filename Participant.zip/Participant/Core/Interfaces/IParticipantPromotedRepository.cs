﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IParticipantPromotedRepository
    {
        Task<ParticipantPromotedModel?> GetParticipantPromoted(string socialSecurityNumber, string participantId, string clientId, string platformName, [Optional] string platformConection);
    }
}

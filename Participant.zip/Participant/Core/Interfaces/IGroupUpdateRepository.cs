﻿using Core.Model;

namespace Core.Interfaces;

public interface IGroupUpdateRepository
{
    Task<GroupUpdateModel?> GetByIdNumber(string idNumber, string platformName);
}

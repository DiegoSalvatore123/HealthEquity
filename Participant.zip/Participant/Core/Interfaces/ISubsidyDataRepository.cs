﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ISubsidyDataRepository
    {
        Task<SubsidyDataModel?> ExecuteCoveragePLS(string platformName, string xml, string userId);
    }
}

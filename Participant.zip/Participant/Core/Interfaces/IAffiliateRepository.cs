﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IAffiliateRepository
    {
        Task<List<AffiliateModel>?> GetDivisionLocations(InfoModel searchModel, [Optional] string platformConection);
        Task<AffiliateModel?> GetAffiliateName(AffiliateInfoModel searchModel, [Optional] string platformConecction);
    }
}

﻿using Core.Model;
using Core.Util;

namespace Core.Interfaces
{
    public interface IVoidValidationRepository
    {
        Task<OperationResultModel?> CheckIfParticipantExist(VoidModel voidModel);
    }
}

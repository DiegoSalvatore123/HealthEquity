﻿namespace Core.Interfaces
{
    public interface ICobraConfig
    {
        Task<string?> GetCLProd(string platform);
        Task<string?> GetResource(string resource);
    }
}

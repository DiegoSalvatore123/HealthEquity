﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDirectBillService
    {
        Task<HttpResponseMessage> GetClientAcivePlans(PlatformModel model);
        Task<HttpResponseMessage> GetPastDue(SearchModel model);
        List<string> CheckForClientBadRequest(PlatformModel model);
        Task<HttpResponseMessage> GetClientPlans(PlatformModel model);
        Task<HttpResponseMessage> GetClientEventName(PlatformModel model);
        Task<HttpResponseMessage> SearchInfoToCancel(PastDueInfoModel searchModel);

    }
}

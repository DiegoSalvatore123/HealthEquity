﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IEmailQueueRepository
    {
        Task<List<EmailModel>?> GetEmailQueue(DocumentModel secureId);
    }
}


﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IEmailNotificationRepository
    {
        Task Add(EmailNotificationModel model, string platformName);
    }
}

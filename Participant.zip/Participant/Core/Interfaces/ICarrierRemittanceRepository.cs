﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICarrierRemittanceRepository
    {
        Task<List<CarrierRemittanceModel>?> GetCarrierRemittanceByPid(ParticipantIdModel participant);
    }
}

﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IDependentSearchRepository
    {
        Task<List<DependentResultModel>?> SearchDependentBySSN(SearchModel searchModel, [Optional] string platformConection);
    }
}

﻿using Core.Model;

namespace Core.Interfaces;

public interface ICoverageCostRepository
{
    Task<List<CoverageCostResultModel>?> GetCoverageCost(string platformName, string planId, string coverageCode);
}
﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDirectBillSPService
    {
        List<string> CheckForClientBadRequest(PlatformModel model);
        Task<HttpResponseMessage> GetImpendingMedicareReport(PlatformModel voidModel);
    }
}

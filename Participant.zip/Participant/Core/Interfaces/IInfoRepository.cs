﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IInfoRepository
    {
        Task<InfoResultModel?> SearchByPid(InfoModel searchModel);
        Task<InfoUpdateModel?> SearchInfoComponent(InfoModel searchModel, [Optional] string platformConecction);
        Task<PastDueCancellationModel?> SearchInfoToCancel(PastDueInfoModel searchModel);
    }
}


﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IClientPlansRepository
    {
        Task<List<ClientPlansModel>?> GetClientPlans(PlatformModel model);
        Task<List<ClientPlansModel>?> GetClientCobraPlans(PlatformModel model);
    }
}

﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IAvailablePlanRepository
    {
        Task<List<AvailablePlansClientResult>?> CoveragePlanByClientId(CoveragePlanDataModel planModel, [Optional] string platformConection);
    }
}

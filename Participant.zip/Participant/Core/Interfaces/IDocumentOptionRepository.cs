﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IDocumentOptionRepository
    {
        Task<List<DocumentOptionModel>?> GetDocumentOptionById(string platformName, List<EmailReSendModel> email, [Optional] string platformConection);
    }
}

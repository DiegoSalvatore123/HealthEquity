﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICasesRepository
    {
        Task<CasesModel?> GetCases(int pId, string platformName);
    }
}

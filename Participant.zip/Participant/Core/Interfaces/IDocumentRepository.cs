﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDocumentRepository
    {
        Task<DocumentResultModel?> GetDocument(DocumentModel secureId);
    }
}


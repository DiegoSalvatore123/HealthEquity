﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICobraService
    {
        Task<HttpResponseMessage> GetEmployeeCounts(PlatformModel model);
        List<string> CheckForClientBadRequest(PlatformModel model);
        Task<HttpResponseMessage> GetClientPlans(PlatformModel model);
        Task<HttpResponseMessage> SearchDependentBySSN(SearchModel model);
    }
}

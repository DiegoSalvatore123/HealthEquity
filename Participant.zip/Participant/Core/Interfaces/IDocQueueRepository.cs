﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDocQueueRepository
    {
        Task<DocQueueModel?> GetDocQueue(int pId, string platformName);
    }
}

﻿namespace Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IActivityRepository Activity { get; }
        IBillingDetailRepository BillingDetail { get; }
        ICoverageRepository Coverage { get; }
        IDependentDetailRepository DependentDetail { get; }
        IDependentRepository Dependent { get; }
        IDependentSearchRepository DependentSearch { get; }
        IDocumentRepository Document { get; }
        IInfoRepository Info { get; }
        ICarrierRemittanceRepository CarrierRemittance { get; }
        IPaymentHistory PaymentHistory { get; }
        IParticipantRepository Participant { get; }
        IQERepository QE { get; }
        IRemoveQERepository RemoveQE { get; }
        IRemoveQEDetailRepository RemoveQEDetail { get; }
        ISystemSettingRepository SystemSetting { get; }
        IEmailNotificationRepository EmailNotification { get; }
        ISpecificFieldsRepository SpecificField { get; }
        ISubsidyRepository Subsidy { get; }
        IStateRepository State { get; }
        IRelationRepository Relation { get; }
        IAffiliateRepository Affiliate { get; }
        IParticipantPromotedRepository ParticipantPromoted { get; }
        IQualifyingEventTypeRepository QualifyingEventType { get; }
        IEmployeeClassRepository EmployeeClass { get; }
        IValidatorRepository RehireValidator { get; }
        IClientOptionAllRepository ClientOptionAll { get; }
        ITransactionRepository ParticipantTransaction { get; }
        ICasesRepository Cases { get; }
        IPaymentRepository Payments { get; }
        IBankCheckRepository BankCheck { get; }
        IVoidRepository Void { get; }
        IVoidValidationRepository VoidCheck { get; }
        ISurchargePercentRepository SurchargePercent { get; }
        IEligibilityEndRepository EligibilityEnd { get; }
        ICustomFieldDomainRepository CustomFieldDomain { get; }
        IClientRepository Client { get; }
        IParticipantCoverageRepository ParticipantCoverage { get; }
        IDocQueueRepository DocQueue { get; }
        IAvailablePlanRepository AvailablePlan { get; }
        IGenericUniqueValueRepository GenericUniqueValue { get; }
        ICoverageAvailablePlanRepository GenericPaireValue { get; }
        IQEPlanComponentRepository QEPlanComponent { get; }
        ISCCobraEligRepository SCCobraElig { get; }
        ICobraHipaaRepository CobraHipaa { get; }
        IDependentCoverageRepository DependentCoverage { get; }
        IParticipantCoveragePlanOptionRepository ParticipantCoveragePlanOption { get; set; }
        IParticipantDependentAddressRepository ParticipantDependentAddress { get; set; }
        IEligibilityTransmissionRepository EligibilityTransmission { get; set; }
        IQEExtensionRepository QEExtension { get; set; }
        IAdminFeeRepository AdminFee { get; set; }
        ICoverageCostRepository CoverageCost { get; set; }
        IParticipantInfoRepository ParticipantInfo { get; set; }
        IPlanBenefitRepository PlanBenefit { get; set; }
        ISubsidyDataRepository SubsidyData { get; set; }
        IGroupUpdateDataRepository GroupUpdateData { get; set; }
        IGroupUpdateDropDownListRepository GroupUpdateDropDownList { get; set; }
        IGroupUpdateRepository GroupUpdate { get; set; }
        IEmailQueueRepository EmailQueue { get; set; }
        IDocumentOptionRepository DocumentOption { get; set; }
        IClientPlansRepository ClientPlans { get; set; }
        IDBPastDueRepository DBPastDue { get; set; }
        IDBImpendingMedicareReportRepository DBImpendingMedicareReport { get; set; }
        IGenericUniquePairValueRepository GenericUniquePairValue { get; set; }
        ICoverageErrorRepository CoverageError { get; set; }
        IMLRQuoteRateRepository MLRQuoteRate { get; set; }
        IMLRQuoteNewRateRepository MLRQuoteNewRate { get; set; }
        ICoveragePlansRepository CoveragePlans { get; set; }
        IGenericGuidValueRepository GenericGuidValue { get; }
    }
}
 
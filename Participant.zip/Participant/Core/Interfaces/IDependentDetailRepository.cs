﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDependentDetailRepository
    {
        Task<List<DependentDetailModel>?> GetDependentDetailByParentPidAndPid(ParticipantIdModel participant, string parentParticipantId);
    }
}

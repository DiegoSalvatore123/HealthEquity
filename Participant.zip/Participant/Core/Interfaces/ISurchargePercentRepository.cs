﻿using Core.Model;

namespace Core.Interfaces
{
    public  interface ISurchargePercentRepository
    {
        Task<SurchargePercentModel?> SearchSurchargePercent(InfoModel model);
    }
}

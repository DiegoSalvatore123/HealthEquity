﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IParticipantCoverageRepository
    {
        Task<ParticipantCoverageModel?> GetParticipantCoverage(int pId, string platformName);
    }
}

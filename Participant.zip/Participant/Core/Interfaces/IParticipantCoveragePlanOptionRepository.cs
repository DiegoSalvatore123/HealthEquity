﻿using Core.Model;

namespace Core.Interfaces;

public interface IParticipantCoveragePlanOptionRepository
{
    Task<ParticipantCoveragePlanOptionResultModel?> GetParticipantCoveragePlanOption(string participantCoverageId, string platformName);
}
﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ISystemSettingRepository
    {
        Task<SystemSettingModel?> GetSystemSettingByName(string settingName, string platformName);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ITransactionService
    {
        Task<HttpResponseMessage> Insert(ParticipantInsertModel model);
        Task<HttpResponseMessage> VoidParticipant(VoidModel voidModel);
        Task<OperationResultModel?> CheckForOpenCases(int pId, string platform);
        Task<OperationResultModel?> CheckForPayment(int pId, string platform);
        Task<OperationResultModel?> CheckForBankCheck(int pId, string platform);
        Task<OperationResultModel?> CheckForParticipantNotFound(VoidModel voidModel);
        Task<HttpResponseMessage> UpdateDisability(DisabilityUpdateModel model);
        Task<HttpResponseMessage> UpdateEmployerChange(EmployerChangeUpdateModel model);
        Task<HttpResponseMessage> InsertAddress(AddressModel searchModel);
        Task<HttpResponseMessage> UpdateCoverageChange(CoverageChangeAvailablePlansModel model);
        Task<HttpResponseMessage> InsertTakeOver(InfoSessionModel searchModel);
        Task<HttpResponseMessage> InsertProcessQE(InfoSessionModel searchModel);
        Task<HttpResponseMessage> InsertDependentProcessQE(InfoSessionModel searchModel);
        Task<HttpResponseMessage> UpdateGroup(UpdateModel searchModel);
        List<string> CheckForBadRequest(Object model);
        Task<HttpResponseMessage> Update(InfoSaveUpdateModel updateModel);
        Task<HttpResponseMessage> CoverageAcceptable(CoverageAcceptable model);
    }
}

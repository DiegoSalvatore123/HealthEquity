﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IRemoveQEDetailRepository
    {
        Task<RemoveQEDetail?> GetRemoveQEDetailByPid(RemoveQEModel model);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ISubsidyRepository
    {
        Task<List<SubsidyResultModel>> GetSubsidybyPid(ParticipantIdModel participant);
    }
}


﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface ISpecificFieldsRepository
    {
        Task<List<SpecificFieldsResultModel>?> GetSpecificFieldsByPid(ParticipantIdModel participant, [Optional] string platformConecction);
        Task<List<SpecificFieldsResultModel>?> GetSpecificFieldsByClientid(UserClientModel customer, [Optional] string platformConecction);
    }
}

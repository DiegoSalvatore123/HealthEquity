﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IValidatorRepository
    {
        Task<RehireValidatorResultModel?> SearchBySSNHireDate(ValidateHireDataModel searchModel);
    }
}
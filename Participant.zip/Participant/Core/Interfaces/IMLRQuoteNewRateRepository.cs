﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IMLRQuoteNewRateRepository
    {
        Task<List<MlrRate>?> GetMLRQuoteGetNewRates(string PlatformName, string participantId, string ProcessIdentifier, [Optional] string platformConection);
    }
}

﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IClientOptionAllRepository
    {
        Task<ClientOptionResultModel?> SearchClientOption(ClientOptionModel model, [Optional] string platformConecction);
        Task<ClientOptionResultModel?> SearchClientOptionLookup(ClientOptionModel model, [Optional] string platformConection);
        Task<ClientOptionResultModel?> GetEmployeeCounts(PlatformModel model);
        Task<ClientOptionResultModel?> GetClientAcivePlans(PlatformModel model);
        Task<ClientOptionResultModel?> GetCafePlan(string platformName, int planID, [Optional] string platformConection);
        Task<ClientOptionResultModel?> GetCoveragError(string PlatformName, string participantId, [Optional] string platformConection);
        Task<ClientOptionResultModel?> GetCoveragErrorQE(string PlatformName, string participantId, [Optional] string platformConection);
        Task<ClientOptionResultModel?> GetCoveragExisting(string PlatformName, string participantId, [Optional] string platformConection);
        Task<ClientOptionResultModel?> GetMLRQuotitData(string PlatformName, string ProcessIdentifier, [Optional] string platformConection);
    }
}

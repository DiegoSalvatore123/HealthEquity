﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IMLRQuoteRateRepository
    {
        Task<List<MlrRate>?> GetMLRQuoteGetRates(string PlatformName, List<AvailablePlansClientResultModel>? AvailablePlans, string participantId, string planData, [Optional] string platformConection);
    }
}

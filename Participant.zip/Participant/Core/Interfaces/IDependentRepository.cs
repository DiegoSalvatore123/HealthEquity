﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IDependentRepository
    {
        Task<List<DependentModel>?> GetDependentByParentPid(ParticipantIdModel participant, [Optional] string platformConection);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IRemoveQERepository
    {
        Task<OperationResultModel?> RemoveQE(RemoveQEModel removeQEModel);
    }
}

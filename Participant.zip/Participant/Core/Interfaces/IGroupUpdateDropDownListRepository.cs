﻿using Core.Model;

namespace Core.Interfaces;

public interface IGroupUpdateDropDownListRepository
{
    Task<List<GroupUpdateDropDownListModel>?> GetBoolean(string tableName, string colName, string platformName);
    Task<List<GroupUpdateDropDownListModel>?> GetAffiliate(string clientId, string divisionLevelAccess, string affiliateString, string platformName);
    Task<List<GroupUpdateDropDownListModel>?> GetSchedule(string clientId, string platformName);
}
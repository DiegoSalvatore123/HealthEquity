﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IParticipantRepository
    {
        Task<List<SearchResultModel>?> Search(SearchModel searchModel);
    }
}


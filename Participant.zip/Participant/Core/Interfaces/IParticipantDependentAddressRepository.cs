﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IParticipantDependentAddressRepository
    {
        Task<CurrentParticipantAddressResultModel?> GetParticipantDependentAddress(InfoModel participantDependent);
    }
}

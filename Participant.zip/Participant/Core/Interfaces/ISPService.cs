﻿using Core.Model;
 namespace Core.Interfaces
{
    public interface ISPService
    {
        Task<HttpResponseMessage> GetSubsidybyPid(ParticipantIdModel model);
        Task<HttpResponseMessage> GetBilling(ParticipantIdModel model);
        Task<HttpResponseMessage> RemoveQE(RemoveQEModel model);
        List<string> CheckForBadRequest(ParticipantIdModel model);
        List<string> CheckForBadRequestRemoveQE(RemoveQEModel model);
        List<string> CheckForConverageBadRequest(CoveragePlanDataModel model);
        Task<HttpResponseMessage> CoveragePlanByClientId(CoveragePlanDataModel model);
        Task<HttpResponseMessage> CheckFeature(CheckFeatureModel model);
        Task<HttpResponseMessage> QueueAch(VoidModel voidModel);
    }
}

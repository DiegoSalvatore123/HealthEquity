﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IGenericGuidValueRepository
    {
        Task<GenericUniqueValue?> GetMLRQuote(string platformName, string clientID, string userId, string qualifyingDate, string planData, string memberData, [Optional] string platformConection);
    }
}

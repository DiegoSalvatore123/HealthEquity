﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IVoidRepository
    {
        Task<int> UpdateParticipant(VoidModel voidModel);
    }
}

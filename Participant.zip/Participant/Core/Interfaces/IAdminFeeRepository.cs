﻿using Core.Model;

namespace Core.Interfaces;

public interface IAdminFeeRepository
{
    Task<List<AdminFeeModel>?> GetAdminFee(string platformName, string clientId);
}
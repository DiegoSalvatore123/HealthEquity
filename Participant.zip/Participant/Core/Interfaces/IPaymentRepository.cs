﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IPaymentRepository
    {
        Task<PaymentModel?> GetPayment(int pId, string platformName);
    }
}

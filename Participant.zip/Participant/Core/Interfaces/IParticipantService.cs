﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IParticipantService
    {
        Task<HttpResponseMessage> Search(SearchModel searchModel);
        List<string> CheckForBadRequest(SearchModel model);
    }
}

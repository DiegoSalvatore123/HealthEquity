﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICollectionService
    {
        Task<HttpResponseMessage> GetStates(InfoModel searchMode);
        Task<HttpResponseMessage> GetEmployeeClasses(InfoModel searchMode);
        Task<HttpResponseMessage> GetDivisionLocations(InfoModel searchMode);
        Task<HttpResponseMessage> GetQualifyingEventType(QualifyingEventTypeModel model);
        List<string> CheckForBadRequest(InfoModel model);
        List<string> CheckForBadRequest(QualifyingEventTypeModel model);
    }
}

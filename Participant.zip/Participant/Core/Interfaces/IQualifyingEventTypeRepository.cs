﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IQualifyingEventTypeRepository
    {
        Task<List<QeMetaDatas>?> GetQualifyingEventType(QualifyingEventTypeModel model);
    }
}

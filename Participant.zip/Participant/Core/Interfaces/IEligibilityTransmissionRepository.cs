﻿using Core.Model;

namespace Core.Interfaces;

public interface IEligibilityTransmissionRepository
{
    Task<List<EligibilityTransmissionModel>?> GetEligibilityTransmissionDetail(string platformName, string participantId);
}
﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICoveragePlansRepository
    {
        Task<List<CoveragePlansModel>?> GetCoveragesPlans(ParticipantDependentCoverageModel participant);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDocumentService
    {
        Task<HttpResponseMessage> GetDocument(DocumentModel secureId);
        List<string> CheckForBadRequest(DocumentModel documentModel);
    }
}

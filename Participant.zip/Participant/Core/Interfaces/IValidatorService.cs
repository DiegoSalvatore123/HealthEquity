﻿using Core.Model;
namespace Core.Interfaces
{
    public interface IValidatorService
    {
        Task<HttpResponseMessage> SearchBySSNHireDate(ValidateHireDataModel searchModel);
        Task<HttpResponseMessage> SearchClientOption(ClientOptionModel searchModel);
        List<string> CheckForBadRequest(ValidateHireDataModel model);
        List<string> CheckForBadRequestSCC(SCCobraEligModel model);
        List<string> CheckForCLientBadRequest(UserClientModel model);
        Task<HttpResponseMessage> IncludeSCCobraElig(SCCobraEligModel searchModel);
        List<string> CheckForBadRequest(ClientOptionModel model);
        Task<HttpResponseMessage> CobraHipaaNotice(UserClientModel searchModel);
        Task<HttpResponseMessage> SearchClientOptionLookup(ClientOptionModel searchModel);
        List<string> CheckForCLientQEBadRequest(Object model);
        Task<HttpResponseMessage> QeExtension(QeCodeExtensionModel searchModel);
        List<string> CheckForBadRequest(Object model);
        Task<HttpResponseMessage> CoveragExisting(ParticipantInfoModel searchModel);
        Task<HttpResponseMessage> SubmitMLRQuoteItRequest(AvailablePlans searchModel);
        Task<HttpResponseMessage> CheckMLRQuoteItStatus(AvailablePlans model);
        Task<HttpResponseMessage> GetMLRQuoteGetRates(AvailablePlans model);
        Task<HttpResponseMessage> GetPlansDates(PlanMLRModel model);
    }
}

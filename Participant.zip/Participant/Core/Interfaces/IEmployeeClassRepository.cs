﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface IEmployeeClassRepository
    {
        Task<List<EmployeeClassModel>?> GetEmployeeClasses(InfoModel searchModel, [Optional] string platformConection);
    }
}

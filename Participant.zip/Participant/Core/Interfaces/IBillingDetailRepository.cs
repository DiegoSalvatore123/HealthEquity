﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IBillingDetailRepository
    {
        Task<BillingDetailModel> GetBillingDetail(ParticipantIdModel participant);
    }
}


﻿using Core.Model;

namespace Core.Interfaces;

public interface IGroupUpdateDataRepository
{
    Task<List<GroupUpdateDataResultModel>> GetData(GroupUpdateModel groupUpdateModel, GroupUpdateSearchModel groupUpdateDataModel);
}
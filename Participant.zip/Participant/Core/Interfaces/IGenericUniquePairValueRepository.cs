﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IGenericUniquePairValueRepository
    {
        Task<List<GenericUniquePairValue>?> GetClientEventName(PlatformModel model);
        Task<GenericUniquePairValue?> GetPlansDates(PlanMLRModel model);
    }
}

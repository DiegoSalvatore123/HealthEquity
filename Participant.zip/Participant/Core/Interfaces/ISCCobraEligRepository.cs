﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ISCCobraEligRepository
    {
        Task<SCCobraEligViewModel?> IncludeSCCobraElig(SCCobraEligModel contract);
    }
}

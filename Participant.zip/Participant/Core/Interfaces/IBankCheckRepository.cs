﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IBankCheckRepository
    {
        Task<BankCheck?> GetBankCheck(int pId, string platformName);
    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IDBImpendingMedicareReportRepository
    {
        Task<List<DBImpendingMedicareReportModel>?> GetImpendingMedicareReport(PlatformModel model);
    }
}

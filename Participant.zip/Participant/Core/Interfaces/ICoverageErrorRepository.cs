﻿using Core.Model;

namespace Core.Interfaces
{
    public interface ICoverageErrorRepository
    {
        Task<List<CoverageErrorModel>?> GetCoverageError(string participantId, string platformName);
        Task<List<CoverageErrorModel>?> GetCoverageErrorQE(string participantId, string platformName);

    }
}

﻿using Core.Model;

namespace Core.Interfaces
{
    public interface IQEPlanComponentRepository
    {
        Task<QEPlanComponentModel?> GetQEPlanComponent(int planId, string PlatformName, string isLifeInsuranceRTPlan);
        Task<QEPlanComponentModel?> GetQEPlanComponentWithPlatformConection(int planId, string platformConection, string isLifeInsuranceRTPlan);
    }
}

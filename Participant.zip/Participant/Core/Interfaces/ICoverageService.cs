﻿
using Core.Model;

namespace Core.Interfaces
{
    public interface ICoverageService
    {
        Task<HttpResponseMessage> CoverageError(ParticipantInfoModel searchModel);
        Task<HttpResponseMessage> CoverageErrorQE(ParticipantInfoModel searchModel);

        List<string> CheckForBadRequest(Object model);
    }
}

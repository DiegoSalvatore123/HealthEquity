﻿using Core.Model;
 
namespace Core.Interfaces
{
    public interface IInnerService
    {
        Task<HttpResponseMessage> SearchPlanNameByPid(ParticipantIdModel model);
        List<string> CheckForBadRequest(Object model);
        Task<HttpResponseMessage> GetEmailQueue(DocumentModel model);
    }
}

﻿using Core.Model;
using System.Runtime.InteropServices;

namespace Core.Interfaces
{
    public interface ICustomFieldDomainRepository
    {
        Task<List<CustomFieldDomain>?> GetSpecificFieldsByPid(string platformName, int customField, [Optional] string platformConection);
    }
}

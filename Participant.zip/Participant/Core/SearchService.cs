﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class SearchService: ISearchService
    {
        private readonly ILogger<SearchService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public SearchService(ILogger<SearchService> logger,  IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(InfoModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForBadRequest(GroupUpdateSearchModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.GroupUpdateIdNumber) || string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForBadRequest(SearchModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application while performing the Search. Try again!");

            return result;
        }
        public async Task<HttpResponseMessage> SearchByPid(InfoModel searchModel)
        {
            try
            {
                InfoResultModel? search = new();
                search = await _unitOfWork.Info.SearchByPid(searchModel);
                if (search == null)               
                    Request.CreateResponse(HttpStatusCode.NoContent, "Participant not available");               
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search by Pid: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchInfoComponent(InfoModel searchModel)
        {
            try
            {
                InfoUpdateModel? participantToUpdate = new();
              
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(searchModel.PlatformName);
                participantToUpdate = await _unitOfWork.Info.SearchInfoComponent(searchModel, platformConection?.Value!);
                var participantId = new ParticipantIdModel
                {
                    ParticipantId = searchModel.ParticipantId,
                    PlatformName = searchModel.PlatformName,
                };
                if (string.IsNullOrEmpty(searchModel.ParticipantId))
                {
                    var clientId = new UserClientModel
                    {
                        ClientId = searchModel.ClientId,
                        PlatformName = searchModel.PlatformName,
                    };
                    participantToUpdate!.ParticipantSpecificFields = await _unitOfWork.SpecificField.GetSpecificFieldsByClientid(clientId, platformConection?.Value!);
                }
                else
                    participantToUpdate!.ParticipantSpecificFields = await _unitOfWork.SpecificField.GetSpecificFieldsByPid(participantId, platformConection?.Value!);
                if (participantToUpdate.ParticipantSpecificFields != null && participantToUpdate.ParticipantSpecificFields.Count > 0)
                {
                    foreach (SpecificFieldsResultModel model in participantToUpdate.ParticipantSpecificFields)
                    {
                        if (model.HasDomainList == 1 || model.HasValidation)
                            model.CustomFieldDomain = await _unitOfWork.CustomFieldDomain.GetSpecificFieldsByPid(searchModel.PlatformName, model.CustomFieldId, platformConection?.Value!);
                    }
                }
                if (!string.IsNullOrEmpty(searchModel.ParticipantId))
                    participantToUpdate.Dependents = await _unitOfWork.Dependent.GetDependentByParentPid(participantId, platformConection?.Value!);

                participantToUpdate.States = await _unitOfWork.State.GetStates(searchModel, platformConection?.Value!);
                participantToUpdate.Relations = await _unitOfWork.Relation.GetRelations(searchModel, platformConection?.Value!);
                participantToUpdate.EmployeeClasses = await _unitOfWork.EmployeeClass.GetEmployeeClasses(searchModel, platformConection?.Value!);
                participantToUpdate.EmployeeClasses?.Insert(0,
                    new EmployeeClassModel
                    {
                        EmployeeClassId = 0,
                        ClassName = "Please Select"
                    });
                participantToUpdate.Divisions = await _unitOfWork.Affiliate.GetDivisionLocations(searchModel, platformConection?.Value!);
                participantToUpdate.Divisions?.Insert(0,
                    new AffiliateModel
                    {
                        AffiliateId = 0,
                        AffiliateName = "Please Select"
                    });
                ClientOptionModel clientOptionId = new()
                {
                    ClientOptionId = 401,
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName
                };
                var cOptionLookUp = await _unitOfWork.ClientOptionAll.SearchClientOptionLookup(clientOptionId, platformConection?.Value!);
                if (cOptionLookUp != null && cOptionLookUp.OptionValue == "1")
                    participantToUpdate.ShowCoverage = true;

                if (participantToUpdate == null)
                    Request.CreateResponse(HttpStatusCode.NoContent, "Data not available");
                return Request.CreateResponse(HttpStatusCode.OK, participantToUpdate);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search by Pid: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchDisability(InfoModel model)
        {
            try
            {
                DisabilityModel? search = new();
                var participantInfo = await _unitOfWork.Info.SearchByPid(model);
                search.ParticipantInfo = participantInfo;
                var disabilitySurchargePercent = await _unitOfWork.SurchargePercent.SearchSurchargePercent(model);
                search.SurchargePercent = disabilitySurchargePercent!.SurchargePercent;
                var disabilityEligibilityEnd = await _unitOfWork.EligibilityEnd.CalculateEligibilityEnd(model.PlatformName, participantInfo!);
                search.EligibilityEnd = disabilityEligibilityEnd;
                if (search == null)
                    Request.CreateResponse(HttpStatusCode.NoContent, "Participant disability data not available");
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Disability data: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchEmployerChangeInfo(InfoModel model)
        {
            try
            {
                EmployerChangeModel? search = new();
                var participantInfo = await _unitOfWork.Info.SearchByPid(model);
                search.ParticipantInfo = participantInfo;
                var clientList = await _unitOfWork.Client.SearchClientforEmployerChange(model);
                search.ClientList = clientList!;
                search.MessageList = new List<string>(); 
                var payment = await _unitOfWork.Payments.GetPayment(Convert.ToInt32(model.ParticipantId!), model.PlatformName);
                if (payment != null && payment.ParymentId != 0)
                    search.MessageList.Add(ConstantValues.PARTICIPANTPAYMENTERROR);
                var bankCheck = await _unitOfWork.BankCheck.GetBankCheck(Convert.ToInt32(model.ParticipantId!), model.PlatformName);
                if (bankCheck != null && bankCheck.CheckId != 0)
                    search.MessageList.Add(ConstantValues.BANCKCHECKERROR);
                var participantCoverage = await _unitOfWork.ParticipantCoverage.GetParticipantCoverage(Convert.ToInt32(model.ParticipantId!), model.PlatformName);
                if (participantCoverage != null && participantCoverage.ParticipantCoverageId != 0)
                    search.MessageList.Add(ConstantValues.PARTICIPANTCOVERAGEERROR);
                var docQueue = await _unitOfWork.DocQueue.GetDocQueue(Convert.ToInt32(model.ParticipantId!), model.PlatformName);
                if (docQueue != null && docQueue.DocId != 0)
                    search.MessageList.Add(ConstantValues.DOCQUEUEERROR);
                if (search == null)
                    Request.CreateResponse(HttpStatusCode.NoContent, "Participant Employer change data not available");
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Employer change data: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetUpdateGroupData(GroupUpdateSearchModel model)
        {
            try
            {
                GroupUpdateResultModel groupUpdateResultModel = new();
                List<GroupUpdateDropDownListModel>? dropDownList = new();
                var updateGroup = await _unitOfWork.GroupUpdate.GetByIdNumber(model.GroupUpdateIdNumber!, model.PlatformName);
                if (updateGroup != null)
                {
                    updateGroup!.OrderBy = model.Order;
                    groupUpdateResultModel.Order = model.Order;
                    var updateGroupData = await _unitOfWork.GroupUpdateData.GetData(updateGroup, model);
                    if (updateGroupData.Any())
                    {
                        groupUpdateResultModel.GroupUpdateData = updateGroupData;
                        //     groupUpdateResultModel.PageSize = model.PageSize ?? 25;
                        groupUpdateResultModel.PageSize = model.PageSize;
                        groupUpdateResultModel.GroupUpdate = updateGroup;
                        groupUpdateResultModel.PageNumber = model.PageNumber;
                        groupUpdateResultModel.TotalCount = updateGroupData.FirstOrDefault()?.TotalRecords;
                        if (!model.IsPaginationSort)
                        {
                            switch (updateGroup.ColumnType)
                            {
                                case "H":
                                    dropDownList = await _unitOfWork.GroupUpdateDropDownList.GetBoolean(updateGroup.TableName!, updateGroup.ColumnName!, model.PlatformName);
                                    break;
                                case "N":
                                    dropDownList = model.GroupUpdateIdNumber switch
                                    {
                                        "7" => await _unitOfWork.GroupUpdateDropDownList.GetAffiliate(model.ClientId.ToString(), model.DivisionLevelAccess ?? "", model.AffiliateString ?? "", model.PlatformName),
                                        "12" => await _unitOfWork.GroupUpdateDropDownList.GetSchedule(model.ClientId.ToString(), model.PlatformName),
                                      _ => await _unitOfWork.GroupUpdateDropDownList.GetBoolean(updateGroup.TableName!, updateGroup.ColumnName!, model.PlatformName),
                                    };
                                break;
                            }
                            groupUpdateResultModel.DropDownList = dropDownList;
                        }
                    }
                }
                groupUpdateResultModel.PageNumber = model.PageNumber;
                return Request.CreateResponse(HttpStatusCode.OK, groupUpdateResultModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Group Update Data By Client Id and GroupUpdateIdNumber: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
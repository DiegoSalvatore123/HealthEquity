﻿

namespace Core.Util
{
    public class ConstantValues
    {
        public const string WEBMASTEREMAIL = "WebMasterEmail";
        public const string NOTIFICATIONTYPEWE = "WE";
        public const Int32 QUEUEDBY1750 = 1750;
        public const string NOTIFICATIONSTATUSQ = "Q";
        public const string EMAILSUBJECTREMOVEQE   = "participant_search/removeQE_process.asp Error";
        public const string FILENAME = "MonJazzTestFile.pdf";
       
        public const string HIREFAIL = "There was an error processing the Rehire for (Participant {0}). Please try again later.";
        public const string ADDFAIL = "There was an error processing the Add for (Participant SSN {0}). Please try again later.";
        public const string DISABILITYSUCCESS = "SUCCESS: processed disability extension for {0} (Participant {1}).";
        public const string DISABILITYFAIL = "There was an error processing the disability extension for (Participant {0}). Please try again later.";
        public const string EMPLOYERCHANGESUCCESS = "SUCCESS: processed employer change for {0} (Participant {1}).";
        public const string EMPLOYERCHANGEFAIL = "There was an error processing the employer change for (Participant {0}). Please try again later.";
        public const string PARTICIPANTPAYMENTERROR = "This participant cannot be moved because they have already had payments accepted.";
        public const string BANCKCHECKERROR = "This participant cannot be moved because they have had checks issued to them.";
        public const string PARTICIPANTCOVERAGEERROR = "This participant cannot be moved because they have active coverages.";
        public const string DOCQUEUEERROR = "This participant cannot be moved because they have had documents mailed to them.";
        public const string DEPENDENTADDRESSSUCCESS = "Dependent address successfully saved.";
        public const string DEPENDENTADDRESSFAIL = "Invalid address. Please check the address details and try again.";
        public const string COVERAGECHANGESUCCESS = "SUCCESS: processed coverage change for {0} (Participant {1}). Coverage processed for:";
        public const string COVERAGECHANGEFAIL = "There was an error processing the coverage change for (Participant {0}). Please try again later.";
        public const string TAKEOVERFAIL = " ERROR: takeover for participant {0} could not be processed at this time. Please try again later.";
        public const string PROCESSQEFAIL = "ERROR: unable to process qualifying event for participant #{0} at this time. Please try again later.";
        public const string PROCESSQESUCCESS = "Successfully processed qualifying event for {0} {1} (Participant {2}).";
        public const string UPDATEGROUPFAIL = "There was an error processing the Update{0} Please try again later";
        public const string UPDATEGROUPSUCCESS = "Successfully processed {0} participant{1} update{2}";
        public const string DEPENDENTPROCESSQEFAIL = "There was an error processing the dependent qualifying event for (Participant {0}). Please try again later.";
        public const string DEPENDENTPROCESSQESUCCESS = "SUCCESS: processed dependent qualifying event for {0} {1} (Participant {2}). Please notify the appropriate carrier(s) of any loss of coverage.";
        public const string UPDATEFAIL = "ERROR: update participant #{0} could not be processed at this time. Please try again later.";
        public const string ACHSUCCESS = "ACH Signup Form queue successfully.";
        public const string ACHFAILED = "ERROR: ACH Signup Form could not be queued at this time. Please try again Later.";
        public const string PARTICIPANT_STATUS_A = "A";
        public const string PARTICIPANT_TYPE_E = "E";
        public const string COVERAGEFAIL = "ERROR: Mark acceptable participant #{0} could not be processed at this time. Please try again later.";
        public const string MLRFAILED = "Client Web: Call to QuotIt FAILED to return all rates requested!";
        public const string MLRSUCCEDD = "Client Web: Call to QuotIt SUCCEEDED to return all rates requested!";


    }

    public enum QualifyingEventTypeEnum
    {
        Employee,
        Spouse,
        Child
    }
    public enum AvailablePlanTypeEnum
    {
        Existing,
        New
    }
}

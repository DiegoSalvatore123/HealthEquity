﻿using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace Core.Util
{
    public static class ServiceUtil
    {
        public static async Task<R?> SendAsync<R>(string url)
        {
            HttpClient client = new();
            R? value = default;

            client.BaseAddress = new Uri(url);

            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

           // HttpResponseMessage response = client.GetAsync(client.BaseAddress).Result;
            HttpResponseMessage response = client.GetAsync("").Result;
            if (response.IsSuccessStatusCode)
                value = await response.Content.ReadAsJsonAsync<R>();
            return value;
        }
        public static async Task<R?> SendAsync<T, R>(string url, T param)
        {
            HttpClient client = new();
            R? value = default;

            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
           HttpResponseMessage response = await client.PostAsJsonAsync(client.BaseAddress, param);
            if (response.IsSuccessStatusCode)
                value = await response.Content.ReadAsJsonAsync<R>();
            return value;
        }
        public static async Task<T?> ReadAsJsonAsync<T>(this HttpContent content)
        {
            var dataAsString = await content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(dataAsString);
        }
        public static string ConvertFileToBase64(string filePath)
        {
            byte[] fileBytes = File.ReadAllBytes(filePath);
            string base64String = Convert.ToBase64String(fileBytes);
            return base64String;
        }
    }
    public static class DateTimeMethods
    {
        public static DateTime StartOfMonth(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1, 0, 0, 0);
        }

        public static DateTime EndOfMonth(this DateTime date)
        {
            return date.StartOfMonth().AddMonths(1).AddSeconds(-1);
        }
    }
}

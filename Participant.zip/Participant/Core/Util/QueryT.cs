﻿namespace Core.Util
{
    public class QueryT
    {
        public string SelectFrom { get; set; } = string.Empty;
        //public string Where { get; set; } = string.Empty;
        //public string OrderBy { get; set; } = string.Empty;
        public Dictionary<string, object>? Parameters { get; set; }
    }
}

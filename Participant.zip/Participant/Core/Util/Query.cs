﻿namespace Core.Util
{
    public class Query
    {
        public string SelectFrom { get; set; } = string.Empty;
        public string Where { get; set; } = string.Empty;
        //public string OrderBy { get; set; } = string.Empty;
        public Dictionary<string, string>? Parameters { get; set; }
    }    
}
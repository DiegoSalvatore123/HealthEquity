﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class DocumentService : IDocumentService
    {
        private readonly ILogger<DocumentService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public DocumentService(ILogger<DocumentService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(DocumentModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.PlatformName) || string.IsNullOrWhiteSpace(model.SecureId))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public async Task<HttpResponseMessage> GetDocument(DocumentModel documentModel)
        {
            try
            {
                DocumentResultModel? documentResultModel = new();
                documentResultModel = await _unitOfWork.Document.GetDocument(documentModel);
                if (documentResultModel != null)
                {
                    List<string> fullPathDetail = new() {
                        documentResultModel.Path?? string.Empty,
                        "\\",
                        documentResultModel.DocumentImageId.ToString(),
                        ".",
                        documentResultModel.Extension?? string.Empty
                    };
                    string fullPath = string.Concat(fullPathDetail.ToArray());
                    fullPath = ConstantValues.FILENAME;
                    documentResultModel.Base64File = ServiceUtil.ConvertFileToBase64(fullPath);
                }
                return Request.CreateResponse(HttpStatusCode.OK, documentResultModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to get document: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

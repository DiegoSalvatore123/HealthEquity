﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class CobraService : ICobraService
    {
        private readonly ILogger<CobraService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public CobraService(ILogger<CobraService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForClientBadRequest(PlatformModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application while performing the Search. Try again!");

            return result;
        }
        public async Task<HttpResponseMessage> GetEmployeeCounts(PlatformModel model)
        {
            try
            {
                ClientOptionResultModel? search = new();
                search = await _unitOfWork.ClientOptionAll.GetEmployeeCounts(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetClientPlans(PlatformModel model)
        {
            try
            {
                List<ClientPlansModel>? search = new();
                search = await _unitOfWork.ClientPlans.GetClientCobraPlans(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> SearchDependentBySSN(SearchModel model)
        {
            try
            {
                List<DependentResultModel>? search = new();
                search = await _unitOfWork.DependentSearch.SearchDependentBySSN(model);
                if (search == null)
                    Request.CreateResponse(HttpStatusCode.NoContent, "Participant not available");
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform Search Dependent By Primary SSN: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;
namespace Core
{
    public class CoverageService: ICoverageService
    {
        private readonly ILogger<SearchService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public CoverageService(ILogger<SearchService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            var participantId = model?.GetType()?.GetProperty("ParticipantId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(participantId) || string.IsNullOrWhiteSpace(platformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public async Task<HttpResponseMessage> CoverageError(ParticipantInfoModel searchModel)
        {
            try
            {
                List<CoverageErrorModel>? search = new();
                search = await _unitOfWork.CoverageError.GetCoverageError(searchModel.ParticipantId, searchModel.PlatformName);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CoverageErrorQE(ParticipantInfoModel searchModel)
        {
            try
            {
                List<CoverageErrorModel>? search = new();
                search = await _unitOfWork.CoverageError.GetCoverageErrorQE(searchModel.ParticipantId, searchModel.PlatformName);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

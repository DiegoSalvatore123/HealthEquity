﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.DependencyModel;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class SPService : ISPService
    {
        private readonly ILogger<SPService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public SPService(ILogger<SPService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public async Task<HttpResponseMessage> GetSubsidybyPid(ParticipantIdModel model)
        {
            try
            {
                List<SubsidyResultModel> search = new();
                search = await _unitOfWork.Subsidy.GetSubsidybyPid(model);

                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Subsidy by PId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> GetBilling(ParticipantIdModel model)
        {
            try
            {
                BillingDetailModel search = new();
                search = await _unitOfWork.BillingDetail.GetBillingDetail(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Billing detail: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CheckFeature(CheckFeatureModel model)
        {
            try
            {
                GenericUniqueValue? isFeature = await _unitOfWork.GenericUniqueValue.IsFeatureOn(model.PlatformName, model.ClientId);                
                return Request.CreateResponse(HttpStatusCode.OK, isFeature);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Check Feature: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> RemoveQE(RemoveQEModel model)
        {
            try
            {
                OperationResultModel? removeQEInfoModel = new();
                removeQEInfoModel = await _unitOfWork.RemoveQE.RemoveQE(model);
                if (removeQEInfoModel != null)
                {
                    if (!removeQEInfoModel.Success)
                    {
                        SystemSettingModel? systemSettingsModel = await _unitOfWork.SystemSetting.GetSystemSettingByName(ConstantValues.WEBMASTEREMAIL, model.PlatformName);
                        if (systemSettingsModel != null)
                        {
                            RemoveQEDetail? removeQEDetail = await _unitOfWork.RemoveQEDetail.GetRemoveQEDetailByPid(model);
                            if (removeQEDetail != null)
                            {
                                EmailNotificationModel emailNotificationModel = new()
                                {
                                    QueuedBy = ConstantValues.QUEUEDBY1750,
                                    NotificacionType = ConstantValues.NOTIFICATIONTYPEWE,
                                    LinkTo = Int32.Parse(model.UserId),
                                    DateQueued = DateTime.Now,
                                    NotificacionStatus = ConstantValues.NOTIFICATIONSTATUSQ,
                                    Subject = ConstantValues.EMAILSUBJECTREMOVEQE,
                                    EmailAddress = systemSettingsModel.SettingValue,
                                    TextMessage = removeQEDetail.TextMessage
                                };
                                await _unitOfWork.EmailNotification.Add(emailNotificationModel, model.PlatformName);
                            }
                        }
                    }
                }
                return Request.CreateResponse(HttpStatusCode.OK, removeQEInfoModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get RemoveQE Detail: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CoveragePlanByClientId(CoveragePlanDataModel model)
        {
            try
            {
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(model.PlatformName);
                if (!string.IsNullOrWhiteSpace(model.AffiliateName) && string.IsNullOrEmpty(model.AffiliateId))
                {
                    AffiliateInfoModel affiliateInfo = new()
                    {
                        PlatformName = model.PlatformName,
                        UserId = model.UserId,
                        ClientId = model.ClientId,
                        AffiliateName = model.AffiliateName ?? ""
                    };
                    AffiliateModel? affiliate = await _unitOfWork.Affiliate.GetAffiliateName(affiliateInfo, platformConection?.Value!);

                    if (affiliate != null)
                        model.AffiliateId = affiliate.AffiliateId.ToString();
                }
                model.Xml = GetSpecificFields(model.ParticipantSpecificFields, model.UserType);
                List<AvailablePlansClientResult>? searchPlan = new();
                searchPlan = await _unitOfWork.AvailablePlan.CoveragePlanByClientId(model, platformConection?.Value!);
                GenericUniqueValue? isFeature = await _unitOfWork.GenericUniqueValue.IsFeatureOn(model.PlatformName, model.ClientId, platformConection?.Value!);
                List<AvailablePlansClientResultModel> availablePlan = new();
                AvailablePlansClientModel availablePlansClientModel = new();
                if (searchPlan != null && searchPlan.Count>0)
                {
                    availablePlan = GetUniqueModelList(searchPlan);
                    await DealRateTypeAndQEPlanComponent(availablePlan, model, Convert.ToBoolean(int.Parse(isFeature?.Value ?? "0")), platformConection?.Value!);
                    GetCoveragePlan(availablePlan, searchPlan);
                    GenericUniqueValue? QeCode = await _unitOfWork.GenericUniqueValue.GetQEExtension(model.PlatformName, model.QualifiedCode!, platformConection?.Value!);
                    availablePlansClientModel.AvailablePlansClient = availablePlan.Where(x => x.Pcid == null).ToList();
                    availablePlansClientModel.ExistingPlansClient = availablePlan.Where(x => x.Pcid != null).ToList();
               //     availablePlansClientModel.IsFeatureOn = Convert.ToBoolean(int.Parse(isFeature?.Value??"0"));
                    availablePlansClientModel.QEExtension = QeCode?.Value ?? "";
                    //return MR for NEW available
                    if(availablePlansClientModel.AvailablePlansClient.Count > 0)
                        GetCoverageMembers(model, availablePlansClientModel.AvailablePlansClient);
                    if (availablePlansClientModel.ExistingPlansClient.Count > 0)
                        GetCoverageMembers(model, availablePlansClientModel.ExistingPlansClient);
                }
                return Request.CreateResponse(HttpStatusCode.OK, availablePlansClientModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Process Coverage Plan By ClientId: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public List<string> CheckForBadRequest(ParticipantIdModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ParticipantId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForBadRequestRemoveQE(RemoveQEModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.ParticipantId) ||
                string.IsNullOrWhiteSpace(model.PlatformName) ||
                string.IsNullOrWhiteSpace(model.UserId) ||
                string.IsNullOrWhiteSpace(model.Reason) ||
                model.Reason.Length > 100 || model.Reason.Length < 5)
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public List<string> CheckForConverageBadRequest(CoveragePlanDataModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            if (string.IsNullOrWhiteSpace(model.PlatformName) || string.IsNullOrWhiteSpace(model.ClientId))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public async Task<HttpResponseMessage> QueueAch(VoidModel model)
        {
            try
            {
                OperationResultModel result = new();
                result = await _unitOfWork.ParticipantTransaction.QueueAch(model);
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to Get Check Feature: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        private static void GetCoverageMembers(CoveragePlanDataModel model,List<AvailablePlansClientResultModel> availablePlan)
        {
            List<CoverageMemberModel> dependentMR = new();
            List<CoverageMemberModel> dependentRT = new();

            CoverageMemberModel coverage = new()
            {
                ParticipantCoverageId = "1",
                Name = model.FirstName + " " + model.LastName,
                ParticipantId =model.ParticipantId != null ? int.Parse(model.ParticipantId!) : 0
            };
            dependentMR.Add(coverage);
            dependentRT.Add(coverage);
            List<CoverageMemberModel>? mr  = GetDependentsMR(model.Dependents);
            if (mr != null)
                dependentMR.AddRange(mr);
            List<CoverageMemberModel>? rt = GetDependentsRT(model.Dependents);
            if (rt != null)
                dependentRT.AddRange(rt);
            foreach (AvailablePlansClientResultModel available in availablePlan)
            {
                if (available.RateType == "MR")
                    available.CoverageMember = dependentMR;
                if (available.RateType == "RT" && available.CoverageType == "F" && available.IsLifeInsuranceRTPlan == "1")
                    available.CoverageMember = dependentRT;
            }
        }
        private static List<CoverageMemberModel>? GetDependentsMR(List<DependentNewViewModel>? dependents)
        {
            List<CoverageMemberModel> lstCoverage=new();
            if (dependents==null || dependents.Count==0)
                return null;
            int? participantId = 0;
            int idNew = 1;
            foreach (DependentNewViewModel dependent in dependents) {
                if(dependent.QualifiedBeneficiary=="Y")
                {
                    if (dependent.ParticipantId == null)
                    {
                        participantId = idNew;
                        idNew++;
                    }
                    else
                        participantId= dependent.ParticipantId;
                    CoverageMemberModel coverage = new()
                    {
                        ParticipantId = participantId,
                        ParticipantCoverageId = "0",
                        Name = dependent.FirstName + " " + dependent.LastName,
                    };
                    lstCoverage.Add(coverage);
                }
            }
            return lstCoverage;
        }
        private static List<CoverageMemberModel>? GetDependentsRT(List<DependentNewViewModel>? dependents)
        {
            List<CoverageMemberModel> lstCoverage = new();
            if (dependents == null || dependents.Count == 0)
                return null;
            int? participantId = 0;
            int idNew = 1;
        
            foreach (DependentNewViewModel dependent in dependents)
            {
                if (dependent.ParticipantId == null)
                {
                    participantId = idNew;
                    idNew++;
                }
                else
                    participantId = dependent.ParticipantId;
                if (dependent.ParticipantStatus == "A")
                {
                    CoverageMemberModel coverage = new()
                    {
                        ParticipantId = participantId,
                        ParticipantCoverageId = "0",
                        Name = dependent.FirstName + " " + dependent.LastName,
                    };
                    lstCoverage.Add(coverage);
                }
            }
            return lstCoverage;
        }
        private static List<AvailablePlansClientResultModel>GetUniqueModelList(List<AvailablePlansClientResult> searchPlan)
        {
            List<AvailablePlansClientResultModel> availablePlan = searchPlan.DistinctBy(p => p.PlanName).Select(sp => new AvailablePlansClientResultModel
            {
                PlanId = sp.PlanId,
                CoverageType = sp.CoverageType,
                RateType = sp.RateType,
                Pcid = sp.Pcid,
                CoverageCode = sp.CoverageCode,
                CoverageRate = sp.CoverageRate.ToString(),
                Priority = sp.Priority,
                CoverageBeginDate = sp.CoverageBeginDate.ToString(),
                CoverageName = sp.CoverageName,
                PlanName = sp.PlanName,
                WaitPeriodType = sp.WaitPeriodType,
                WaitPeriodQty = sp.WaitPeriodQty,
                WaitEndsType = sp.WaitEndsType,
                CoverageEndType = sp.CoverageEndType,
                PlanIsFutureDated = sp.PlanIsFutureDated,
                IsMNLife = sp.IsMNLife,
            }).ToList();
            return availablePlan;
        }
        private static void GetCoveragePlan(List<AvailablePlansClientResultModel> availablePlan, List<AvailablePlansClientResult> searchPlan)
        {
            foreach (AvailablePlansClientResultModel name in availablePlan)
            {
                var coverageAvailablePlan = new List<CoverageAvailablePlan>();
                if (name.CoverageAvailablePlan == null || !name.CoverageAvailablePlan.Any())
                {
                   coverageAvailablePlan = (from sp in searchPlan.Where(x => x.PlanName == name.PlanName)
                                            select new CoverageAvailablePlan
                                            {
                                                Code = sp.CoverageCode,
                                                Description = sp.CoverageName
                                            }).ToList();
                }
                else
                {
                    coverageAvailablePlan = (from cap in name.CoverageAvailablePlan.Where(x => x.Code != null)
                                             select new CoverageAvailablePlan
                                             {
                                                 Code = cap.Code,
                                                 Description = cap.Description
                                             }).ToList();
                }
                
                coverageAvailablePlan.Insert(0,
                     new CoverageAvailablePlan
                     {
                         Code = "",
                         Description = "Not Selected"
                     });
                name.CoverageAvailablePlan = coverageAvailablePlan;
            }
        }
        private async Task DealRateTypeAndQEPlanComponent(List<AvailablePlansClientResultModel> availablePlan, CoveragePlanDataModel model, bool isFeature, string platformConection)
        {
            DateTime CoverageBeginDate;
            List<CoverageAvailablePlan>? coverages = await _unitOfWork.GenericPaireValue.GetCoverageWithPlatformConection(platformConection, "98");
            GenericUniqueValue? isDirectRateEntry = await _unitOfWork.GenericUniqueValue.GetDirectRateEntry(platformConection, model.ClientId.ToString());
            foreach (AvailablePlansClientResultModel available in availablePlan)
            {
                available.ShowSubsidy = false;
                if (isFeature && model.Action != "4") 
                { 
                    QEPlanComponentModel? qePlanComponentModel = await _unitOfWork.QEPlanComponent.GetQEPlanComponentWithPlatformConection(available.PlanId, platformConection, available.IsLifeInsuranceRTPlan!);
                    available.QEPlanComponentModel = qePlanComponentModel;
                    if ((qePlanComponentModel?.DisablePLS == 0 && qePlanComponentModel.BenType > 0) || qePlanComponentModel?.Bentypecnt > 0)
                        available.ShowSubsidy = true;
                }
                if ((available.RateType == "RT"|| available.RateType == "ST" || available.RateType == "MI" || available.RateType == "VA" || available.RateType == "IR") && model.Action != "4")
                {
                    GenericUniqueValue? isLifeInsuranceRTPlan = await _unitOfWork.GenericUniqueValue.GetLifeInsuranceRTPlanWithPlatformConection(platformConection, available.PlanId.ToString(),"LA");
                    available.IsLifeInsuranceRTPlan = isLifeInsuranceRTPlan?.Value ?? "";
                }
                if (available.RateType == "IR")
                {
                    if (coverages != null && coverages.Count > 0)
                        available.CoverageAvailablePlan = coverages;
                }
                if (available.RateType == "MR" && model.Action!="4")
                {
                    available.IsTobaccoRated = "0";
                    GenericUniqueValue ? IsTobaccoRated = await _unitOfWork.GenericUniqueValue.GetTobaccoUse(platformConection, available.PlanId.ToString());
                    available.IsTobaccoRated = IsTobaccoRated?.Value ?? "0";
                    available.IsDirectRateEntry = (isDirectRateEntry?.Value)=="1";
                }
                if (!string.IsNullOrEmpty(model.QualifyingEventDate))
                { 
                    if (string.IsNullOrEmpty(available.CoverageBeginDate) && !string.IsNullOrEmpty(model.HireDate))
                    {
                        CoverageBeginDate = available.WaitPeriodType!.Trim() switch
                        {
                            "D" => Convert.ToDateTime(model.HireDate).AddDays(available.WaitPeriodQty),
                            "M" => Convert.ToDateTime(model.HireDate).AddMonths(available.WaitPeriodQty),
                            "W" => DateTimeExtensions.AddWeeks(Convert.ToDateTime(model.HireDate), available.WaitPeriodQty),
                            _ => Convert.ToDateTime(model.HireDate),
                        };
                        if (available.WaitPeriodType.Trim() != "O")
                        {
                            CoverageBeginDate = available.WaitEndsType!.Trim() switch
                            {
                                "ME" => GetCoverageBeginDate(CoverageBeginDate),
                                "SD" => CoverageBeginDate.AddDays(0),
                                "ND" => CoverageBeginDate.AddDays(1),
                                _ => CoverageBeginDate,
                            };
                        }
                        if(model.Action == "4")
                        {
                            if (DateTime.Compare(CoverageBeginDate, Convert.ToDateTime(model.BillingStartDate)) > 0)
                            {
                                available.CoverageBeginDate = CoverageBeginDate.ToShortDateString();
                            }
                            else
                            {
                                available.CoverageBeginDate = model.BillingStartDate;
                            }                            
                        }
                        else
                        {
                            available.CoverageBeginDate = CoverageBeginDate.ToShortDateString();
                        }                        
                    }
                    if (model.Action != "4")
                    {
                        available.LastDayPreCobra = GetLastPreCobraCoverageDate(model.QualifyingEventDate, available.CoverageEndType);
                    }
                }
                else
                    available.CoverageBeginDate = model.BillingStartDate;//DIRECT BILL
                if (available.PlanIsFutureDated == 0)
                    available.PlanIsValid = true;
                //I Think this is not used. Diego
                //GenericUniqueValue? planType = await _unitOfWork.GenericUniqueValue.GetPlanTypeWithPlatformConection(platformConection, available.PlanId.ToString());
                //available.PlanType = planType?.Value?.ToString() ?? "";
                if (model.Action != "4")
                {
                    GenericUniqueValue? planOption = await _unitOfWork.GenericUniqueValue.GetPlanOptionConection(platformConection, available.PlanId.ToString());
                    available.PlanOption = planOption?.Value?.Trim().ToString() ?? "";
                }
            }
        }
        private string GetLastPreCobraCoverageDate(string qeDate, string? planEndsType)
        {
            var year = Convert.ToDateTime(qeDate).Year;
            var month = Convert.ToDateTime(qeDate).Month;
            var day = Convert.ToDateTime(qeDate).Day;
            var lPCCDate = qeDate;
            switch (planEndsType)
            {
                case "ME":                    
                    lPCCDate = (new DateTime(year, month, DateTime.DaysInMonth(year, month))).ToShortDateString();
                    break;
                case "MI":
                    if (day > 15)
                        lPCCDate = (new DateTime(year, month, day).AddMonths(1)).ToShortDateString();
                    lPCCDate = (new DateTime(year, month, 15)).ToShortDateString();
                    break;
                case "ND":
                    lPCCDate = (new DateTime(year, month, day).AddDays(1)).ToShortDateString();
                    break;
                case "SD":
                    break;  
            }            
            return lPCCDate;
        }        
        private static DateTime GetCoverageBeginDate(DateTime converageBeginDate)
        {
            int yr = converageBeginDate.Year;
            int mm = converageBeginDate.Month;
            if (string.IsNullOrEmpty(mm.ToString()))
                mm = 0;
            if (string.IsNullOrEmpty(yr.ToString()))
                yr = 0;
             if (mm == 12)
                return  new DateTime(yr + 1, 1, 1);
              else
                return new DateTime(yr, mm + 1, 1);
        }
        private static string GetSpecificFields(List<SpecificFieldsModel>? model, string userType)
        {
            string xml = @"'<UserDefinedFieldBO xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance""><UserDefinedFieldInfos>";

            if (model != null && model.Count > 0)
            {
                foreach (SpecificFieldsModel _model in model)
                {
                    if (_model.ShowOnWeb == true || userType == "I" || userType == "O")
                    {
                        if (_model.CustomFieldId > 0)
                        {
                            xml = string.Concat(xml, "<UserDefinedFieldInfo>");
                            xml = string.Concat(xml, string.Format("<CustomFieldId>{0}</CustomFieldId>", _model.CustomFieldId));
                            xml = string.Concat(xml, string.Format("<FieldValue>{0}</FieldValue>", _model.FieldValue));
                            xml = string.Concat(xml, "</UserDefinedFieldInfo>");
                        }
                    }
                }
            }
            xml = string.Concat(xml, "</UserDefinedFieldInfos></UserDefinedFieldBO>'");
            return xml;
        }
     
    }
}

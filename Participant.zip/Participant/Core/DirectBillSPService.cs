﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Reflection;

namespace Core
{
    public class DirectBillSPService : IDirectBillSPService
    {
        private readonly ILogger<DirectBillSPService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public DirectBillSPService(ILogger<DirectBillSPService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForClientBadRequest(PlatformModel model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));

            if (string.IsNullOrWhiteSpace(model.ClientId) || string.IsNullOrWhiteSpace(model.PlatformName))
                result.Add("There was an error in the Application. Try again!");

            return result;
        }
        public async Task<HttpResponseMessage> GetImpendingMedicareReport(PlatformModel model)
        {
            try
            {
                List<DBImpendingMedicareReportModel>? result = new();
                result = await _unitOfWork.DBImpendingMedicareReport.GetImpendingMedicareReport(model);
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to GetImpendingMedicareReport: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}

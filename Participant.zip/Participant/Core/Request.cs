﻿using System.Net.Http.Formatting;
using System.Net;

namespace Core
{
    public static class Request
    {
        public static HttpResponseMessage CreateResponse<T>(HttpStatusCode statusCode, T content)
        {
            return new HttpResponseMessage()
            {
                StatusCode = statusCode,
                Content = new ObjectContent<T>(content, new JsonMediaTypeFormatter(), "application/json")
            };
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Logging;
using System.Net;

namespace Core
{
    public class TransactionService : ITransactionService
    {
        private readonly ILogger<TransactionService> _logger;
        private readonly IUnitOfWork _unitOfWork;
        public TransactionService(ILogger<TransactionService> logger, IUnitOfWork unitOfWork)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _unitOfWork = unitOfWork ?? throw new ArgumentNullException(nameof(unitOfWork));
        }
        public List<string> CheckForBadRequest(Object model)
        {
            var result = new List<string>();
            if (model == null) throw new ArgumentNullException(nameof(model));
            var userId = model?.GetType()?.GetProperty("UserId")?.GetValue(model, null)?.ToString();
            var platformName = model?.GetType()?.GetProperty("PlatformName")?.GetValue(model, null)?.ToString();
            var clientId = model?.GetType()?.GetProperty("ClientId")?.GetValue(model, null)?.ToString();

            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(platformName) || string.IsNullOrWhiteSpace(clientId))
                result.Add("There was an error in the Application. Try again.");
            return result;
        }
        public async Task<HttpResponseMessage> Insert(ParticipantInsertModel participantInsertModel)
        {
            try
            {
                OperationResultModel operationResultModel = new();
                GenericUniqueValue? platformConnection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(participantInsertModel.PlatformName);
                participantInsertModel.ParticipantInfo.AffiliateId = await GetAffiliate(platformConnection, participantInsertModel.ParticipantInfo.AffiliateName ?? "", participantInsertModel.ParticipantInfo.AffiliateId, participantInsertModel.PlatformName, participantInsertModel.UserId, participantInsertModel.ClientId);
                operationResultModel = await _unitOfWork.ParticipantTransaction.Insert(participantInsertModel);
                return Request.CreateResponse(HttpStatusCode.OK, operationResultModel);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform Insert Participant: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> InsertAddress(AddressModel searchModel)
        {
            try
            {
                OperationResultModel search = new();
                search = await _unitOfWork.ParticipantTransaction.CreateAddress(searchModel);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> UpdateDisability(DisabilityUpdateModel model)
        {
            try
            {
                OperationResultModel search = new();
                search = await _unitOfWork.ParticipantTransaction.UpdateDisability(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> UpdateEmployerChange(EmployerChangeUpdateModel model)
        {
            try
            {
                OperationResultModel search = new();
                search = await _unitOfWork.ParticipantTransaction.UpdateEmployerChange(model);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform update Employer Change: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> UpdateCoverageChange(CoverageChangeAvailablePlansModel model)
        {
            try
            {
                CoverageChangeResultModel search = new();
                GenericUniqueValue? platformConnection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(model.PlatformName);
                if (model.NewCoverageChanges != null && model.NewCoverageChanges.Count > 0)
                {

                    foreach (var newCoverageChange in model.NewCoverageChanges)
                    {
                        GenericUniqueValue? CheckIfAlreadyExistNewCoverageId = await _unitOfWork.GenericUniqueValue.GetParticipantCoverageId(platformConnection?.Value!, newCoverageChange.ParticipantId, newCoverageChange.PlanId, newCoverageChange.EffectiveDate);
                        if (CheckIfAlreadyExistNewCoverageId == null || string.IsNullOrWhiteSpace(CheckIfAlreadyExistNewCoverageId?.Value))
                        {
                            GenericUniqueValue? newTerminationDate = await _unitOfWork.GenericUniqueValue.GetTerminationCoverageDate(platformConnection?.Value!, newCoverageChange.ParticipantId, newCoverageChange.PlanId, newCoverageChange.EffectiveDate);
                            newCoverageChange.TerminationDate = newTerminationDate?.Value == "0" ? null : newTerminationDate?.Value;
                        }
                        else
                        {
                            search.Success = false;
                            search.ResultDescription = $"This participant is already covered under {newCoverageChange.PlanName}";
                            return Request.CreateResponse(HttpStatusCode.OK, search);
                        }
                    }
                }
                search = await _unitOfWork.ParticipantTransaction.UpdateCoverageChange(model, platformConnection?.Value!);
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform update Coverage Change: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> InsertTakeOver(InfoSessionModel searchModel)
        {
            try
            {
                OperationResultModel search = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(searchModel.PlatformName);
                searchModel.ParticipantInfo!.AffiliateId = await GetAffiliate(platformConection, searchModel.ParticipantInfo.AffiliateName ?? "", searchModel.ParticipantInfo.AffiliateId, searchModel.PlatformName, searchModel.UserId, searchModel.ClientId);
             
                GetDateConverage(searchModel.AvailablePlans!, searchModel.ProcessQE!);
                if (string.IsNullOrEmpty(searchModel.ProcessQE!.EligiibilityEndDate!))
                {
                    //Search data from current Participant
                    ClientOptionModel optionModel = new()
                    {
                        ClientOptionId = 261,
                        ClientId = searchModel.ClientId,
                        PlatformName = searchModel.PlatformName,
                        UserId = searchModel.UserId,
                    };

                    searchModel.ProcessQE.EligiibilityEndDate = (Convert.ToDateTime(searchModel.ProcessQE.LastDayPreCobraCoverage2).AddMonths(int.Parse(searchModel.ProcessQE!.ExtensionLength!))).AddYears(-1).ToShortDateString();
                    ClientOptionResultModel? model = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel, platformConection?.Value!);
                    if (model != null)
                    {
                        if (model.OptionValue != "3")
                            searchModel.ProcessQE!.EligiibilityEndDate = (Convert.ToDateTime(searchModel.ProcessQE!.EligiibilityEndDate).EndOfMonth()).ToShortDateString();
                    }
                }
                ClientOptionModel optionModel289 = new()
                {
                    ClientOptionId = 289,
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                    UserId = searchModel.UserId,
                };
                ClientOptionResultModel? model289 = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel289, platformConection?.Value!);
                if (model289 != null && model289!.OptionValue == "0")
                {
                    searchModel.FormNumber = "CLC27";
                    searchModel.EventType = "6D";
                }
                else
                {
                    searchModel.FormNumber = "CLC06";
                    searchModel.EventType = "56";
                }
                search = await _unitOfWork.ParticipantTransaction.InsertTakeOver(searchModel);

                if (search.Success)
                {
                    ClientOptionResultModel? coverageCount = await _unitOfWork.ClientOptionAll.GetCoveragError(searchModel.PlatformName, searchModel.ParticipantInfo.ParticipantId ??"", platformConection?.Value!);
                    if (coverageCount!.OptionValue != "0")
                        search.DependentError=true;
                }
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> InsertProcessQE(InfoSessionModel searchModel)
        {
            try
            {
                OperationResultModel search = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(searchModel.PlatformName);
                searchModel.ParticipantInfo!.AffiliateId = await GetAffiliate(platformConection, searchModel.ParticipantInfo.AffiliateName ?? "", searchModel.ParticipantInfo.AffiliateId, searchModel.PlatformName, searchModel.UserId, searchModel.ClientId);

                if (searchModel.AvailablePlans != null && searchModel.AvailablePlans.AvailablePlansClient != null && searchModel.AvailablePlans.AvailablePlansClient.Count > 0)
                    GetDateConverage(searchModel.AvailablePlans!, searchModel.ProcessQE!);

                if (string.IsNullOrEmpty(searchModel.ProcessQE!.EligiibilityEndDate!))
                {
                    //Search data from current Participant
                    ClientOptionModel optionModel261 = new()
                    {
                        ClientOptionId = 261,
                        ClientId = searchModel.ClientId,
                        PlatformName = searchModel.PlatformName,
                        UserId = searchModel.UserId,
                    };

                    if (searchModel.AvailablePlans != null && searchModel.AvailablePlans.AvailablePlansClient != null && searchModel.AvailablePlans.AvailablePlansClient.Count > 0)
                        searchModel.ProcessQE.EligiibilityEndDate = (Convert.ToDateTime(searchModel.ProcessQE.LastDayPreCobraCoverage2).AddMonths(int.Parse(searchModel.ProcessQE!.ExtensionLength!))).AddYears(-1).ToShortDateString();
                    ClientOptionResultModel? model = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel261, platformConection?.Value!);
                    if (model != null)
                    {
                        if (model.OptionValue != "3" && !string.IsNullOrWhiteSpace(searchModel.ProcessQE!.EligiibilityEndDate))
                            searchModel.ProcessQE!.EligiibilityEndDate = (Convert.ToDateTime(searchModel.ProcessQE!.EligiibilityEndDate).EndOfMonth()).ToShortDateString();
                    }
                }
                ClientOptionModel optionModel289 = new()
                {
                    ClientOptionId = 289,
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                    UserId = searchModel.UserId,
                };
                ClientOptionResultModel? model289 = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel289, platformConection?.Value!);
                if (model289 != null && model289!.OptionValue == "0")
                {
                    searchModel.FormNumber = "CLC27";
                    searchModel.EventType = "6D";
                }
                else
                {
                    searchModel.FormNumber = "CLC06";
                    searchModel.EventType = "56";
                }
                ClientOptionModel optionModel286 = new()
                {
                    ClientOptionId = 286,
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                    UserId = searchModel.UserId,
                };
                ClientOptionResultModel? model286 = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel286, platformConection?.Value!);
                if (model286 != null && model286!.OptionValue == "1")
                    searchModel.EventTypeQE = "A4";
                else
                    searchModel.EventTypeQE = "03";
                search = await _unitOfWork.ParticipantTransaction.InsertProcessQE(searchModel);
                if (search.Success)
                {
                    ClientOptionResultModel? coverageCount = await _unitOfWork.ClientOptionAll.GetCoveragErrorQE(searchModel.PlatformName, searchModel.ParticipantInfo.ParticipantId ?? "", platformConection?.Value!);
                    if (coverageCount!.OptionValue != "0")
                        search.DependentError = true;
                }
                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> InsertDependentProcessQE(InfoSessionModel searchModel)
        {
            try
            {
                OperationResultModel operationResult = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(searchModel.PlatformName);
                searchModel.ParticipantInfo!.AffiliateId = await GetAffiliate(platformConection, searchModel.ParticipantInfo.AffiliateName ?? "", searchModel.ParticipantInfo.AffiliateId, searchModel.PlatformName, searchModel.UserId, searchModel.ClientId);

                DependentProcessQEModel model = new()
                {
                    ProcessQE = searchModel.ProcessQE,
                    ParticipantInfo = searchModel.ParticipantInfo,
                    CO709 = new(),
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                    UserId = searchModel.UserId,
                    Address = searchModel.Address,
                    AvailablePlans = searchModel.AvailablePlans,
                    Dependents = searchModel.Dependents,
                    SpecificFields = searchModel.SpecificFields,
                    UserType = searchModel.UserType,
                };
                searchModel.ProcessQE!.BillingStartDate = searchModel.AvailablePlans!.AvailablePlansClient![0].CoverageBeginDate;
                GetDateConverage(searchModel.AvailablePlans!, searchModel.ProcessQE!);
                model.ProcessQE!.EligiibilityEndDate = (Convert.ToDateTime(model.ProcessQE.LastDayPreCobraCoverage2).AddMonths(int.Parse(model.ProcessQE!.ExtensionLength!))).AddYears(-1).ToShortDateString();
                ClientOptionModel optionModel709 = new()
                {
                    ClientOptionId = 709,
                    ClientId = model.ClientId,
                    PlatformName = model.PlatformName,
                    UserId = model.UserId,
                };
                ClientOptionResultModel? model709 = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel709, platformConection?.Value!);
                if (model709 != null)
                {
                    model.CO709 = model709;
                }
                ClientOptionModel optionModel286 = new()
                {
                    ClientOptionId = 286,
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                    UserId = searchModel.UserId,
                };
                ClientOptionResultModel? model286 = await _unitOfWork.ClientOptionAll.SearchClientOption(optionModel286, platformConection?.Value!);
                if (model286 != null && model286!.OptionValue == "1")
                    model.EventTypeQE = "A4";
                else
                    model.EventTypeQE = "03";
                int i = 0;
                foreach (AvailablePlansClientResultModel plan in model.AvailablePlans!.AvailablePlansClient!)
                {
                    ClientOptionResultModel? planCafe = await _unitOfWork.ClientOptionAll.GetCafePlan(searchModel.PlatformName, plan.PlanId, platformConection?.Value!);
                    if (planCafe != null)
                        model.AvailablePlans!.AvailablePlansClient![i].IsCafePlan = planCafe.OptionValue == "1" ? true : false;
                    i++;
                }
                var participantPromoted = await _unitOfWork.ParticipantPromoted.GetParticipantPromoted(model.ParticipantInfo.SocialSecurityNumber, model?.ParticipantInfo?.ParticipantId!, model?.ClientId!, searchModel.PlatformName, platformConection?.Value!);
                GenericUniqueValue? preferredLanguage = await _unitOfWork.GenericUniqueValue.GetPreferredLanguage(model?.PlatformName!, model?.ClientId!, platformConection?.Value!);
                operationResult = await _unitOfWork.ParticipantTransaction.InsertDependentProcessQE(model!, preferredLanguage?.Value, participantPromoted!);
                return Request.CreateResponse(HttpStatusCode.OK, operationResult);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform Dependent Process QE: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> UpdateGroup(UpdateModel updateModel)
        {
            try
            {
                OperationResultModel search = new();

                search = await _unitOfWork.ParticipantTransaction.UpdateGroup(updateModel);

                return Request.CreateResponse(HttpStatusCode.OK, search);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        private static void GetDateConverage(AvailablePlansClientModel availablePlans, ProcessQEInfoModel processQE)
        {
            processQE.LastDayPreCobraCoverage = availablePlans.AvailablePlansClient![0].LastDayPreCobra;
            processQE.LastDayPreCobraCoverage2 = availablePlans.AvailablePlansClient![0].LastDayPreCobra;
            processQE.CoverageBeginDate = availablePlans.AvailablePlansClient![0].CoverageBeginDate;

            if (availablePlans.AvailablePlansClient != null)
            {
                foreach (AvailablePlansClientResultModel newPlan in availablePlans.AvailablePlansClient)
                {
                    int dif = DateTimeExtensions.Years(Convert.ToDateTime(processQE.LastDayPreCobraCoverage), Convert.ToDateTime(newPlan.LastDayPreCobra));
                    if (dif < 0)
                        processQE.LastDayPreCobraCoverage = newPlan.LastDayPreCobra;
                    if (dif > 0)
                        processQE.LastDayPreCobraCoverage2 = newPlan.LastDayPreCobra;
                    if (DateTimeExtensions.Years(Convert.ToDateTime(processQE.LastDayPreCobraCoverage), Convert.ToDateTime(newPlan.CoverageBeginDate)) < 0)
                        processQE.CoverageBeginDate = newPlan.CoverageBeginDate;
                }
            }
            processQE.EligibilityStart = Convert.ToDateTime(processQE.LastDayPreCobraCoverage2).AddDays(1).ToShortDateString();
        }
        public async Task<HttpResponseMessage> Update(InfoSaveUpdateModel updateModel)
        {
            try
            {
                OperationResultModel result = new();
                GenericUniqueValue? platformConection = await _unitOfWork.GenericUniqueValue.GetPlatformConnection(updateModel.PlatformName);
                updateModel.ParticipantInfo!.AffiliateId = await GetAffiliate(platformConection, updateModel.ParticipantInfo.AffiliateName ?? "", updateModel.ParticipantInfo.AffiliateId, updateModel.PlatformName, updateModel.UserId, updateModel.ClientId);

                if (updateModel.Email != null && updateModel.Email.Count > 0)
                    updateModel.Documents = await _unitOfWork.DocumentOption.GetDocumentOptionById(updateModel.PlatformName, updateModel.Email, platformConection?.Value!);

                result = await _unitOfWork.ParticipantTransaction.Update(updateModel);
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        public async Task<HttpResponseMessage> CoverageAcceptable(CoverageAcceptable model)
        {
            try
            {
                OperationResultModel result = new();
                result = await _unitOfWork.ParticipantTransaction.CoverageAcceptable(model);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to peform search: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        #region Void Participant
        public async Task<OperationResultModel?> CheckForOpenCases(int pId, string platform)
        {
            if (pId == 0 || string.IsNullOrWhiteSpace(platform))
                return new OperationResultModel { Success = false, ResultDescription = "There was an error in the application. Try again." };
            var cases = await _unitOfWork.Cases.GetCases(pId, platform);
            if (cases != null)
                return new OperationResultModel { Success = false, ResultDescription = "This participant cannot be voided until Case # " + cases.CaseNumber.ToString() + " is closed." };
            return null;
        }
        public async Task<OperationResultModel?> CheckForPayment(int pId, string platform)
        {
            if (pId == 0 || string.IsNullOrWhiteSpace(platform))
                return new OperationResultModel { Success = false, ResultDescription = "There was an error in the application. Try again." };
            var payments = await _unitOfWork.Payments.GetPayment(pId, platform);
            if (payments != null && payments.ParymentId != 0)
                return new OperationResultModel { Success = false, ResultDescription = "This participant cannot be voided because they have already had payments accepted." };
            return null;
        }
        public async Task<OperationResultModel?> CheckForBankCheck(int pId, string platform)
        {
            if (pId == 0 || string.IsNullOrWhiteSpace(platform))
                return new OperationResultModel { Success = false, ResultDescription = "There was an error in the application. Try again." };
            var bankCheck = await _unitOfWork.BankCheck.GetBankCheck(pId, platform);
            if (bankCheck != null && bankCheck.CheckId != 0)
                return new OperationResultModel { Success = false, ResultDescription = "This participant cannot be voided because they have had checks issued to them." };
            return null;
        }
        public async Task<OperationResultModel?> CheckForParticipantNotFound(VoidModel voidModel)
        {
            if (voidModel.ParticipantId == 0 || string.IsNullOrWhiteSpace(voidModel.PlatformName))
                return new OperationResultModel { Success = false, ResultDescription = "There was an error in the application. Try again." };
            var participantFound = await _unitOfWork.VoidCheck.CheckIfParticipantExist(voidModel);
            if (participantFound != null)
                return new OperationResultModel { Success = false, ResultDescription = participantFound.ResultDescription };
            return null;
        }
        public async Task<HttpResponseMessage> VoidParticipant(VoidModel voidModel)
        {
            try
            {
                int result = await _unitOfWork.Void.UpdateParticipant(voidModel);
                if (result == 0)
                    return Request.CreateResponse(HttpStatusCode.BadRequest, new OperationResultModel { Success = false, ResultDescription = "Sorry, Error while updating participant !" });
                return Request.CreateResponse(HttpStatusCode.OK, new OperationResultModel { Success = true, ResultDescription = result.ToString() });
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to perform Void by Pid: {ex}", ex);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        #endregion
        private async Task<string> GetAffiliate(GenericUniqueValue? platformConection, string AffiliateName,string AffiliateId, string PlatformName, string UserId, string ClientId)
        {
            if (!string.IsNullOrWhiteSpace(AffiliateName) && string.IsNullOrWhiteSpace(AffiliateId))
            {
                AffiliateInfoModel affiliateInfo = new()
                {
                    PlatformName = PlatformName,
                    UserId = UserId,
                    ClientId = ClientId,
                    AffiliateName =  AffiliateName 
                };
                AffiliateModel? affiliate = await _unitOfWork.Affiliate.GetAffiliateName(affiliateInfo, platformConection?.Value!);

                if (affiliate != null)
                    return affiliate.AffiliateId.ToString();
                else
                    return string.Empty;
            }
            else
                return AffiliateId;
        }
    }
}

﻿using Core.Model;
using Core.Util;

namespace HealthEquity.COBRA.Participant.API
{
    public class ConsulHostedService : IHostedService
    {
        private readonly ILogger<ConsulHostedService> _logger;
        private readonly IConfiguration _configuration;
        private readonly string _apiName;
        private readonly int _apiPort;
        private readonly string _configUri;

        public ConsulHostedService(ILogger<ConsulHostedService> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _apiPort = _configuration.GetValue<int>("APIPort")!;
            _apiName = _configuration.GetValue<string>("APIName")!;
            _configUri = _configuration.GetValue<string>("ConfigUri")!;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {            
            try
            {
                _logger.LogInformation("Consul Hosted Service running. Registering");
                var uri = $"{_configUri}/Register";
                ServiceParams serviceParams = new()
                {
                    ServiceName = _apiName,
                    Port = _apiPort,
                    HealthCheckUri = $"api/v1/Participant/Status"
                };
                await ServiceUtil.SendAsync<ServiceParams, string>(uri, serviceParams);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to Register service");
            }            
        }

        public async Task StopAsync(CancellationToken cancellationToken)
        {            
            try
            {
                _logger.LogInformation("Consul Hosted Service stopping.");
                var uri = $"{_configUri}/Unregister";
                await ServiceUtil.SendAsync<string, string>(uri, _apiName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to Unregister service");
            }            
        }
    }
}

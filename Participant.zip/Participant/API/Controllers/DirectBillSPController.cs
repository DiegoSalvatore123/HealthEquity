﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/DirectBillSP")]
    [ApiController]
    public class DirectBillSPController : CobraControllerBase<DirectBillSPController, IDirectBillSPService>
    {
        public DirectBillSPController(IDirectBillSPService service, ILogger<DirectBillSPController> logger)
            : base(logger, service) { }

        [Authorize]
        [HttpPost("GetImpendingMedicareReport")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status403Forbidden)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetImpendingMedicareReport(PlatformModel model)
        {
            try
            {
                CheckPermissions(model);
                var errors = Service.CheckForClientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetImpendingMedicareReport(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to perform GetImpendingMedicareReport: {Message}/r/n{StackTrace}", ex.Message, ex.StackTrace);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}

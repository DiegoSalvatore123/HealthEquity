﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/ParticipantValidator")]
    [ApiController]
    public class ParticipantValidatorController : CobraControllerBase<ParticipantValidatorController, IValidatorService>
    {
        public ParticipantValidatorController(IValidatorService service, ILogger<ParticipantValidatorController> logger)
          : base(logger, service) { }

        [Authorize]
        [HttpPost("SearchBySSNHireDate")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> SearchBySSNHireDate(ValidateHireDataModel searchModel)
        {
            try
            {
                CheckPermissions(searchModel);
                //Check Inputs
                var errors = Service.CheckForBadRequest(searchModel);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.SearchBySSNHireDate(searchModel);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("SearchClientOption")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> SearchClientOption(ClientOptionModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.SearchClientOption(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("ClientOptionLookup")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> ClientOptionLookup(ClientOptionModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.SearchClientOptionLookup(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("IncludeSCCobraElig")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> IncludeSCCobraElig(SCCobraEligModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequestSCC(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.IncludeSCCobraElig(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("CobraHipaaNotice")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CobraHipaaNotice(UserClientModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.CobraHipaaNotice(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("QeExtension")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> QeExtension(QeCodeExtensionModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientQEBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.QeExtension(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("CoveragExisting")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CoveragExisting(ParticipantInfoModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.CoveragExisting(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("SubmitMLRQuoteItRequest")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> SubmitMLRQuoteItRequest(AvailablePlans model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientQEBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.SubmitMLRQuoteItRequest(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("CheckMLRQuoteItStatus")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CheckMLRQuoteItStatus(AvailablePlans model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientQEBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.CheckMLRQuoteItStatus(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("GetMLRQuoteGetRates")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetMLRQuoteGetRates(AvailablePlans model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientQEBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetMLRQuoteGetRates(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("GetPlansDates")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPlansDates(PlanMLRModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForCLientQEBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetPlansDates(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}

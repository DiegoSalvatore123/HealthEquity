﻿using Microsoft.AspNetCore.Mvc;
namespace API.Controllers
{
    public class CobraControllerBase<TSelf, TService> : ControllerBase
    {
        public ILogger<TSelf> Logger { get; private set; }
        public TService Service { get; private set; }
        protected CobraControllerBase(ILogger<TSelf> logger, TService service)
        {
            Logger = logger ?? throw new ArgumentNullException(nameof(logger));
            Service = service ?? throw new ArgumentNullException(nameof(service));
        }

        protected void CheckPermissions(Object input)
        {
            var platformClaim = User.Claims.Where(c => c.Type == "sid").FirstOrDefault()?.Value;
            var platformName = input?.GetType()?.GetProperty("PlatformName")?.GetValue(input, null)?.ToString();
            if (string.IsNullOrEmpty(platformClaim))
            {
                throw new Exception("Platform is not set in Claims");
            }
            if (!string.Equals(platformName, platformClaim, StringComparison.OrdinalIgnoreCase))
            {
                throw new Exception("Platform does not match");
            }
            var clientId = input?.GetType()?.GetProperty("ClientId")?.GetValue(input, null)?.ToString();
            var clientClaim = User.Claims.Where(c => c.Type == "cid").FirstOrDefault()?.Value;
            if (!string.IsNullOrWhiteSpace(clientId) && !string.IsNullOrWhiteSpace(clientClaim) && !string.Equals(clientClaim, clientId))
            {
                throw new Exception($"Client ID does not match");
            }
            var userId = input?.GetType()?.GetProperty("UserId")?.GetValue(input, null)?.ToString();
            var userClaim = User.Claims.Where(c => c.Type == platformClaim).FirstOrDefault()?.Value;
            if (!string.IsNullOrWhiteSpace(userId) && !string.IsNullOrWhiteSpace(userClaim) && !string.Equals(userClaim, userId))
            {
                throw new Exception("User ID does not match");
            }
        }
    }
}


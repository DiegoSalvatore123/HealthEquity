﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/ParticipantDocument")]
    [ApiController]
    public class ParticipantDocumentController : CobraControllerBase<ParticipantDocumentController, IDocumentService>
    {
        public ParticipantDocumentController(IDocumentService service, ILogger<ParticipantDocumentController> logger)
            : base(logger, service) { }

        [Authorize]
        [HttpPost("GetDocumentBySid")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetDocumentBySid(DocumentModel documentModel)
        {
            try
            {
                CheckPermissions(documentModel);
                var errors = Service.CheckForBadRequest(documentModel);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetDocument(documentModel);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Get Image: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/Participant")]
    [ApiController]
    public class ParticipantController : CobraControllerBase<ParticipantController, IParticipantService>
    {
        public ParticipantController(IParticipantService service, ILogger<ParticipantController> logger)
           : base(logger, service) { }

        [Authorize]
        [HttpPost("Search")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> Search(SearchModel searchModel)
        {
            try
            {
                CheckPermissions(searchModel);
                //Check Inputs
                var errors = Service.CheckForBadRequest(searchModel);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.Search(searchModel);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [ProducesResponseType(StatusCodes.Status200OK)]
        [AllowAnonymous]
        [HttpGet("Status")]
        public Task<IActionResult> Status()
        {
            return Task.FromResult((IActionResult)Ok("OK"));
        }
    }
}

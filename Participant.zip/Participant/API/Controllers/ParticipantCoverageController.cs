﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/Coverage")]
    [ApiController]
    public class ParticipantCoverageController :  CobraControllerBase<ParticipantCoverageController, ICoverageService>
    {
        public ParticipantCoverageController(ICoverageService service, ILogger<ParticipantCoverageController> logger)
           : base(logger, service) { }

        [Authorize]
        [HttpPost("CoverageError")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CoverageError(ParticipantInfoModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.CoverageError(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("CoverageErrorQE")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CoverageErrorQE(ParticipantInfoModel model)
        {
            try
            {
                CheckPermissions(model);
                //Check Inputs
                var errors = Service.CheckForBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.CoverageErrorQE(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Search: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [ProducesResponseType(StatusCodes.Status200OK)]
        [AllowAnonymous]
        [HttpGet("Status")]
        public Task<IActionResult> Status()
        {
            return Task.FromResult((IActionResult)Ok("OK"));
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Text;

namespace API.Controllers
{
    [Route("api/v1/DirectBill")]
    [ApiController]
    public class DirectBillController : CobraControllerBase<DirectBillController, IDirectBillService>
    {
        public DirectBillController(IDirectBillService service, ILogger<DirectBillController> logger)
          : base(logger, service) { }

        [Authorize]
        [HttpPost("GetClientAcivePlans")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetClientAcivePlans(PlatformModel model)
        {
            try
            {
                CheckPermissions(model);
                var errors = Service.CheckForClientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetClientAcivePlans(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Get Active Plans by Client Id: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("GetPastDue")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetPastDue(SearchModel model)
        {
            try
            {
                CheckPermissions(model);
                var errors = Service.CheckForClientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetPastDue(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Get Past Due by Client Id: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("GetClientPlans")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetClientPlans(PlatformModel model)
        {
            try
            {
                CheckPermissions(model);
                var errors = Service.CheckForClientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetClientPlans(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Get AdminFee by Client Id: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("GetClientEventName")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetClientEventName(PlatformModel model)
        {
            try
            {
                CheckPermissions(model);
                var errors = Service.CheckForClientBadRequest(model);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.GetClientEventName(model);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to Get AdminFee by Client Id: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [Authorize]
        [HttpPost("SearchInfoToCancel")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> SearchInfoToCancel(PastDueInfoModel searchModel)
        {
            try
            {
                CheckPermissions(searchModel);
                //Check Inputs
                var errors = Service.CheckForClientBadRequest(searchModel);
                if (errors.Count > 0)
                {
                    var errorMessage = new StringBuilder();
                    foreach (var error in errors)
                        errorMessage.AppendLine(error);
                    return BadRequest(errorMessage.ToString());
                }
                HttpResponseMessage message = await Service.SearchInfoToCancel(searchModel);
                var response = await this.StandardizeResponse(message);
                return response;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to perform search by Pid: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
    }
}

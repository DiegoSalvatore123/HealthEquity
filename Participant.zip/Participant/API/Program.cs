using Core.Interfaces;
using DataAccess;
using HealthEquity.COBRA.Participant.API;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;

IConfiguration configuration = new ConfigurationBuilder()
     .AddJsonFile($"envsettings.json")
     .AddEnvironmentVariables()
        .Build();

var builder = WebApplication.CreateBuilder(new WebApplicationOptions
{
    EnvironmentName = configuration.GetValue<string>("ENVIRONMENT")
});

// Setup JWT Bearer
ICobraConfig cobraConfig = new CobraConfig(builder.Configuration);
var publicKey = await cobraConfig.GetResource("Authentication/JWTPublicKey");
if (publicKey == null)
{
    throw new Exception("JWT Public Key is not found");
}
RSA rsaPublic = RSA.Create(keySizeInBits: 2048);
rsaPublic.ImportFromPem(publicKey.ToCharArray());
var audienceSigningKey = new RsaSecurityKey(rsaPublic);
builder.Services.AddAuthentication(authOptions =>
{
    authOptions.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    authOptions.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateAudience = false,
        ValidateIssuer = false,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = audienceSigningKey,
        ValidateLifetime = true
    };
});

// Setup URL for API
string localIPAddress;
using (Socket socket = new(AddressFamily.InterNetwork, SocketType.Dgram, 0))
{
    socket.Connect("8.8.8.8", 65530);
    localIPAddress = (socket.LocalEndPoint as IPEndPoint)!.Address.ToString();
}

var apiPort = builder.Configuration.GetValue<string>("APIPort")!;
var apiUrl = $"http://{localIPAddress}:{apiPort}";

builder.Logging.AddLog4Net("log4net.config");
builder.Services.AddDataAccessServices();
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "COBRA Participant API", Version = "v1" });
    c.AddSecurityDefinition("JWT",
        new OpenApiSecurityScheme
        {
            Description = "JWT Authorization header using the Bearer scheme.",
            Name = "Authorization",
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.Http,
            Scheme = "Bearer"
        });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "JWT"
                }
            },
            new List<string>()
        }
    });
});

//comment to run without Consul
builder.WebHost.UseUrls(apiUrl.Trim());
builder.Services.AddHostedService<ConsulHostedService>();

builder.Services.AddWindowsService();

var app = builder.Build();

if (!app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseDeveloperExceptionPage();

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();

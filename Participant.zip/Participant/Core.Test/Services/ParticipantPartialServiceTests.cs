﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Reflection;
using Xunit;
namespace Core.Test.Services
{
    public class ParticipantPartialServiceTests
    {
        private ILogger<PartialService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public PartialService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<PartialService>>().Object;

            var participantPartialService = new PartialService(_logger, unitOfWork.Object);
            return participantPartialService;
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetActivityByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetActivityByPid_GivenparticipantIdModelReturnsAtLeastOneActivityModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<ActivityModel>();
            unitOfWork.Setup(x => x.Activity.GetActivityByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1"
            };

            //act
            var result = await testArrange.GetActivityByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetTypeOfActivityByPid_GivenparticipantIdModelReturnsAtLeastOneActivityModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<ActivityModel>();
            unitOfWork.Setup(x => x.Activity.GetActivityFilteringByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1"
            };

            //act
            var result = await testArrange.GetActivityByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByParentPid_GivenparticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetDependentByParentPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetDependentByParentPid_GivenparticipantIdModelReturnsAtLeastOneDependentDetailModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var dependList = new List<DependentModel>();
            var dependDetailList = new List<DependentDetailModel>();
            unitOfWork.Setup(x => x.Dependent.GetDependentByParentPid(It.IsAny<ParticipantIdModel>(), null)).ReturnsAsync(dependList);            
            unitOfWork.Setup(x => x.DependentDetail.GetDependentDetailByParentPidAndPid(It.IsAny<ParticipantIdModel>(), "1")).ReturnsAsync(dependDetailList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new();

            //act
            var result = await testArrange.GetDependentByParentPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModellIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantGetCoverageModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetCoverageByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModelReturnsAtLeastOneCoverageModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<CoverageModel>();
            unitOfWork.Setup(x => x.Coverage.GetCoverageByPid(It.IsAny<ParticipantGetCoverageModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantGetCoverageModel? participantIdModel = new()
            {
                ParticipantId = "1"
            };

            //act
            var result = await testArrange.GetCoverageByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFieldsByPid_GivenparticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetSpecificFieldsByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetSpecificFieldsByPid_GivenParticipantIdModelReturnsAtLeastOneSpecificFieldsModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SpecificFieldsResultModel>();
            unitOfWork.Setup(x => x.SpecificField.GetSpecificFieldsByPid(It.IsAny<ParticipantIdModel>(), null)).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1"
            };

            //act
            var result = await testArrange.GetSpecificFieldsByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenparticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetCarrierRemittanceByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenparticipantIdModelReturnsAtLeastOneNoticeModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<CarrierRemittanceModel>();
            unitOfWork.Setup(x => x.CarrierRemittance.GetCarrierRemittanceByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1",
                ClientId = "1",
                UserId = "1",
                PlatformName = "CXO"
            };

            //act
            var result = await testArrange.GetCarrierRemittanceByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenparticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetPaymentHistoryByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenparticipantIdModelReturnsAtLeastOneNoticeModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<PaymentHistoryModel>();
            unitOfWork.Setup(x => x.PaymentHistory.GetPaymentHistoryByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1",
                ClientId = "1",
                UserId = "1",
                PlatformName = "CXO"
            };

            //act
            var result = await testArrange.GetPaymentHistoryByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public void CheckForBadRequestParticipantIdModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new()
            {
                ParticipantId = "ParticipantIdTest",
                PlatformName = "PlatformNameTest"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequestParticipantIdModel_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: participantIdModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequestParticipantIdModel_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public void CheckForBadRequestInfoModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel infoModel = new()
            {
                ParticipantId = "ParticipantIdTest",
                PlatformName = "PlatformNameTest"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: infoModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequestInfoModel_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: infoModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequestInfoModel_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel infoModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: infoModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public void CheckForBadRequestParticipantDependentCoverageModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantDependentCoverageModel dependenteCoverageModel = new()
            {
                ParticipantCoverageId = "ParticipantCoverageIdTest",
                PlatformName = "PlatformNameTest",
                ClientId = "ClientIdTest"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: dependenteCoverageModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequestParticipantDependentCoverageModel_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantDependentCoverageModel dependenteCoverageModel = new()
            {
                ParticipantCoverageId = "ParticipantCoverageIdTest",
                PlatformName = "PlatformNameTest"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: dependenteCoverageModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public async Task GetDependentCoveragesByParticipantCoverageIdAndClientId_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            List<ParticipantDependentCoverageResultModel>? searchDependentCoverages = new();
            unitOfWork.Setup(x => x.DependentCoverage.GetParticipantCoverageByParticipantCoverageIdAndClientId("1","1","CXO")).ReturnsAsync(searchDependentCoverages);
            ParticipantCoveragePlanOptionResultModel? dependentCoveragePlanOption = new();
            unitOfWork.Setup(x => x.ParticipantCoveragePlanOption.GetParticipantCoveragePlanOption("1","CXO")).ReturnsAsync(dependentCoveragePlanOption);
            ParticipantDependentCoverageModel participantDependentCoverageModel = new()
            {
                ParticipantCoverageId = "1",
                ClientId = "1",
                PlatformName = "CXO"
            };

            var testArrange = TestArrange(unitOfWork);
            var planOptionResultModel = new ParticipantDependentCoveragesPlanOptionResultModel
            {
                planOption = dependentCoveragePlanOption,
                DependentCoverages = searchDependentCoverages
            };

            //act
            var result = await testArrange.GetDependentCoveragesByParticipantCoverageIdAndClientId(model: participantDependentCoverageModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfodModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetParticipantDependentAddress(model: infoModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModelReturnsAtLeastOneDependentDetailModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var dependentAddress = new CurrentParticipantAddressResultModel();
            unitOfWork.Setup(x => x.ParticipantDependentAddress.GetParticipantDependentAddress(It.IsAny<InfoModel>())).ReturnsAsync(dependentAddress);
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = new();

            //act
            var result = await testArrange.GetParticipantDependentAddress(model: infoModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model: participantIdModel!);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var eligibilityTransmissionModels = new List<EligibilityTransmissionModel>();
            var participantIdModel = new ParticipantIdModel();
            unitOfWork.Setup(x => x.EligibilityTransmission.GetEligibilityTransmissionDetail(participantIdModel.PlatformName, participantIdModel.ParticipantId)).ReturnsAsync(eligibilityTransmissionModels);
            var testArrange = TestArrange(unitOfWork);

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantSPServiceTests
    {
        private ILogger<SPService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public SPService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<SPService>>().Object;

            var participantInnerService = new SPService(_logger, unitOfWork.Object);
            return participantInnerService;
        }
        [Fact]
        public async Task GetSubsidybyPid_GivenGetSubsidybyPidReturnsASubsidyResultModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var subsidyResult = new List<SubsidyResultModel>();
            unitOfWork.Setup(x => x.Subsidy.GetSubsidybyPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(subsidyResult);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new();

            //act
            var result = await testArrange.GetSubsidybyPid(model: participantIdModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetSubsidybyPid_GivenParticipantIdeIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new();

            //act
            var result = await testArrange.GetSubsidybyPid(model: participantIdModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task RemoveQE_GivenRemoveQESuccessTrueReturnsARemoveQEResultModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var removeQEResultModel = new OperationResultModel() { 
                ResultDescription = "DescriptionTest",
                Success = true
            };
            var removeQEDetail = new RemoveQEDetail();
            unitOfWork.Setup(x => x.RemoveQE.RemoveQE(It.IsAny<RemoveQEModel>())).ReturnsAsync(removeQEResultModel);
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel? removeQEModel = new();

            //act
            var result = await testArrange.RemoveQE(model: removeQEModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task RemoveQE_GivenRemoveQESuccessFalseReturnsARemoveQEResultModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var removeQEResultModel = new OperationResultModel()
            {
                ResultDescription = "DescriptionTest",
                Success = false
            };
            var systemSettingModel = new SystemSettingModel()
            {
                UsedBy = "Test",
                SettingValue = "ValueTest",
                Explanation = "ExplanationTest",
                SettingNameId = "IdTest"
            };
            var removeQEDetail = new RemoveQEDetail()
            {
                TextMessage = "Test",
            };
            unitOfWork.Setup(x => x.RemoveQE.RemoveQE(It.IsAny<RemoveQEModel>())).ReturnsAsync(removeQEResultModel);
            unitOfWork.Setup(x => x.SystemSetting.GetSystemSettingByName(It.IsAny<String>(), It.IsAny<String>())).ReturnsAsync(systemSettingModel);
            unitOfWork.Setup(x => x.RemoveQEDetail.GetRemoveQEDetailByPid(It.IsAny<RemoveQEModel>())).ReturnsAsync(removeQEDetail);
            unitOfWork.Setup(x => x.EmailNotification.Add(It.IsAny<EmailNotificationModel>(), It.IsAny<String>()));
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel? removeQEModel = new()
            {
                UserId = "1"
            };

            //act
            var result = await testArrange.RemoveQE(model: removeQEModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
            Assert.Equal("{\"Success\":false,\"ResultDescription\":\"DescriptionTest\",\"ErrorDetails\":\"\",\"ParticipantId\":\"\",\"DependentError\":false}", actualMessage);
        }

        [Fact]
        public async Task RemoveQE_GivenRemoveQEIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel? removeQEModel = new();

            //act
            var result = await testArrange.RemoveQE(model: removeQEModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
        [Fact]
        public async Task GetBilling_GivenGetBillingReturnsABillingDetailModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var billingDetail = new BillingDetailModel();
            unitOfWork.Setup(x => x.BillingDetail.GetBillingDetail(It.IsAny<ParticipantIdModel>())).ReturnsAsync(billingDetail);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = "1",
                ClientId = "1",
                UserId = "1",
                PlatformName = "CXO"
            };            

            //act
            var result = await testArrange.GetBilling(model: participantIdModel);
            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetBilling_GivenParticipantIdeIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new();
            //act
            var result = await testArrange.GetBilling(model: participantIdModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public void CheckForBadRequest_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new()
            {
                ParticipantId = "ParticipantIdTest",
                PlatformName = "PlatformNameTest"
            };            

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequest_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: participantIdModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequest_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public void CheckForBadRequestRemoveQE_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel removeQEModel = new()
            {
                ParticipantId = "ParticipantIdTest",
                PlatformName = "PlatformNameTest",
                UserId = "UserIdTest",
                Reason = "ReasonTest"
            };

            //act
            var result = testArrange.CheckForBadRequestRemoveQE(model: removeQEModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequestRemoveQE_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel? removeQEModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequestRemoveQE(model: removeQEModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequestRemoveQE_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            RemoveQEModel? removeQEModel = new();

            //act
            var result = testArrange.CheckForBadRequestRemoveQE(model: removeQEModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
    }
}
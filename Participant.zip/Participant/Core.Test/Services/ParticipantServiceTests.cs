﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantServiceTests
    {
        private ILogger<ParticipantService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public ParticipantService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<ParticipantService>>().Object;

            var participantService = new ParticipantService(_logger, unitOfWork.Object);
            return participantService;
        }
        [Fact]
        public async Task Search_GivenSearchReturnsAtLeastOneSearchResultModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SearchResultModel>();
            unitOfWork.Setup(x => x.Participant.Search(It.IsAny<SearchModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            SearchModel? searchModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.Search(searchModel: searchModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }

        [Fact]
        public async Task Search_GivenClientIdIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            SearchModel? searchModel = new()
            {
                ClientId = ""
            };

            //act
            var result = await testArrange.Search(searchModel: searchModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public void CheckForBadRequest_PropertiesIsNullOrWhiteSpace_ReturnsNotOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SearchResultModel>();
            List<SearchResultModel>? searchResultModels = null;
            unitOfWork.Setup(x => x.Participant.Search(It.IsAny<SearchModel>())).ReturnsAsync(searchResultModels);
            var testArrange = TestArrange(unitOfWork);
            SearchModel searchModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: searchModel);

            //assert
            Assert.Equal("There was an error in the Application while performing the Search. Try again!", result[0]);
        }
        [Fact]
        public void CheckForBadRequest_ClientIdIsNullOrWhiteSpace_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SearchResultModel>();
            List<SearchResultModel>? searchResultModels = null;
            unitOfWork.Setup(x => x.Participant.Search(It.IsAny<SearchModel>())).ReturnsAsync(searchResultModels);
            var testArrange = TestArrange(unitOfWork);
            SearchModel? searchModel = null;

            //act
            //assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: searchModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
    }
}

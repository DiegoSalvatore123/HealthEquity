﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class DirectBillServiceTests
    {
        private ILogger<CobraService>? _logger;
        public IUnitOfWork? _unitOfWork;

        public DirectBillService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<CobraService>>().Object;

            var directBillService = new DirectBillService(_logger, unitOfWork.Object);
            return directBillService;
        }
        [Fact]
        public void CheckForBadRequest_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel platformModel = new()
            {
                ClientId = "ClientIdTest",
                PlatformName = "PlatformNameTest"
            };

            //act
            var result = testArrange.CheckForClientBadRequest(platformModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequest_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel? platformModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForClientBadRequest(platformModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequest_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel platformModel = new();

            //act
            var result = testArrange.CheckForClientBadRequest(platformModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again!", result[0]);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var dBPastDueSearchModels = new List<DBPastDueModel>();
            unitOfWork.Setup(x => x.DBPastDue.GetPastDue(It.IsAny<SearchModel>())).ReturnsAsync(dBPastDueSearchModels);
            var testArrange = TestArrange(unitOfWork);
            SearchModel? dBPastDueSearchModel = new();

            //act
            var result = await testArrange.GetPastDue(dBPastDueSearchModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            SearchModel? dBPastDueSearchModel = new();

            //act
            var result = await testArrange.GetPastDue(dBPastDueSearchModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
            Assert.Equal("\"Object reference not set to an instance of an object.\"", actualMessage);
        }
    }
}

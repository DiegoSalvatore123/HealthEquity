﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantInnerServiceTests
    {
        private ILogger<InnerService>? _logger;
        public InnerService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<InnerService>>().Object;

            var participantInnerService = new InnerService(_logger, unitOfWork.Object);
            return participantInnerService;
        }
        public static InnerService DefautlTestTemplate(ILogger<InnerService> _logger, IUnitOfWork _unitOfWork)
        {
            if (_logger is null) throw new ArgumentNullException(nameof(_logger));
            if (_unitOfWork is null) throw new ArgumentNullException(nameof(_unitOfWork));

            var participantInnerService = new InnerService(_logger, _unitOfWork);
            return participantInnerService;
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenSearchPlanNameByPidReturnsAtLeastOnePlanModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<PlanModel>();
            unitOfWork.Setup(x => x.QE.SearchPlanNameByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.SearchPlanNameByPid(model: participantIdModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = new()
            {
                ParticipantId = ""
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model: participantIdModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public void CheckForBadRequest_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new()
            {
                ParticipantId = "ParticipantIdTest",
                PlatformName = "PlatformNameTest"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequest_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel? participantIdModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: participantIdModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequest_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantIdModel participantIdModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: participantIdModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
    }
}
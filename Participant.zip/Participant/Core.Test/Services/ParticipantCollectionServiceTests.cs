﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantCollectionServiceTests
    {
        private ILogger<CollectionService>? _logger;
        public IUnitOfWork? _unitOfWork;

        public CollectionService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<CollectionService>>().Object;

            var participantCollectionService = new CollectionService(_logger, unitOfWork.Object);
            return participantCollectionService;
        }

        [Fact]
        public async Task GetStates_GivenInfoModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetStates(searchModel: infoModel);
#pragma warning restore CS8604 // Possible null reference argument.
            _ = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }

        [Fact]
        public async Task GetStates_GivenInfoModelReturnsAtLeastOneStateModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<StateModel>();
            unitOfWork.Setup(x => x.State.GetStates(It.IsAny<InfoModel>(), null)).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = new()
            {
                ParticipantId = "1",
                PlatformName = "Test",
            };

            //act
            var result = await testArrange.GetStates(searchModel: infoModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }

        [Fact]
        public async Task GetEmployeeClasses_GivenInfoModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetEmployeeClasses(searchModel: infoModel);
#pragma warning restore CS8604 // Possible null reference argument.
            _ = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }

        [Fact]
        public async Task GetEmployeeClasses_GivenInfoModelReturnsAtLeastOneStateModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<EmployeeClassModel>();
            unitOfWork.Setup(x => x.EmployeeClass.GetEmployeeClasses(It.IsAny<InfoModel>(), null)).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = new()
            {
                ParticipantId = "1",
                PlatformName = "CXO",
                ClientId = "1",
                DivisionLevelAccess = "1",
            };

            //act
            var result = await testArrange.GetEmployeeClasses(searchModel: infoModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }

        [Fact]
        public async Task GetDivisionLocations_GivenInfoModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetDivisionLocations(searchModel: infoModel);
#pragma warning restore CS8604 // Possible null reference argument.
            _ = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }

        [Fact]
        public async Task GetDivisionLocations_GivenInfoModelReturnsAtLeastOneStateModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<AffiliateModel>();
            unitOfWork.Setup(x => x.Affiliate.GetDivisionLocations(It.IsAny<InfoModel>(), null)).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = new()
            {
                ParticipantId = "1",
                PlatformName = "Test",
            };

            //act
            var result = await testArrange.GetDivisionLocations(searchModel: infoModel);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }

        [Fact]
        public async Task GetQualifyingEventType_GivenModelIsNull_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            QualifyingEventTypeModel? model = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.GetQualifyingEventType(model: model);
#pragma warning restore CS8604 // Possible null reference argument.
            _ = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }

        [Fact]
        public async Task GetQualifyingEventType_GivenModelReturnsAtLeastOneModel_ReturnsHttpStatusCodeOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<QeMetaDatas>();
            unitOfWork.Setup(x => x.QualifyingEventType.GetQualifyingEventType(It.IsAny<QualifyingEventTypeModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            QualifyingEventTypeModel? model = new()
            {
                QualifyingEventType = "Test",
                PlatformName = "Test",
                ClientId = "Test"
            };

            //act
            var result = await testArrange.GetQualifyingEventType(model: model);

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
    }
}

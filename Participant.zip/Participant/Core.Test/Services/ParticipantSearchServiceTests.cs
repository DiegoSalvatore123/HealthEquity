﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantSearchServiceTests
    {
        private ILogger<SearchService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public SearchService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<SearchService>>().Object;

            var participantPartialService = new SearchService(_logger, unitOfWork.Object);
            return participantPartialService;
        }
        [Fact]
        public async Task SearchByPid_GivenSearchByPidReturnsAnInfoResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var infoResult = new InfoResultModel();
            unitOfWork.Setup(x => x.Info.SearchByPid(It.IsAny<InfoModel>())).ReturnsAsync(infoResult);

            var testArrange = TestArrange(unitOfWork);
            InfoModel? participantInfoModel = new()
            {
                PlatformName = "Test",
                ClientId = "1"
            };

            //act
            var result = await testArrange.SearchByPid(searchModel: participantInfoModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByPid_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? participantInfoModel = new()
            {
                ClientId = "1",
                PlatformName = "Test",
                ParticipantId = "1"
            };

            //act
            var result = await testArrange.SearchByPid(searchModel: participantInfoModel);
            
            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }

        [Fact]
        public void CheckForBadRequestBySSN_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var infoResult = new InfoResultModel();
            unitOfWork.Setup(x => x.Info.SearchByPid(It.IsAny<InfoModel>())).ReturnsAsync(infoResult);
            var testArrange = TestArrange(unitOfWork);
            InfoModel infoModel = new()
            {
                ClientId = "3313",
                PlatformName = "CXO"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: infoModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequestBySSN_ClientIdIsNullOrWhiteSpace_ReturnsNotOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel infoModel = new()
            {
                ClientId = "",
                PlatformName = ""
            };

            //act
            var result = testArrange.CheckForBadRequest(model: infoModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }

        [Fact]
        public void CheckForBadRequestBySSN_ClientIdIsNullOrWhiteSpace_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
            //assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: infoModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }

        [Fact]
        public void CheckForBadRequest_ClientIdIsNullOrWhiteSpace_ReturnsNotOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SearchResultModel>();
            List<SearchResultModel>? searchResultModels = null;
            unitOfWork.Setup(x => x.Participant.Search(It.IsAny<SearchModel>())).ReturnsAsync(searchResultModels);
            var testArrange = TestArrange(unitOfWork);
            SearchModel? searchModel = new();
            InfoModel? infoModel = new()
            {
                ClientId = ""
            };

            //act
            var result = testArrange.CheckForBadRequest(model: infoModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }

        [Fact]
        public void CheckForBadRequest_ClientIdIsNullOrWhiteSpace_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new List<SearchResultModel>();
            List<SearchResultModel>? searchResultModels = null;
            unitOfWork.Setup(x => x.Participant.Search(It.IsAny<SearchModel>())).ReturnsAsync(searchResultModels);
            var testArrange = TestArrange(unitOfWork);
            InfoModel? infoModel = null;

            //act
            //assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: infoModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
    }
}
﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;

namespace Core.Test.Services
{
    public class ParticipantTransactionControllerTests
    {
        private ILogger<TransactionService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public TransactionService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<TransactionService>>().Object;

            var participantTransactionService = new TransactionService(_logger, unitOfWork.Object);
            return participantTransactionService;
        }
        [Fact]
        public async Task UpdateDisability_GivenUpdateDisabilityReturnsAnOperationResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var disabilityResult = new OperationResultModel();
            unitOfWork.Setup(x => x.ParticipantTransaction.UpdateDisability(It.IsAny<DisabilityUpdateModel>())).ReturnsAsync(disabilityResult);

            var testArrange = TestArrange(unitOfWork);
            DisabilityUpdateModel? disabilityUpdateModel = new()
            {
                ParticipantId = 1,
                Name = "name",
                SurchargePercent = (decimal?)0.1,
                EligibilityEnd =DateTime.Now,
                DeterminationDate =DateTime.Now,
                ClientId = "1",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateDisability(model: disabilityUpdateModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task UpdateDisability_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            DisabilityUpdateModel? disabilityUpdateModel = new()
            {
                ParticipantId = 1,
                Name = "name",
                SurchargePercent = (decimal?)0.1,
                EligibilityEnd = DateTime.Now,
                DeterminationDate = DateTime.Now,
            };

            //act
            var result = await testArrange.UpdateDisability(model: disabilityUpdateModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task UpdateEmployerChange_GivenUpdateEmployerChangeReturnsAnOperationResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var EmployerChangeResult = new OperationResultModel();
            unitOfWork.Setup(x => x.ParticipantTransaction.UpdateEmployerChange(It.IsAny<EmployerChangeUpdateModel>())).ReturnsAsync(EmployerChangeResult);

            var testArrange = TestArrange(unitOfWork);
            EmployerChangeUpdateModel? employerChangeUpdateModel = new()
            {
                ParticipantId = 1,
                Name = "name",
                NewClientId = "1",
                ClientId = "1",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateEmployerChange(model: employerChangeUpdateModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task UpdateEmployerChange_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            EmployerChangeUpdateModel? employerChangeUpdateModel = new()
            {
                ParticipantId = 1,
                Name = "name",
                NewClientId = "1"
            };

            //act
            var result = await testArrange.UpdateEmployerChange(model: employerChangeUpdateModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        //
        [Fact]
        public async Task InsertRehire_GivenUpdateDisabilityReturnsAnOperationResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var disabilityResult = new OperationResultModel();
            var genericUniqueValue = new GenericUniqueValue() {Value = "Test" };
            var testArrange = TestArrange(unitOfWork);
            ParticipantInsertModel infoRehireModel = new()
            {
                ParticipantInfo = new(),
                Dependents = null,
                Co709 = "Test",
                Co713 = "Test",
                Status = "Test",
                ParticipantType = "Test",
                RehireDB = "Test",
                ClientId = "Test",
                PlatformName = "Test",
                UserId = "Test"
            };
            AffiliateInfoModel affiliateInfo = new()
            {
                PlatformName = "Test",
                UserId = "Test",
                ClientId = "Test",
                AffiliateName = "Test"
            };
            AffiliateModel? affiliate = new();
            unitOfWork.Setup(x => x.ParticipantTransaction.UpdateDisability(It.IsAny<DisabilityUpdateModel>())).ReturnsAsync(disabilityResult);
            unitOfWork.Setup(x => x.Affiliate.GetAffiliateName(It.IsAny<AffiliateInfoModel>(), "")).ReturnsAsync(affiliate);
            unitOfWork.Setup(x => x.GenericUniqueValue.GetPlatformConnection(It.IsAny<string>())).ReturnsAsync(genericUniqueValue);

            //act
            var result = await testArrange.Insert(participantInsertModel: infoRehireModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task InsertRehire_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantInsertModel infoRehireModel = new()
            {
                ParticipantInfo = new(),
                Dependents = null,
                Co709 = "Test",
                Co713 = "Test",
                Status = "Test",
                ParticipantType = "Test",
                RehireDB = "Test",
                ClientId = "Test",
                PlatformName = "Test",
                UserId = "Test"
            };

            //act
            var result = await testArrange.Insert(participantInsertModel: infoRehireModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public void CheckForBadRequest_GivenInfoRehireModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantInsertModel infoRehireModel = new()
            {
                ParticipantInfo = new(),
                Dependents = null,
                Co709 = "Test",
                Co713 = "Test",
                Status = "Test",
                ParticipantType = "Test",
                RehireDB = "Test",
                ClientId = "Test",
                PlatformName = "Test",
                UserId = "Test"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: infoRehireModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequest_GivenInfoRehireModel_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantInsertModel? infoRehireModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: infoRehireModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequest_GivenPlatformModel_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel platformModel = new()
            {
                ClientId = "Test",
                PlatformName = "Test",
                UserId = "Test"
            };

            //act
            var result = testArrange.CheckForBadRequest(model: platformModel);

            //assert
            Assert.Empty(result);
        }
        [Fact]
        public void CheckForBadRequest_GivenPlatformModel_ThrowNewArgumentNullException()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel? platformModel = null;

            //act & assert
#pragma warning disable CS8604 // Possible null reference argument.
            Assert.Throws<ArgumentNullException>(() => testArrange.CheckForBadRequest(model: platformModel));
#pragma warning restore CS8604 // Possible null reference argument.
        }
        [Fact]
        public void CheckForBadRequest_GivenPlatformModel_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            PlatformModel platformModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: platformModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public void CheckForBadRequest_ReturnError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            ParticipantInsertModel infoRehireModel = new();

            //act
            var result = testArrange.CheckForBadRequest(model: infoRehireModel);

            //assert
            Assert.Equal("There was an error in the Application. Try again.", result[0]);
        }
        [Fact]
        public async Task CreateAddress_GivenAddressInsertReturnsAnOperationResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var updateAddressResult = new OperationResultModel();
            unitOfWork.Setup(x => x.ParticipantTransaction.CreateAddress(It.IsAny<AddressModel>())).ReturnsAsync(updateAddressResult);

            var testArrange = TestArrange(unitOfWork);
            AddressModel? addressUpdateModel = new()
            {
                ParticipantId = 1,
                DependentId = 1,
                Address1 = "test",
                Address2 = "test",
                City = "test",
                State = "test",
                Zip = "test",
            };

            //act
            var result = await testArrange.InsertAddress(searchModel: addressUpdateModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task CreateAddress_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            AddressModel? addressUpdateModel = new()
            {
            };

            //act
            var result = await testArrange.InsertAddress(searchModel: addressUpdateModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task UpdateCoverageChange_GivenCoverageNewUpdateDropReturnsAnOperationResultModel_ReturnsOk()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var updateCoverageChangeResult = new CoverageChangeResultModel();
            GenericUniqueValue? participantId = new GenericUniqueValue(){};
            GenericUniqueValue? terminationDate = new GenericUniqueValue() { };
            unitOfWork.Setup(x => x.GenericUniqueValue.GetParticipantCoverageId(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).ReturnsAsync(participantId);
            unitOfWork.Setup(x => x.GenericUniqueValue.GetTerminationCoverageDate(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<string>())).ReturnsAsync(terminationDate);
            unitOfWork.Setup(x => x.ParticipantTransaction.UpdateCoverageChange(It.IsAny<CoverageChangeAvailablePlansModel>(), It.IsAny<string>())).ReturnsAsync(updateCoverageChangeResult);

            var testArrange = TestArrange(unitOfWork);
            CoverageChangeAvailablePlansModel? updateCoverageChangeModel = new()
            {
                ParticipantId = 1,
                Name = "Test",
                NewCoverageChanges = new List<NewCoverageChangeModel>()
                {
                    new NewCoverageChangeModel()
                    {
                        NewCoverageCode = "01",
                        TerminationDate = "02/02/2024",
                        NewFixedPremium = "20.5",
                        ParticipantId = 1,
                        PlanId = 1,
                        EffectiveDate = new DateTime().ToString(),
                    }
                },
                UpdateCoverageChanges = new List<UpdateCoverageChangeModel>()
                {
                    new UpdateCoverageChangeModel()
                    {
                        NewCoverageCode = "01",
                        NewFixedPremium = "20.5",
                        ParticipantId = 1,
                        PlanId = 1,
                        EffectiveDate = new DateTime().ToString(),
                    }    
                },
                DropCoverageChanges = new List<CoverageChangeModel>()
                {
                    new CoverageChangeModel()
                    {
                        NewFixedPremium = "20.5",
                        ParticipantId = 1,
                        PlanId = 1,
                        EffectiveDate = new DateTime().ToString(),
                    }
                }
            };

            //act
            var result = await testArrange.UpdateCoverageChange(model: updateCoverageChangeModel);
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task UpdateCoverageChange_GivenInfoIncomplete_ReturnsInternalServerError()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var testArrange = TestArrange(unitOfWork);
            CoverageChangeAvailablePlansModel? updateCoverageChangeModel = new()
            {
            };

            //act
            var result = await testArrange.UpdateCoverageChange(model: updateCoverageChangeModel);

            //assert
            Assert.Equal(HttpStatusCode.InternalServerError, result?.StatusCode);
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using Xunit;


namespace Core.Test.Services
{
    public class ParticipantValidatorServiceTest
    {
        private ILogger<ValidatorService>? _logger;
        public IUnitOfWork? _unitOfWork;
        public ValidatorService TestArrange(Mock<IUnitOfWork> unitOfWork)
        {
            _logger = new Mock<ILogger<ValidatorService>>().Object;

            var participantService = new ValidatorService(_logger, unitOfWork.Object);
            return participantService;
        }
        [Fact]
        public async Task SearchByHIreDate_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var newList = new RehireValidatorResultModel();
            unitOfWork.Setup(x => x.RehireValidator.SearchBySSNHireDate(It.IsAny<ValidateHireDataModel>())).ReturnsAsync(newList);
            var testArrange = TestArrange(unitOfWork);
            ValidateHireDataModel? searchModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.SearchBySSNHireDate(searchModel: searchModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchClientOption_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var clientOptionResultModel = new ClientOptionResultModel();
            unitOfWork.Setup(x => x.ClientOptionAll.SearchClientOption(It.IsAny<ClientOptionModel>(), null)).ReturnsAsync(clientOptionResultModel);
            var testArrange = TestArrange(unitOfWork);
            ClientOptionModel? clientOptionModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.SearchClientOption(searchModel: clientOptionModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchClientOptionLookup_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var clientOptionResultModel = new ClientOptionResultModel();
            unitOfWork.Setup(x => x.ClientOptionAll.SearchClientOptionLookup(It.IsAny<ClientOptionModel>(), null)).ReturnsAsync(clientOptionResultModel);
            var testArrange = TestArrange(unitOfWork);
            ClientOptionModel? clientOptionModel = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.SearchClientOptionLookup(searchModel: clientOptionModel);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }

        [Fact]
        public async Task IncludeSCCobraElig_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var sCCobraEligViewModel = new SCCobraEligViewModel();
            unitOfWork.Setup(x => x.SCCobraElig.IncludeSCCobraElig(It.IsAny<SCCobraEligModel>())).ReturnsAsync(sCCobraEligViewModel);
            var testArrange = TestArrange(unitOfWork);
            SCCobraEligModel? cobtraelig = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.IncludeSCCobraElig(searchModel: cobtraelig);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
        [Fact]
        public async Task CobraHipaaNotice_ReturnsOK()
        {
            //arrange
            var unitOfWork = new Mock<IUnitOfWork>();
            var sCCobraEligViewModel = new CobraHipaaViewModel();
            unitOfWork.Setup(x => x.CobraHipaa.CobraHipaaNotice(It.IsAny<UserClientModel>())).ReturnsAsync(sCCobraEligViewModel);
            var testArrange = TestArrange(unitOfWork);
            UserClientModel? cobtraelig = null;

            //act
#pragma warning disable CS8604 // Possible null reference argument.
            var result = await testArrange.CobraHipaaNotice(searchModel: cobtraelig);
#pragma warning restore CS8604 // Possible null reference argument.
            var actualMessage = await result.Content.ReadAsStringAsync();

            //assert
            Assert.Equal(HttpStatusCode.OK, result?.StatusCode);
        }
    }
}
﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using Microsoft.Extensions.Configuration;

namespace DataAccess
{
    public class CobraConfig : ICobraConfig
    {
        private readonly IConfiguration _configuration;

        public CobraConfig(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<string?> GetCLProd(string platform)
        {
            var uri = $"{_configuration.GetSection("ConfigUri").Value}/PlatformResource";
            PlatformRequest platformRequest = new()
            {
                Platform = platform,
                ResourceName = "CLPROD"
            };

            var connection = await ServiceUtil.SendAsync<PlatformRequest, string>(uri, platformRequest);
            return connection;

        }

        public async Task<string?> GetResource(string resource)
        {
            var uri = $"{_configuration.GetSection("ConfigUri").Value}/GlobalResource?resourceName={resource}";
            return await ServiceUtil.SendAsync<string>(uri);
        }
    }
}

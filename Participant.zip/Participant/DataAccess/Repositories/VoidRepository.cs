﻿using Core.Interfaces;
using Core.Model;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using Core.Util;

namespace DataAccess.Repositories
{
    public class VoidRepository : GenericRepository<VoidModel>, IVoidRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;

        public VoidRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<int> UpdateParticipant(VoidModel voidModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(voidModel.PlatformName));
            Query voidParticipantQuery = ParticipantSelect.UpdateParticipant(voidModel);
            string updateParticipant = await ExecuteGenericRowOutput(voidParticipantQuery, "@ReturnValue", 3);
            return int.Parse(updateParticipant);
        }
    }
}

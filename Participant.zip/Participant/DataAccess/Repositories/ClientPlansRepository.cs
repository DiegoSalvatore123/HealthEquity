﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class ClientPlansRepository : GenericRepository<ClientPlansModel>, IClientPlansRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;

        public ClientPlansRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<ClientPlansModel>?> GetClientPlans(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query clientList = DirectBillSelect.GetClientPlans( model.ClientId);
            List<ClientPlansModel>? lstSearch = await ExecuteGeneric(clientList);
            return lstSearch;
        }
        public async Task<List<ClientPlansModel>?> GetClientCobraPlans(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query clientList = CobraSelect.GetClientPlans(model.ClientId);
            List<ClientPlansModel>? lstSearch = await ExecuteGeneric(clientList);
            return lstSearch;
        }
    }
}

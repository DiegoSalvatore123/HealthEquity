﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class QERepository : GenericRepository<PlanModel>, IQERepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public QERepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<PlanModel>?> SearchPlanNameByPid(ParticipantIdModel participant)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            Query participantGetByID = ParticipantSelect.SearchPlanNameByPid(participant.ParticipantId);

            List<PlanModel>? lstParticipant = await ExecuteGeneric(participantGetByID);
            return lstParticipant;
        }
    }
}

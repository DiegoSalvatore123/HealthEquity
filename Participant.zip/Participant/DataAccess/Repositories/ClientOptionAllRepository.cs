﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class ClientOptionAllRepository : GenericRepository<ClientOptionResultModel>, IClientOptionAllRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public ClientOptionAllRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<ClientOptionResultModel?> SearchClientOption(ClientOptionModel model, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query query = Select.SearchClientOption(model);
            ClientOptionResultModel? clientOptionResultModel = await ExecuteGenericRow(query);
            return clientOptionResultModel;
        }
        public async Task<ClientOptionResultModel?> SearchClientOptionLookup(ClientOptionModel model, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            else
                database.SetConnectionString(platformConection);
            ClientOptionResultModel? clientoption = await SearchClientOption(model);
            if (clientoption == null)
            {
                Query query = Select.SearchClientOptionLookup(model);
                ClientOptionResultModel? clientOptionResultModel = await ExecuteGenericRow(query);
                return clientOptionResultModel;
            }
            else
                return clientoption;
        }
        public async Task<ClientOptionResultModel?> GetEmployeeCounts(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));

            Query participantGetByID = CobraSelect.GetEmployeeCounts(model);
            ClientOptionResultModel? clientoption = await ExecuteGenericRow(participantGetByID);
            return clientoption;
        }
        public async Task<ClientOptionResultModel?> GetClientAcivePlans(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));

            Query activePlans = DirectBillSelect.GetClientAcivePlans(model);
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(activePlans);
            return clientoption![0];
        }
        public async Task<ClientOptionResultModel?> GetCafePlan(string PlatformName,int planId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);

            Query activePlans = Select.GetCafePlan(planId);
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(activePlans);
            return clientoption![0];
        }
        public async Task<ClientOptionResultModel?> GetCoveragError(string PlatformName,string participantId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query coverageCount = Select.GetCoveragError( participantId);
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(coverageCount);
            return clientoption![0];
        }
        public async Task<ClientOptionResultModel?> GetCoveragErrorQE(string PlatformName, string participantId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query coverageCount = Select.GetCoveragErrorQE(participantId);
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(coverageCount);
            return clientoption![0];
        }
        public async Task<ClientOptionResultModel?> GetCoveragExisting(string PlatformName, string participantId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query coverageCount = Select.GetCoveragExisting(participantId);
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(coverageCount);
            return clientoption![0];
        }
        public async Task<ClientOptionResultModel?> GetMLRQuotitData(string PlatformName,string ProcessIdentifier,[Optional] string platformConection)
        {
            var database = _db.Database;
         //   int rateCount = 0;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query mlrQuote = Select.GetMLRQuotitData(ProcessIdentifier);
          //  DateTime startTime= DateTime.Now;
           
            List<ClientOptionResultModel>? clientoption = await ExecuteGeneric(mlrQuote);
            //while (rateCount!= mlrGuidCount && ((DateTime.Now - startTime).TotalSeconds<60))
            //{
            //    clientoption = await ExecuteGeneric(mlrQuote);
            //    if (clientoption.Vaue == "0")
            //        System.Threading.Thread.Sleep(3000);
            //    else
            //        rateCount = int.Parse(clientoption![0].OptionValue);
            //}
            return clientoption![0];
        }
       
    }
}

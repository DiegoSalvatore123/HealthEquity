﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class DocumentOptionRepository : GenericRepository<DocumentOptionModel>, IDocumentOptionRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DocumentOptionRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<DocumentOptionModel>?> GetDocumentOptionById(string platformName, List<EmailReSendModel> emails, [Optional] string platformConection)
        {
            var database = _db.Database;
            List<DocumentOptionModel>? lstDocumentModel = new();
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            foreach (EmailReSendModel email in emails) { 
                Query documentByID = EligibilityTransmission.GetDocumentOption(email.DocId.ToString());
                DocumentOptionModel? document = await ExecuteGenericRow(documentByID);
                if (document != null)
                    lstDocumentModel.Add(document);
            }
            return lstDocumentModel;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class DBPastDueRepository : GenericRepository<DBPastDueModel>, IDBPastDueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DBPastDueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<DBPastDueModel>?> GetPastDue(SearchModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query query = DirectBillSelect.GetPastDue(model);
            List<DBPastDueModel>? dBPastDueModels = await ExecuteGeneric(query);
            return dBPastDueModels;
        }
    }
}

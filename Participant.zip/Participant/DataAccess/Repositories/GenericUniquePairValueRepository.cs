﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using DataAccess.Queries.QualifyingEvent;

namespace DataAccess.Repositories
{
    public class GenericUniquePairValueRepository : GenericRepository<GenericUniquePairValue>, IGenericUniquePairValueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public GenericUniquePairValueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<GenericUniquePairValue>?> GetClientEventName(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query query = DirectBillSelect.GetDirectBillTypes(model.ClientId);
            List<GenericUniquePairValue>? lstSearch = await ExecuteGeneric(query);
            return lstSearch;
        }
        public async Task<GenericUniquePairValue?> GetPlansDates(PlanMLRModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query query = Select.GetPlansDates(model.PlanId);
            GenericUniquePairValue? lstSearch = await ExecuteGenericRow(query);
            return lstSearch;
        }
    }
}

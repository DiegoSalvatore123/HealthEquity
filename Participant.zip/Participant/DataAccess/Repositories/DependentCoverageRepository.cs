﻿using Core.Interfaces;
using Core.Model;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class DependentCoverageRepository : GenericRepository<ParticipantDependentCoverageResultModel>, IDependentCoverageRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public DependentCoverageRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }
    public async Task<List<ParticipantDependentCoverageResultModel>?> GetParticipantCoverageByParticipantCoverageIdAndClientId(string participantCoverageId, string clientId, string platformName)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
        var queryDependentCoverage = ParticipantSelect.GetDependentCoverageByParticipantCoverageIdAndClientId(participantCoverageId, clientId);
        List<ParticipantDependentCoverageResultModel>? result = await ExecuteGeneric(queryDependentCoverage);
        return result;
    }
}
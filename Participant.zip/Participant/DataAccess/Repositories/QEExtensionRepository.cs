﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class QEExtensionRepository : GenericRepository<QEExtensionModel>, IQEExtensionRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public QEExtensionRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<QEExtensionModel?> QEExtension(QeCodeExtensionModel qe)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(qe.PlatformName));
            Query feature = Select.QEExtension(qe.QeCode);
            QEExtensionModel? extension = await ExecuteGenericRow(feature);
            return extension;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class AvailablePlanRepository : GenericRepository<AvailablePlansClientResult>, IAvailablePlanRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public AvailablePlanRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<AvailablePlansClientResult>?> CoveragePlanByClientId(CoveragePlanDataModel planModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(planModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query getcoverage = ParticipantExecSP.CoveragePlanByClientId(planModel);
            List<AvailablePlansClientResult>? lstSearch = await ExecuteGeneric(getcoverage);
            if (lstSearch != null)
            {
                if (planModel.BillingStartDate.Equals(string.Empty))
                {
                    lstSearch = lstSearch.Where(obj => obj.PlanIsFutureDated != 1).ToList();
                    if(planModel.Action == "6")
                        lstSearch = lstSearch.Where(obj => !obj.IsMNLife ?? true).ToList();
                    else if(planModel.Action == "1")
                        lstSearch = lstSearch.Where(obj => !((obj.IsMNLife ?? false) && planModel.QualifiedCode == "08")).ToList();
                }
            }
            return lstSearch;
        }
    }
}

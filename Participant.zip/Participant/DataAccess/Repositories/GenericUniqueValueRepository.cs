﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using DataAccess.Queries.CoverageChange;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class GenericUniqueValueRepository : GenericRepository<GenericUniqueValue>, IGenericUniqueValueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public GenericUniqueValueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<GenericUniqueValue?> GetPlatformConnection(string platformName)
        {
            GenericUniqueValue? genericUniqueValue = new() { Value = await _cobraConfig.GetCLProd(platformName) };
            return genericUniqueValue;
        }
        public async Task<GenericUniqueValue?> GetLifeInsuranceRTPlan(string platformName, string planId, string rateType)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

            Query lifeInsurance = Select.GetLifeInsuranceRTPlan(planId, rateType);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(lifeInsurance);
            return lstSearch;
        }
        public async Task<GenericUniqueValue?> GetLifeInsuranceRTPlanWithPlatformConection(string platformConecction, string planId, string rateType)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConecction);

            Query lifeInsurance = Select.GetLifeInsuranceRTPlan(planId, rateType);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(lifeInsurance);
            return lstSearch;
        }
        public async Task<GenericUniqueValue?> IsFeatureOn(string platformName, string clientId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);

            Query feature = ParticipantExecSP.IsFeatureOn(clientId);
            string isFeature = await ExecuteGenericRowOutput(feature, "@IsFeatureOn",2);
            GenericUniqueValue genericUnique = new()
            {
                Value= isFeature,
            };
            return genericUnique;
        }
        public async Task<GenericUniqueValue?> GetQEExtension(string PlatformName, string QualifiedCode, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);

            Query qe = Select.GetQEExtension(QualifiedCode ?? "");
            GenericUniqueValue? code = await ExecuteGenericRow(qe);
            return code;
        }
        public async Task<GenericUniqueValue?> GetPlanType(string platformName, string planId)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

            Query query = Select.GetPlanType(planId);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(query);
            return lstSearch;
        }
        public async Task<GenericUniqueValue?> GetPlanTypeWithPlatformConection(string platformConection, string planId)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConection);

            Query query = Select.GetPlanType(planId);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(query);
            return lstSearch;
        }
        public async Task<GenericUniqueValue?> GetPlanOptionConection(string platformConection, string planId)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConection);

            Query query = Select.GetPlanOption(planId);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(query);
            return lstSearch;
        }
        public async Task<GenericUniqueValue?> GetTobaccoUse(string platformConecction, string planId)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConecction);

            Query tobacco = Select.GetTobaccoUsePlan(planId);
            GenericUniqueValue? tobaccoPlan = await ExecuteGenericRow(tobacco);
            return tobaccoPlan;
        }
        public async Task<GenericUniqueValue?> GetDirectRateEntry(string platformConecction, string clientId)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConecction);

            Query directoryRate = Select.GetDirectRateEntry(clientId);
            GenericUniqueValue? rateClient = await ExecuteGenericRow(directoryRate);
            return rateClient;
        }
        public async Task<GenericUniqueValue?> GetParticipantCoverageId(string platformConnection, int participantId, int planId, string effectiveDate)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConnection);
            Query participantCoverage = SelectCoverage.GetParticipantCoverageId(participantId, planId, effectiveDate);
            GenericUniqueValue? coverageId = await ExecuteGenericRow(participantCoverage);
            return coverageId;
        }
        public async Task<GenericUniqueValue?> GetTerminationCoverageDate(string platformConnection, int participantId, int planId, string effectiveDate)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConnection);
            Query terminationDateQ = SelectCoverage.GetTerminationDate(participantId, planId, effectiveDate);
            GenericUniqueValue? terminationDate = await ExecuteGenericRow(terminationDateQ);
            return terminationDate;
        }
        public async Task<GenericUniqueValue?> GetPreferredLanguage(string platformName, string clientId, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            Query query = Select.GetPreferredLanguage(clientId);
            GenericUniqueValue? lstSearch = await ExecuteGenericRow(query);
            return lstSearch;
        }
        public async Task MLRProcessEvent(string platformName, string clientID, string userId,string message, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            Query eventMlF = ParticipantExecSP.EventMLR(clientID, userId, message);
            await ExecuteGenericNoReturn(eventMlF);
            
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class SpecificFieldsRepository : GenericRepository<SpecificFieldsResultModel>, ISpecificFieldsRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public SpecificFieldsRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<SpecificFieldsResultModel>?> GetSpecificFieldsByPid(ParticipantIdModel participant, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query specificFieldsByID = ParticipantSelect.GetSpecificFieldsByPid(participant.ParticipantId);
            List<SpecificFieldsResultModel>? lstSearch = await ExecuteGeneric(specificFieldsByID);
            return lstSearch;
        }
        public async Task<List<SpecificFieldsResultModel>?> GetSpecificFieldsByClientid(UserClientModel customer, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(customer.PlatformName));
            else
                database.SetConnectionString(platformConection);

            Query specificFieldsByID = ParticipantSelect.GetSpecificFieldsByClientId(customer.ClientId);
            List<SpecificFieldsResultModel>? lstSearch = await ExecuteGeneric(specificFieldsByID);
            return lstSearch;
        }
    }
}

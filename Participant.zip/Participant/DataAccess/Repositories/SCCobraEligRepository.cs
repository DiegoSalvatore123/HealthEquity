﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class SCCobraEligRepository : GenericRepository<SCCobraEligViewModel>, ISCCobraEligRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public SCCobraEligRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<SCCobraEligViewModel?> IncludeSCCobraElig(SCCobraEligModel contract)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(contract.PlatformName));
            Query sccCobra = ParticipantSelect.GetIncludeSCCobraElig(contract);
            SCCobraEligViewModel? sccCobraElig = await ExecuteGenericRow(sccCobra);
            return sccCobraElig;
        }
    }
}
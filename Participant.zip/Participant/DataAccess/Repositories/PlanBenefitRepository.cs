﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class PlanBenefitRepository : GenericRepository<PlanBenefitTypeModel>, IPlanBenefitRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public PlanBenefitRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<PlanBenefitTypeModel>?> GetBenefitForPlanId(string platformName, string planId)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            Query eligibilityEndQuery = Select.GetBenefitForPlanId(planId);
            List<PlanBenefitTypeModel>? lstSearch = await ExecuteGeneric(eligibilityEndQuery);
            return lstSearch;
        }
    }
}

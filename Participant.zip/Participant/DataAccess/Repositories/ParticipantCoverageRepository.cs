﻿using Core.Interfaces;
using Core.Model;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class ParticipantCoverageRepository: GenericRepository<ParticipantCoverageModel>, IParticipantCoverageRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public ParticipantCoverageRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<ParticipantCoverageModel?> GetParticipantCoverage(int pId, string platformName)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            var result = GetFirstOrDefault(ta => ta.ParticipantId == pId && ta.CoverageState != 'V');
            return result;
        }
    }
}

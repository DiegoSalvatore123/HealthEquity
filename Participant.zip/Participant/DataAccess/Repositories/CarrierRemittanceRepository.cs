﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class CarrierRemittanceRepository : GenericRepository<CarrierRemittanceModel>, ICarrierRemittanceRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public CarrierRemittanceRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<CarrierRemittanceModel>?> GetCarrierRemittanceByPid(ParticipantIdModel participant)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            Query query = ParticipantSelect.GetCarrierRemittanceByPid(participant);
            List<CarrierRemittanceModel>? lstSearch = await ExecuteGeneric(query);
            return lstSearch;
        }
    }
}

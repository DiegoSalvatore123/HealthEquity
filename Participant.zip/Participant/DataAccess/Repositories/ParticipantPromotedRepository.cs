﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class ParticipantPromotedRepository : GenericRepository<ParticipantPromotedModel>, IParticipantPromotedRepository
{
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;

        public ParticipantPromotedRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }        

        public async Task<ParticipantPromotedModel?> GetParticipantPromoted(string socialSecurityNumber, string participantId, string clientId, string platformName, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            Query participantPromotedQuery = ParticipantSelect.GetParticipantPromoted(socialSecurityNumber, participantId, clientId);
            ParticipantPromotedModel? participantPromotedModel = new();
            participantPromotedModel = await ExecuteGenericRow(participantPromotedQuery);
            return participantPromotedModel;
        }
    }
}

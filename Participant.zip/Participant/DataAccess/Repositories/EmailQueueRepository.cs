﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class EmailQueueRepository : GenericRepository<EmailModel>, IEmailQueueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public EmailQueueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<EmailModel>?> GetEmailQueue(DocumentModel documentModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(documentModel.PlatformName));
            Query query = ParticipantSelect.GetEmail(documentModel.ParticipantId);
            List<EmailModel>? documentResultModel = await ExecuteGeneric(query);
            return documentResultModel;
        }
    }
}

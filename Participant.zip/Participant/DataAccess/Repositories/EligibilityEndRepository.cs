﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.DisabilityExtension;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class EligibilityEndRepository : GenericRepository<EligibilityEndModel>, IEligibilityEndRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public EligibilityEndRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<string?> CalculateEligibilityEnd(string platformName, InfoResultModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            QueryT eligibilityEndQuery = Select.CalculateEligibilityEndDate(model);
            var elegibilityEndOutput = ExecuteGenericRowSpecificOutput<DateTime>(eligibilityEndQuery, "@EligibilityEndDate", 3);
            string elegibilityEndFormatted = elegibilityEndOutput.ToString("MM/dd/yyyy");
            return elegibilityEndFormatted;            
        }
    }
}

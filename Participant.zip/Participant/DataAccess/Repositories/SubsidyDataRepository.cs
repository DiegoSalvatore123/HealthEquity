﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class SubsidyDataRepository : GenericRepository<SubsidyDataModel>, ISubsidyDataRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public SubsidyDataRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<SubsidyDataModel?> ExecuteCoveragePLS(string platformName, string xml, string userId)
        {
            var database = _db.Database;
            SubsidyDataModel subsidy=new();
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            Query pls = ParticipantExecSP.InsertCoveragePLS(xml, userId);
            List<SubsidyDataModel>? returnLst = await ExecuteGeneric(pls);
            if (returnLst != null)
                subsidy = returnLst[0];
            return subsidy;
        }
    }
}

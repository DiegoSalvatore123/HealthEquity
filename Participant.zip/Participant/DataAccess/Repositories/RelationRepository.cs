﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class RelationRepository : GenericRepository<RelationModel>, IRelationRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public RelationRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }    
        public async Task<List<RelationModel>?> GetRelations(InfoModel searchModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query getRelations = ParticipantSelect.GetRelations();
            List<RelationModel>? lstSearch = await ExecuteGeneric(getRelations);
            return lstSearch;
        }
    }
}

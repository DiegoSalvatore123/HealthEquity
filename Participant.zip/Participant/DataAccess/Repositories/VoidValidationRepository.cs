﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class VoidValidationRepository : GenericRepository<VoidCheckModel>, IVoidValidationRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public VoidValidationRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<OperationResultModel?> CheckIfParticipantExist(VoidModel voidModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(voidModel.PlatformName));
            Query voidParticipantQuery = ParticipantSelect.CheckIfParticipantFound(voidModel);

            var participantExistense = await ExecuteGeneric(voidParticipantQuery);
            if (participantExistense == null || participantExistense.Count == 0)
                return new OperationResultModel { Success = false, ResultDescription = "Participant Not Found. Please try again." };
            return null;
        }
    }
}

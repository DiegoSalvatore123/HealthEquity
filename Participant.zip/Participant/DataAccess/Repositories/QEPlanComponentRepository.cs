﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class QEPlanComponentRepository : GenericRepository<QEPlanComponentModel>, IQEPlanComponentRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public QEPlanComponentRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }

        public async Task<QEPlanComponentModel?> GetQEPlanComponent(int planId, string PlatformName, string isLifeInsuranceRTPlan)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            Query query = Select.SearchqQePlanComponent(planId.ToString(), isLifeInsuranceRTPlan);
            QEPlanComponentModel? qEPlanComponentModel = await ExecuteGenericRow(query);
            return qEPlanComponentModel;
        }
        public async Task<QEPlanComponentModel?> GetQEPlanComponentWithPlatformConection(int planId, string platformConection, string isLifeInsuranceRTPlan)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConection);
            Query query = Select.SearchqQePlanComponent(planId.ToString(), isLifeInsuranceRTPlan);
            QEPlanComponentModel? qEPlanComponentModel = await ExecuteGenericRow(query);
            return qEPlanComponentModel;
        }
    }
}

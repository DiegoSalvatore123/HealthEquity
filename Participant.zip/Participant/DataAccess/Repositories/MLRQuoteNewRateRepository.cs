﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class MLRQuoteNewRateRepository : GenericRepository<MLRQuoteGetNewRateModel>, IMLRQuoteNewRateRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public MLRQuoteNewRateRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<MlrRate>?> GetMLRQuoteGetNewRates(string PlatformName, string participantId, string ProcessIdentifier, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query mlrQuote = SelectCoverage.GetMLRQuoteGetNewRates(ProcessIdentifier);
            List<MLRQuoteGetNewRateModel>? newRates = await ExecuteGeneric(mlrQuote);
            List<MlrRate>? mlrRates = new();
            if (newRates != null)
            {
                foreach (MLRQuoteGetNewRateModel quote in newRates)
                {
                        MlrRate rate = new()
                        {
                            Id = quote.PlanId + "-" + participantId,
                            Value = quote.Rate.ToString() + "-" + quote.CCSId.ToString()
                        };
                        mlrRates.Add(rate);
                }
            }
            return mlrRates;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class SystemSettingRepository : GenericRepository<SystemSettingModel>, ISystemSettingRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public SystemSettingRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<SystemSettingModel?> GetSystemSettingByName(string settingName, string platformName)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            Query query = ParticipantSelect.GetSystemSettingByName(settingName);
            SystemSettingModel? systemSettingsModel = await ExecuteGenericRow(query);
            return systemSettingsModel;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class SubsidyRepository : GenericRepository<SubsidyResultModel>, ISubsidyRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public SubsidyRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<SubsidyResultModel>> GetSubsidybyPid(ParticipantIdModel participant)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            Query participantGetByID = ParticipantSelect.GetSubsidybyPid(participant.ParticipantId);

            List<SubsidyResultModel>? returnLst = await ExecuteGeneric(participantGetByID);
            return returnLst ?? new List<SubsidyResultModel>();
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class DocQueueRepository: GenericRepository<DocQueueModel>, IDocQueueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DocQueueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<DocQueueModel?> GetDocQueue(int pId, string platformName)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            var result = GetFirstOrDefault(ta => ta.ParticipantId == pId && ta.DocStatus != 'V');
            return result;
        }
    }
}

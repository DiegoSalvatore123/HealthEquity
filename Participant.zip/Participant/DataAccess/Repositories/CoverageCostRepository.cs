﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class CoverageCostRepository : GenericRepository<CoverageCostResultModel>, ICoverageCostRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public CoverageCostRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }

    public async Task<List<CoverageCostResultModel>?> GetCoverageCost(string platformName, string planId, string coverageCode)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
        Query coverageCostQuery = CoverageCost.GetCoverageCost(planId, coverageCode);
        List<CoverageCostResultModel>? coverageCost = await ExecuteGeneric(coverageCostQuery);
        return coverageCost;
    }
}
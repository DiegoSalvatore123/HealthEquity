﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;
public class EligibilityTransmissionRepository : GenericRepository<EligibilityTransmissionModel>, IEligibilityTransmissionRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public EligibilityTransmissionRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }
    public async Task<List<EligibilityTransmissionModel>?> GetEligibilityTransmissionDetail(string platformName, string participantId)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
        Query eligibilityTransmissionQuery = EligibilityTransmission.GetEligibilityTransmissionByPid(participantId);
        List<EligibilityTransmissionModel>? listEligibilityTransmissionDetail = await ExecuteGeneric(eligibilityTransmissionQuery);
        return listEligibilityTransmissionDetail;
    }
}
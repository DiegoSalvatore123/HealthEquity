﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class StateRepository : GenericRepository<StateModel>, IStateRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public StateRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }

        public async Task<List<StateModel>?> GetStates(InfoModel searchModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query getStates = ParticipantSelect.GetStates();
            List<StateModel>? lstSearch = await ExecuteGeneric(getStates);
            return lstSearch;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class CoverageAvailablePlanRepository : GenericRepository<CoverageAvailablePlan>, ICoverageAvailablePlanRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public CoverageAvailablePlanRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<CoverageAvailablePlan>?> GetCoverage(string platformName, string code)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

            Query getcoverage = Select.GetCoverage(code);
            List<CoverageAvailablePlan>? coverage = await ExecuteGeneric(getcoverage);
            return coverage;
        }
        public async Task<List<CoverageAvailablePlan>?> GetCoverageWithPlatformConection(string platformConection, string code)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConection);

            Query getcoverage = Select.GetCoverage(code);
            List<CoverageAvailablePlan>? coverage = await ExecuteGeneric(getcoverage);
            return coverage;
        }

    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.DisabilityExtension;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class SurchargePercentRepository : GenericRepository<SurchargePercentModel>, ISurchargePercentRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;

        public SurchargePercentRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<SurchargePercentModel?> SearchSurchargePercent(InfoModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query surchargePercentQuery = Select.GetDisabilitySurchargePercent(model.ClientId);
            return _ = await ExecuteGenericRow(surchargePercentQuery);
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class RemoveQEDetailRepository : GenericRepository<RemoveQEDetail>, IRemoveQEDetailRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public RemoveQEDetailRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<RemoveQEDetail?> GetRemoveQEDetailByPid(RemoveQEModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query query = ParticipantSelect.RemoveQEDetail(model);
            RemoveQEDetail? removeQEDetail = await ExecuteGenericRow(query);
            return removeQEDetail;
        }
    }
}

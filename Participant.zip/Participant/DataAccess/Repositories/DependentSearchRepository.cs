﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class DependentSearchRepository : GenericRepository<DependentResultModel>, IDependentSearchRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DependentSearchRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<DependentResultModel>?> SearchDependentBySSN(SearchModel searchModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query dependentGetByPID = ParticipantSelect.SearchDependentBySSN(searchModel);
            List<DependentResultModel>? lstDependentModel = await ExecuteGeneric(dependentGetByPID);

            return lstDependentModel;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class CustomFieldDomainRepository : GenericRepository<CustomFieldDomain>, ICustomFieldDomainRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public CustomFieldDomainRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<CustomFieldDomain>?> GetSpecificFieldsByPid(string platformName, int customField, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            Query specificFieldsByID = ParticipantSelect.GetCutomFieldsById(customField);
            List<CustomFieldDomain>? lstSearch = await ExecuteGeneric(specificFieldsByID);
            return lstSearch;
        }
    }
}

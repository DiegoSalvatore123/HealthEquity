﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.QualifyingEvent;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class QualifyingEventTypeRepository : GenericRepository<QeMetaDatas>, IQualifyingEventTypeRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public QualifyingEventTypeRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<QeMetaDatas>?> GetQualifyingEventType(QualifyingEventTypeModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query query = Select.GetQualifyingEventType(model);
            List<QeMetaDatas>? qualifyingEventTypeResultModels = await ExecuteGeneric(query);
            return qualifyingEventTypeResultModels;
        }
    }
}

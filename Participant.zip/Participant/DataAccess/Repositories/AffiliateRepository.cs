﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class AffiliateRepository : GenericRepository<AffiliateModel>, IAffiliateRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public AffiliateRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<AffiliateModel>?> GetDivisionLocations(InfoModel searchModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query getDivisionLocation = ParticipantSelect.GetDivisionLocation(searchModel);
            List<AffiliateModel>? lstSearch = await ExecuteGeneric(getDivisionLocation);
            return lstSearch;
        }
        public async Task<AffiliateModel?> GetAffiliateName(AffiliateInfoModel searchModel, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            
            Query getAffiliate = ParticipantSelect.GetAffiliateName(searchModel.ClientId, searchModel.AffiliateName);
            AffiliateModel? afiiliate = await ExecuteGenericRow(getAffiliate);
            return afiiliate;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class GenericGuidValueRepository : GenericRepository<GenericGuidValue>, IGenericGuidValueRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public GenericGuidValueRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<GenericUniqueValue?> GetMLRQuote(string platformName, string clientID, string userId, string qualifyingDate, string planData, string memberData, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            else
                database.SetConnectionString(platformConection);
            GenericUniqueValue genericUnique=new();
            string quote=string.Empty;
            Query mlrQuote = ParticipantExecSP.GetMLRQuote(clientID, qualifyingDate, planData, memberData);
            List<GenericGuidValue>? genericGuid = await ExecuteGeneric(mlrQuote);
            if(genericGuid!=null && genericGuid.Count>0)
            {
                foreach(GenericGuidValue guid in genericGuid)
                {
                    quote += quote == string.Empty ? "" : ",";
                    quote += guid.Value.ToString();
                }
            }
            genericUnique.Value = quote;
            return genericUnique;
        }
    }
}

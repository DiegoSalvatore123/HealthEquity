﻿using Core.Interfaces;
using Core.Util;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.Design;
using System.Data;
using System.Linq.Expressions;

namespace DataAccess.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        protected readonly DbContext _dbContext;
        internal DbSet<T> dbSet;
        public GenericRepository(DbContext dbContext)
        {
            _dbContext = dbContext;
            dbSet = dbContext.Set<T>();
        }
        public void Add(T entity)
        {
            dbSet.Add(entity);
        }
        public async Task<T?> Get(int id)
        {
            return await dbSet.FindAsync(id);
        }
        public void Remove(int id)
        {
            T? entityToRemove = dbSet.Find(id);
            if (entityToRemove != null)
                Remove(entityToRemove);
        }
        public void Remove(T entity)
        {
            dbSet.Remove(entity);
        }
        public IEnumerable<T> GetAll(Expression<Func<T, bool>>? filter = null, Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null, string? includeProperties = null)
        {
            IQueryable<T> query = dbSet;
            if (filter != null)
                query = query.Where(filter);
            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            if (orderBy != null)
                return orderBy(query).ToList();
            return query.ToList();
        }
        public T? GetFirstOrDefault(Expression<Func<T, bool>>? filter = null, string? includeProperties = null)
        {
            IQueryable<T> query = dbSet;
            if (filter != null)
                query = query.Where(filter);

            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }
            return query.FirstOrDefault();
        }
        public async Task<List<T>?> ExecuteGeneric(string query, Dictionary<string, string>? sqlParams = null)
        {
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (sqlParams != null)
            {
                foreach (KeyValuePair<string, string> _param in sqlParams)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    sqlParameters.Add(sqlParameter);
                }
            }
            return await _dbContext.Set<T>().FromSqlRaw(query, sqlParameters.ToArray()).ToListAsync();
        }
        public async Task<List<T>?> ExecuteGeneric(Query query)
        {
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, string> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    sqlParameters.Add(sqlParameter);
                }
            }
            return await _dbContext.Set<T>().FromSqlRaw(query.SelectFrom, sqlParameters.ToArray()).ToListAsync();
        }
        public async Task<T?> ExecuteGenericRow(Query query)
        {
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, string> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    sqlParameters.Add(sqlParameter);
                }
            }
            return await _dbContext.Set<T>().FromSqlRaw(query.SelectFrom, sqlParameters.ToArray()).FirstOrDefaultAsync();
        }
        public async Task<int?> ExecuteGenericSpecificRow(QueryT query)
        {
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, object> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    sqlParameters.Add(sqlParameter);
                }
            }
            return await _dbContext.Database.ExecuteSqlRawAsync(query.SelectFrom, sqlParameters.ToArray());
        }
        public async Task<string> ExecuteGenericRowOutput(Query query, string outPutParameterName, int outPutParameterPosition)
        {
            string returnValue = "0";
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, string> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    if (_param.Key == outPutParameterName)
                    {
                        sqlParameter.Direction = System.Data.ParameterDirection.Output;
                            if(_param.Key == "@GUID")
                                sqlParameter.SqlDbType = System.Data.SqlDbType.UniqueIdentifier;
                            else
                                sqlParameter.SqlDbType = System.Data.SqlDbType.Int;
                    }
                    sqlParameters.Add(sqlParameter);
                }
            }
          await _dbContext.Database.ExecuteSqlRawAsync(query.SelectFrom, sqlParameters.ToArray());
            var out1Value = sqlParameters.ToArray()[outPutParameterPosition].Value;
            if (out1Value != null && out1Value!.ToString()!.Length>0)
                    returnValue = out1Value!.ToString();
                //returnValue = Convert.ToInt32(out1Value.ToString());
                return returnValue!;
        }
        public TResult? ExecuteGenericRowSpecificOutput<TResult>(QueryT query, string outPutParameterName, int outPutParameterPosition)
        {
            TResult? returnValue = default;
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();

            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, object> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    if (_param.Key == outPutParameterName)
                    {
                        sqlParameter.Direction = ParameterDirection.Output;
                        sqlParameter.SqlDbType = GetSqlDbType<TResult>();
                    }
                    sqlParameters.Add(sqlParameter);
                }
            }
            _dbContext.Database.ExecuteSqlRaw(query.SelectFrom, sqlParameters.ToArray());
            var outValue = sqlParameters.ToArray()[outPutParameterPosition].Value;
            if (outValue != null)
                returnValue = ConvertValue<TResult>(outValue.ToString()!);
            return returnValue ;
        }
        private static SqlDbType GetSqlDbType<TResult>()
        {
            if (typeof(TResult) == typeof(int))
                return SqlDbType.Int;
            else if (typeof(TResult) == typeof(DateTime))
                return SqlDbType.DateTime;
            else
                return SqlDbType.NVarChar;
        }
        private static TResult ConvertValue<TResult>(string value)
        {
            if (typeof(TResult) == typeof(int))
                return (TResult)(object)Convert.ToInt32(value);
            else if (typeof(TResult) == typeof(DateTime))
                return (TResult)(object)Convert.ToDateTime(value);
            else
                return (TResult)(object)value;
        }
        public int Save(T entity)
        {
            _dbContext.Update(entity);
            return _dbContext.SaveChanges();
        }
        public void SaveAll(IEnumerable<T> entities)
        {
            _dbContext.UpdateRange(entities);
            _dbContext.SaveChanges();
        }
        public void AddAll(IEnumerable<T> entities)
        {
            _dbContext.AddRange(entities);
        }
        public async Task ExecuteGenericNoReturn(Query query)
        {
            SqlParameter sqlParameter;
            List<SqlParameter> sqlParameters = new();
            if (query.Parameters != null)
            {
                foreach (KeyValuePair<string, string> _param in query.Parameters)
                {
                    sqlParameter = new SqlParameter() { ParameterName = _param.Key, Value = _param.Value };
                    sqlParameters.Add(sqlParameter);
                }
            }
           await _dbContext.Database.ExecuteSqlRawAsync(query.SelectFrom, sqlParameters.ToArray());
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class CoverageErrorRepository : GenericRepository<CoverageErrorModel>, ICoverageErrorRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public CoverageErrorRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<CoverageErrorModel>?> GetCoverageError(string participantId, string platformName)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            Query getStates = SelectCoverage.GetCoverageError(participantId);
            List<CoverageErrorModel>? lstSearch = await ExecuteGeneric(getStates);
            return lstSearch;
        }
        public async Task<List<CoverageErrorModel>?> GetCoverageErrorQE(string participantId, string platformName)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
            Query getStates = SelectCoverage.GetCoverageErrorQE(participantId);
            List<CoverageErrorModel>? lstSearch = await ExecuteGeneric(getStates);
            return lstSearch;
        }
    }
}

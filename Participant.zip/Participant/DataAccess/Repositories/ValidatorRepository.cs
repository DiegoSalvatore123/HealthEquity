﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class ValidatorRepository : GenericRepository<RehireValidatorResultModel>, IValidatorRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public ValidatorRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<RehireValidatorResultModel?> SearchBySSNHireDate(ValidateHireDataModel searchModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            Query participantGetByID = ParticipantSelect.SearchBySSNHireDate(searchModel);
            RehireValidatorResultModel? rehire = await ExecuteGenericRow(participantGetByID);
            return rehire;
        }
    }
}

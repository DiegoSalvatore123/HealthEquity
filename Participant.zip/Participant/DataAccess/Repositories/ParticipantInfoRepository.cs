﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class ParticipantInfoRepository : GenericRepository<ParticipantInfoResultModel>, IParticipantInfoRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;

    public ParticipantInfoRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }

    public async Task<ParticipantInfoResultModel?> GetParticipantInfo(string platformName, string participantId)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
        Query participantInfoQuery = ParticipantSelect.GetParticipantInfoByParticipantId(participantId);
        ParticipantInfoResultModel? participantInfoModel = new();
        participantInfoModel = await ExecuteGenericRow(participantInfoQuery);
        return participantInfoModel;
    }
}
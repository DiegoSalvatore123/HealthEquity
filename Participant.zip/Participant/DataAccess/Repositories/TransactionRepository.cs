﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.DependencyModel;
using Microsoft.Extensions.Logging;

namespace DataAccess.Repositories
{
    public class TransactionRepository : GenericRepository<OperationResultModel>, ITransactionRepository
    {
        private readonly ILogger<TransactionRepository> _logger;
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        private readonly IPlanBenefitRepository _planBenefit;
        private readonly ISubsidyDataRepository _subsidyData;
        public TransactionRepository(ILogger<TransactionRepository> logger, CobraDbContext db, ICobraConfig cobraConfig, IPlanBenefitRepository planBenefit, ISubsidyDataRepository subsidyData) : base(db)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _db = db;
            _cobraConfig = cobraConfig;
            _planBenefit = planBenefit;
            _subsidyData = subsidyData;
        }
        public async Task<OperationResultModel> CreateAddress(AddressModel insertModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(insertModel.PlatformName));
            OperationResultModel operationResultModel = await NewAddress(insertModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> Insert(ParticipantInsertModel participantInsertModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participantInsertModel.PlatformName));
            OperationResultModel operationResultModel = await NewParticipant(participantInsertModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> InsertTakeOver(InfoSessionModel insertModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(insertModel.PlatformName));
            OperationResultModel operationResultModel = await NewTakeOver(insertModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> InsertProcessQE(InfoSessionModel insertModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(insertModel.PlatformName));
            OperationResultModel operationResultModel = await NewProcessQE(insertModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> InsertDependentProcessQE(DependentProcessQEModel insertModel, string? preferredLanguage, ParticipantPromotedModel? participantPromoted)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(insertModel.PlatformName));
            OperationResultModel operationResultModel = await NewDependentProcessQE(insertModel, preferredLanguage, participantPromoted, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> UpdateGroup(UpdateModel insertModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(insertModel.PlatformName));
            OperationResultModel operationResultModel = await SaveUpdateGroup(insertModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> Update(InfoSaveUpdateModel updateModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(updateModel.PlatformName));
            OperationResultModel operationResultModel = await Update(updateModel, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> CoverageAcceptable(CoverageAcceptable model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            OperationResultModel operationResultModel = await CoverageAcceptable(model, database);
            return operationResultModel;
        }
        public async Task<OperationResultModel> QueueAch(VoidModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            OperationResultModel operationResultModel = await InsertQueueAch(model);
            return operationResultModel;
        }
        private async Task<OperationResultModel> InsertQueueAch(VoidModel model)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
                ResultDescription = ConstantValues.ACHSUCCESS
            };
            try
            {
                QueueAchModel queueAchModel = new()
                {
                    ParticipantId = model.ParticipantId.ToString(),
                    UserId = model.UserId,
                    EventType = "14",
                    EventDate = DateTime.Now.ToString(),
                    FormNumber = "R036",
                    EventSource = "WEB",
                    DueDate = DateTime.Now.AddDays(1).ToString(),
                    EventDescription=model.Reason,
                };
                await InsertQueueAch(queueAchModel);
                return operationResultModel;
            }
            catch (Exception ex)
            {
                _ = ex.Message;
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = ConstantValues.ACHFAILED;
                return operationResultModel;
            }
        }
        private async Task InsertQueueAch(QueueAchModel queueAchModel)
        {
            Query rehireEvent = ParticipantExecSP.CreatePrintEvents(queueAchModel);
            string error = await ExecuteGenericRowOutput(rehireEvent, "@ErrorCount", rehireEvent.Parameters!.Count - 1);
            if (error != "0")
                throw new Exception("Error Saving Queue");
        }
        private async Task<OperationResultModel> NewAddress(AddressModel insertModel, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
                ResultDescription = string.Format(ConstantValues.DEPENDENTADDRESSSUCCESS)
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                AddressModel address = new()
                {
                    ParticipantId = insertModel.DependentId,
                    Address1 = insertModel.Address1,
                    Address2 = insertModel.Address2 ?? "",
                    City = insertModel.City,
                    State = insertModel.State ?? "",
                    Zip = insertModel.Zip ?? "",
                    UserId = insertModel.UserId,
                };
                await InsertAddress(address);
                EventModel _event;
                EventParameterModel eventModel = ConvertToAddressModel(insertModel);
                _event = GetEventModel(eventModel, "79");
                await InsertEvent(_event);

                await transaction.CommitAsync();
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _ = ex.Message;
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = ConstantValues.DEPENDENTADDRESSFAIL;
                return operationResultModel;
            }
        }
        private async Task<OperationResultModel> NewParticipant(ParticipantInsertModel insertModel, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                int participantId = await InsertParticipant(insertModel);
                if (participantId > 0)
                {
                    insertModel.ParticipantInfo.ParticipantNewId = participantId;
                    EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);

                    AddressModel address = GetAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                    await InsertAddress(address);
                    EventModel _event;
                    if (insertModel.RightNotices != null && insertModel.RightNotices.CobraYN == "Y")
                    {
                        _event = GetEventModel(eventModel, "48");
                        await InsertEvent(_event);
                    }
                    if (insertModel.RightNotices != null && insertModel.RightNotices.HipaaYN == "Y")
                    {
                        _event = GetEventModel(eventModel, "49");
                        await InsertEvent(_event);
                    }

                    eventModel.UserId = insertModel.UserId;
                    _event = GetEventModel(eventModel, "04");
                    await InsertEvent(_event);

                    //Only for rehire insertModel.RehireDB!=""
                    await ProcessEligibiity(insertModel);

                    //SpecificFields
                    await ProcessSpecificFields(insertModel.SpecificFields!, insertModel.UserType, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                    if (insertModel.Dependents != null)
                    {
                        List<DependentNewViewModel>? Dependents;
                        Dependents = insertModel.Dependents.Where(dep => dep.ParticipantId > 0).ToList();
                        if (Dependents.Any())
                        {
                            DependentOldModel dependentsOld = GetDependentsOld(Dependents, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                            await InsertDependentsOld(dependentsOld);
                        }
                        await ProcessNewDependents(insertModel.Dependents, insertModel!.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                    }
                }
                await transaction.CommitAsync();
                operationResultModel.ParticipantId = insertModel.ParticipantInfo.ParticipantNewId.ToString();
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                string eror = ex.Message;
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.ADDFAIL, insertModel.ParticipantInfo.SocialSecurityNumber);
                return operationResultModel;
            }
        }
        private static EventParameterModel ConvertToAddressModel(InfoResultViewModel insertModel, string userId)
        {
            EventParameterModel eventModel = new()
            {
                ParticipantId = insertModel.ParticipantNewId,
                FirstName = insertModel.FirstName,
                LastName = insertModel.LastName,
                SocialSecurityNumber = insertModel.SocialSecurityNumber,
                HireDate = insertModel.HireDate,
                BirthDate = insertModel.BirthDate,
                UserId= userId
            };
            return eventModel;
        }
        private static EventParameterModel ConvertToAddressModel(AddressModel insertModel)
        {
            EventParameterModel eventModel = new()
            {
                ParticipantId = insertModel.ParticipantId,
                UserId = insertModel.UserId,
                CustomComment = string.Concat(string.Format("Dependent ID {0} Address updated to {1} {2}, {3} {4}, {5}", insertModel.DependentId, insertModel.Address1, insertModel.City, insertModel.State, insertModel.Zip, insertModel.UserId))
        };
            return eventModel;
        }
        private async Task ProcessEligibiity(ParticipantInsertModel insertModel)
        {
                RehireModel rehire;
                if (string.IsNullOrEmpty(insertModel.RehireDB))
                    return;
                if (insertModel.RehireDB == "B")
                     rehire = GetRehireB(insertModel);
                else
                     rehire = GetRehireElse(insertModel);
                await InsertRehire(rehire);
                EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                EventModel _event = GetEventModel(eventModel, "EH");
                await InsertEvent(_event);
        }
        private async Task ProcessNewDependents(List<DependentNewViewModel>? dependents, int participantId, string userId, bool retrieveDependentId = false)
        {
            List<DependentNewViewModel>? Dependents =dependents?.Where(dep => dep.ParticipantId.ToString()!.Length < 3).ToList(); 
            if (Dependents!=null && Dependents.Count > 0)
            {
                GetDependentsNew(Dependents, participantId);
                foreach (DependentNewViewModel dependent in Dependents)
                {
                    if (!retrieveDependentId)
                    {
                        await InsertDependentsNew(dependent);
                    }
                    else
                    {
                        var dependentId = await InsertDependentsNewRetrieveId(dependent);
                        dependent.ParticipantNewId = dependentId;
                        dependent.ParticipantId = null;
                    }
                    


                    EventModel eventModel = GetEventModel(dependent, "43", userId);
                    await InsertEvent(eventModel);
                }
            }
        }
        private async Task InsertDependentProcesssQE(List<DependentNewViewModel>? dependents, int participantId, string userId, string userName)
        {
            List<DependentNewViewModel>? Dependents = dependents?.Where(dep => dep.ParticipantId == null).ToList();
            if (Dependents != null && Dependents.Count > 0)
            {
                GetDependentsNew(Dependents, participantId);
                foreach (DependentNewViewModel dependent in Dependents)
                {
                    await InsertDependentsNew(dependent);
                    EventModel eventModel = GetDependentEventModel(dependent, "43", userId, userName);
                    await InsertEvent(eventModel);
                }
            }
        }
        private static RehireModel GetRehireB(ParticipantInsertModel participantModel)
        {
            RehireModel rehireModel = new()
            {
                ParticipantId = participantModel.ParticipantInfo.ParticipantNewId,
                ClientId = participantModel.ClientId,
                SSN = participantModel.ParticipantInfo.SocialSecurityNumber ?? "",
                BeneficiaryDate = "",
                HireDate =  participantModel.ParticipantInfo.ReHireDate,
                UserId = participantModel.UserId,
                Debug= "0",
                DirectBill= "1"
            };
            return rehireModel;
        }
        private static DependentOldModel GetDependentsOld(List<DependentNewViewModel> Dependents, int ParticipantId, string UserId)
        {
            string xml= "<root>";
            foreach(DependentNewViewModel dependent in Dependents)
            {
                xml = string.Concat(xml,string.Format("<Dependent Id='{0}' FirstName='{1}' LastName='{2}' SSN='{3}' Gender='{4}'", dependent.ParticipantId , dependent.FirstName, dependent.LastName, dependent.SocialSecurityNumber, dependent.Gender));
                xml = string.Concat(xml, string.Format(" DOB='{0}' Relationship='{1}' Student='{2}' QualifiedBeneficiary='{3}' Status='{4}'/>", dependent.BirthDate, dependent.Relationship, dependent.Student, dependent.QualifiedBeneficiary,'A'));
            }
            xml = string.Concat(xml, "</root>");
            DependentOldModel rehireModel = new()
            {
                ParticipantId = ParticipantId,
                UserId = UserId,
                DependentInfo= xml
            };
            return rehireModel;
        }
        private static void GetDependentsNew(List<DependentNewViewModel> Dependent, int ParticipantId)
        {
            Dependent.ForEach(item =>
            {
                item.ParticipantId = ParticipantId;
                item.ParticipantType = "D";
            });
        }
        private static RehireModel GetRehireElse(ParticipantInsertModel participantModel)
        {
            RehireModel rehireModel = new()
            {
                ParticipantId = participantModel.ParticipantInfo.ParticipantNewId,
                ClientId = participantModel.ClientId,
                SSN = participantModel.ParticipantInfo.SocialSecurityNumber ?? "",
                BeneficiaryDate = "",
                HireDate =participantModel.ParticipantInfo.CoverageStartDate,
                UserId = participantModel.UserId,
                Debug = "0",
                DirectBill = "0"
            };
            return rehireModel;
        }
        private static AddressModel GetAddressModel(InfoResultViewModel participantModel, string UserId)
        {
            AddressModel addressModel = new()
            {
                ParticipantId = participantModel.ParticipantNewId,
                Address1 = participantModel.Address1,
                Address2 = participantModel.Address2 ?? "",
                City = participantModel.City,
                State = participantModel.State ?? "" ,
                Zip = participantModel.Zip ?? "" ,
                UserId = UserId,
            };
            return addressModel;
        }
        private static EventModel GetEventModelByField(InfoResultViewModel participantInfoOld, InfoResultViewModel participantInfo, string fieldName, string userId)
        {
            string eventType = "76";
            string comment = fieldName switch
            {
                "Names" => string.Concat(string.Format("Participant Name Updated from {0} {1} {2} to: {3} {4} {5}", participantInfoOld!.FirstName, participantInfoOld!.MiddleInitial,participantInfoOld!.LastName,participantInfo!.FirstName,participantInfo!.MiddleInitial,participantInfo!.LastName)),
                "Email" => string.Concat(string.Format("Participant Email Updated from {0} to: {1} ", participantInfoOld!.EmailAddress, participantInfo!.EmailAddress)),
                "Phone" => string.Concat(string.Format("Participant phone Updated from {0} to: {1} ", participantInfoOld!.PhoneNumber,participantInfo!.PhoneNumber)),
                "Location" => string.Concat(string.Format("Participant Location Updated from {0} to: {1} ", participantInfoOld!.AffiliateName,participantInfo!.AffiliateName)),
                "Number" => string.Concat(string.Format("Participant Employee Number Updated from {0} to: {1} ", participantInfoOld!.EmployeeNumber,participantInfo!.EmployeeNumber)),
                "Birth" => string.Concat(string.Format("Participant Birth Date Updated from {0} to: {1} ", participantInfoOld!.BirthDate,participantInfo!.BirthDate)),
                "Hire" => string.Concat(string.Format("Participant Hire Date Updated from {0} to: {1} ", participantInfoOld!.HireDate,participantInfo!.HireDate)),
                "Class" => string.Concat(string.Format("Participant Employee Class Updated from {0} to: {1} ", participantInfoOld!.ClassName,participantInfo!.ClassName)),
                "QualifiedBeneficiary" => string.Concat(string.Format("Participant Medical/Dental status updated from {0} to: {1} ", participantInfoOld!.QualifiedBeneficiary, participantInfo!.QualifiedBeneficiary)),
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId = int.Parse(participantInfo!.ParticipantId!),
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId =userId,
            };
            return eventModel;
        }
        private static EventModel GetEventDependentModelByField(DependentNewViewModel participantInfoOld, DependentNewViewModel participantInfo, string fieldName, string userId, int participantId)
        {
            string eventType = "77";
            string comment = fieldName switch 
            {
                "Names" => string.Concat(string.Format("Dependent # {0} Name Updated from {1} {2} to: {3} {4}", participantInfoOld.ParticipantId, participantInfoOld!.FirstName, participantInfoOld!.LastName, participantInfo!.FirstName,  participantInfo!.LastName)),
                "SSN" => string.Concat(string.Format("Dependent # {0} Social Security Number Updated from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.SocialSecurityNumber, participantInfo!.SocialSecurityNumber)),
                "Birth" => string.Concat(string.Format("Dependent # {0} Birth Date Updated from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.BirthDate, participantInfo!.BirthDate)),
                "Gender" => string.Concat(string.Format("Dependent # {0} Gender Changed  from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.GenderDesc, participantInfo!.GenderDesc)),
                "Relationship" => string.Concat(string.Format("Dependent # {0} Relationship Updated from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.RelationshipDesc, participantInfo!.RelationshipDesc)),
                "Student" => string.Concat(string.Format("Dependent # {0} Student Status Updated from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.StudentDesc, participantInfo!.StudentDesc)),
                "Status" => string.Concat(string.Format("Dependent # {0} Status Updated from {1} to: {2} ", participantInfoOld.ParticipantId, participantInfoOld!.StatusDesc, participantInfo!.StatusDesc)),
                "QualifiedBeneficiary" => string.Concat(string.Format("Dependent # {0} Medical Dental Covered Status Updated from {0} to: {1} ", participantInfoOld.ParticipantId, participantInfoOld!.QualifiedBeneficiary, participantInfo!.QualifiedBeneficiary)),
                "ID" => string.Concat(string.Format("Dependent # {0} Employee Number Updated from {0} to: {1} ", participantInfoOld.ParticipantId, participantInfoOld!.EmployeeNumber, participantInfo!.EmployeeNumber)),
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId = participantId,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private static EventModel GetEventModel(EventParameterModel participantModel, string eventType)
        {
            string comment  = eventType switch
            {
                "04" => string.Concat(string.Format("Participant Added: {0} {1} SSN: {2} DOH: {3} DOB: {4}", participantModel.FirstName, participantModel.LastName, participantModel.SocialSecurityNumber, participantModel.HireDate, participantModel.BirthDate)),
                "08" => string.Concat(string.Format("Participant Added: {0} {1} SSN: {2} DOH: {3} DOB: {4}", participantModel.FirstName, participantModel.LastName, participantModel.SocialSecurityNumber, participantModel.HireDate, participantModel.BirthDate)),
                "EH" => string.Concat(string.Format("Eligibility Hold Evaluated During Rehire")),
                "48" => string.Concat(string.Format("User {0} Indicated that Initial COBRA Rights Notices had been sent.'",  participantModel.UserId)),
                "49" => string.Concat(string.Format("User {0} Indicated that Initial HIPAA Rights Notices had been sent.'", participantModel.UserId)),
                "76" => string.Concat(string.Format("Participant info updated for User {0}", participantModel.UserId)),
                "77" => string.Concat(string.Format("Dependent info updated for User {0}", participantModel.UserId)),
                "DP" => string.Concat(string.Format("Dependent coverage exceptions under {0} marked acceptable", participantModel.PlanName)),
                "79" => participantModel.CustomComment,
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId = participantModel.ParticipantId,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = participantModel.UserId,
            };
            return eventModel;
        }
        private static EventModel GetEventSpecificfieldsModel(int participantId, string userId, string eventType)
        {
            string comment = eventType switch
            {
                "04" => string.Concat(string.Format("Employer-Specific Fields added for PID:{0}, {1} ", participantId, userId)),
                "76" => string.Concat(string.Format("Employer-Specific Fields added for PID:{0}, {1} ", participantId, userId)),
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId = participantId,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private static EventModel GetEventModel(DependentNewViewModel participantModel, string eventType, string userId)
        {
            string comment = eventType switch
            {
               "43" => string.Concat(string.Format("Dependent {0} {1} added, Relationship = {2} , Birth Date = {3}", participantModel.FirstName, participantModel.LastName, participantModel.Relationship, participantModel.BirthDate)),
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId =participantModel.ParticipantId??0,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private static EventModel GetDependentEventModel(DependentNewViewModel participantModel, string eventType, string userId, string userName)
        {
            string comment = eventType switch
            {
                "43" => string.Concat(string.Format("Dependent {0} {1} added by User {2},ID# {3}", participantModel.FirstName, participantModel.LastName, userName, userId)),
                _ => "",
            };
            EventModel eventModel = new()
            {
                ParticipantId = participantModel.ParticipantId ?? 0,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private async Task<int> InsertParticipant(ParticipantInsertModel insertModel)
        {
            Query insertParticipant = ParticipantInserts.InsertParticipant(insertModel);
            string participantId = await ExecuteGenericRowOutput(insertParticipant, "@Pid", insertParticipant.Parameters != null ? insertParticipant.Parameters.Count - 1 : 0);
            return int.Parse(participantId);
        }
        private async Task InsertAddress(AddressModel address)
        {
            Query insertAddress = ParticipantInserts.InsertAddress(address);
            await ExecuteGenericNoReturn(insertAddress);
        }
        private async Task InsertEvent(EventModel _event)
        {
            Query insertEvent = ParticipantInserts.InsertEvent(_event);
            await ExecuteGenericNoReturn(insertEvent);
        }
        private async Task InsertRehire(RehireModel rehire)
        {
            Query rehireEvent = ParticipantExecSP.InsertRehire(rehire);
            _ = await ExecuteGenericRowOutput(rehireEvent, "@Result", 5);
        }
        private async Task InsertDependentsOld(DependentOldModel dependents)
        {
            Query dependent = ParticipantExecSP.InsertDependents(dependents);
            await ExecuteGenericNoReturn(dependent);
        }
        private async Task<int> InsertDependentsNewRetrieveId(DependentNewViewModel Dependent)
        {
            Query dependent = ParticipantInserts.InsertDependentParticipant(Dependent, true);
            string participantId = await ExecuteGenericRowOutput(dependent, "@Pid", dependent.Parameters != null ? dependent.Parameters.Count - 1 : 0);
            return int.Parse(participantId);
        }
        private async Task InsertDependentsNew(DependentNewViewModel Dependent)
        {
            Query dependent = ParticipantInserts.InsertDependentParticipant(Dependent);
            await ExecuteGenericNoReturn(dependent);
        }
        public async Task<OperationResultModel> UpdateDisability(DisabilityUpdateModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            OperationResultModel operationResultModel = await UpdateDisabilityDate(model, database);           
            return operationResultModel;  
        }
        private async Task<OperationResultModel> UpdateDisabilityDate(DisabilityUpdateModel model, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
                ResultDescription = string.Format(ConstantValues.DISABILITYSUCCESS, model.Name,model.ParticipantId)
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                QueryT disabilityEvent = ParticipantExecSP.UpdateDisability(model);
                var disabilityUpdated = await ExecuteGenericSpecificRow(disabilityEvent);                
                await transaction.CommitAsync();
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                string mesage="Transaction failed";
                _logger.LogError(message: mesage, ex);
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.DISABILITYFAIL, model.ParticipantId);
                operationResultModel.ErrorDetails = ex.ToString();
                return operationResultModel;
            }
        }
        private async Task ProcessSpecificFields(List<SpecificFieldsModel> insertModel, string userType, int participantId, string userId)
        {
            string xml = GetSpecificFields(insertModel!, userType, participantId);
            SpecificFieldsInsertModel spModel = GetSpecificFieldsModel(userId, xml);
            Query specific = ParticipantExecSP.InsertSpecificFields(spModel);
            await ExecuteGenericNoReturn(specific);
        }
        private static string GetSpecificFields(List<SpecificFieldsModel> insertModel, string userType, int participantId)
        {
            string xml = "'<ParticipantCustomFields>";
            string replaceChars = "";
            if (insertModel != null&& insertModel.Count>0)
            {
                xml = "'<ParticipantCustomFields>";
                foreach (SpecificFieldsModel model in insertModel)
                {
                    if(model.ShowOnWeb==true || userType == "I" || userType == "O")
                    {
                        if (model.CustomFieldId>0)
                        {
                            replaceChars = !string.IsNullOrEmpty(model.FieldValue) ? model.FieldValue!.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("''", "") : "";
                            xml = string.Concat(xml, "<ParticipantCustomField>");
                            xml = string.Concat(xml, string.Format("<ParticipantId>{0}</ParticipantId>", participantId));
                            xml = string.Concat(xml, string.Format("<CustomFieldId>{0}</CustomFieldId>", model.CustomFieldId));
                            xml = string.Concat(xml, string.Format("<FieldValue>{0}</FieldValue>", replaceChars));
                            xml = string.Concat(xml, "</ParticipantCustomField>");
                        }
                    }
                }
            }
            xml = string.Concat(xml, "</ParticipantCustomFields>");
            return xml;
        }
        private static SpecificFieldsInsertModel GetSpecificFieldsModel(string userId , string xml)
        {
            SpecificFieldsInsertModel specificFieldsInsert = new()
            {
                UserId = userId,
                Xml = xml
            };
            return specificFieldsInsert;
        }
        public async Task<OperationResultModel> UpdateEmployerChange(EmployerChangeUpdateModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            OperationResultModel operationResultModel = await UpdateClientForEmployerChange(model, database);
            return operationResultModel;
        }
        private async Task<OperationResultModel> UpdateClientForEmployerChange(EmployerChangeUpdateModel model, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
                ResultDescription = string.Format(ConstantValues.EMPLOYERCHANGESUCCESS, model.Name, model.ParticipantId)
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                await UpdateClientForEmployerChange(model);
                EventModel eventModel = new()
                {
                    ParticipantId = Convert.ToInt32(model.ParticipantId),
                    EventType = "78",
                    EventSource = "WEB",
                    Comment = string.Concat(string.Format("Participant moved from Client ID {0} to {1} because: {2}, {3}", model.ClientId, model.NewClientId, model.Reason, model.UserId)),
                    UserId = model.UserId,
                };
                await InsertEvent(eventModel);
                await transaction.CommitAsync();
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                string mesage = "Transaction failed";
                _logger.LogError(mesage, ex);
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.EMPLOYERCHANGEFAIL, model.ParticipantId);
                operationResultModel.ErrorDetails = ex.ToString();
                return operationResultModel;
            }
        }
        private async Task UpdateClientForEmployerChange(EmployerChangeUpdateModel Dependent)
        {
            Query clientQuery = ParticipantInserts.UpdateClientForEmployerChange(Dependent);
            await ExecuteGenericNoReturn(clientQuery);
        }
        public async Task<CoverageChangeResultModel> UpdateCoverageChange(CoverageChangeAvailablePlansModel model, string platformConnection)
        {
            var database = _db.Database;
            database.SetConnectionString(platformConnection);
            CoverageChangeResultModel operationResultModel = await UpdateCoverageChange(model, database);
            return operationResultModel;
        }
        private async Task<CoverageChangeResultModel> UpdateCoverageChange(CoverageChangeAvailablePlansModel model, DatabaseFacade database)
        {
            CoverageChangeResultModel operationResultModel = new()
            {
                Success = true,
                ResultDescription = string.Format(ConstantValues.COVERAGECHANGESUCCESS, model.Name, model.ParticipantId),
                PlanName = new List<string>()
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                if(model.UpdateCoverageChanges != null && model.UpdateCoverageChanges.Count > 0)
                {
                    foreach (var updateChange in model.UpdateCoverageChanges)
                    {
                        Query coverageChange = CoverageInserts.UpdateCoverageForParticipantChange(updateChange);
                        await ExecuteGenericNoReturn(coverageChange);
                        operationResultModel?.PlanName?.Add(updateChange.PlanName);
                        EventModel eventModel = GetEventModelForUpdateCoverage(updateChange, model.ParticipantId, model.UserId);                        
                        await InsertEvent(eventModel);
                    }
                }
                if (model.DropCoverageChanges != null && model.DropCoverageChanges.Count > 0)
                {
                    foreach (var dropChange in model.DropCoverageChanges)
                    {
                        Query dropCoverageChange = CoverageInserts.DropCoverageForParticipantChange(dropChange);
                        await ExecuteGenericNoReturn(dropCoverageChange);
                        operationResultModel?.PlanName?.Add(dropChange.PlanName);
                        EventModel eventModel = new()
                        {
                            ParticipantId = Convert.ToInt32(model.ParticipantId),
                            EventType = "C4",
                            EventSource = "WEB",
                            Comment = string.Concat(string.Format("Coverage Dropped: {0} ({1}) effective {2}.", dropChange.PlanName, dropChange.PlanId, dropChange.EffectiveDate)),
                            UserId = model.UserId,
                        };
                        await InsertEvent(eventModel);
                    }
                }
                if (model.NewCoverageChanges != null && model.NewCoverageChanges.Count > 0)
                {
                    foreach (var newChange in model.NewCoverageChanges)
                    {   
                        Query newCoverageChange = CoverageInserts.AddCoverageForParticipantChange(newChange);
                        await ExecuteGenericNoReturn(newCoverageChange);
                        operationResultModel?.PlanName?.Add(newChange.PlanName);
                        EventModel eventModel = GetEventModelForNewCoverage(newChange, model.ParticipantId, model.UserId);
                        await InsertEvent(eventModel);
                    }
                }                
                await transaction.CommitAsync();
                return operationResultModel!;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                string mesage = "Transaction failed";
                _logger.LogError(mesage, ex);
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.COVERAGECHANGEFAIL, model.ParticipantId);
                operationResultModel.ErrorDetails = ex.ToString();
                return operationResultModel;
            }
        }   
        private static EventModel GetEventModelForUpdateCoverage(UpdateCoverageChangeModel updateChange, int participantId, string userId)
        {
            EventModel eventModel = new()
            {
                ParticipantId = Convert.ToInt32(participantId),
                EventType = "C2",
                EventSource = "WEB",
                UserId = userId,
                Comment = string.Format("Coverage Updated: {0} ({1}). ", updateChange.PlanName, updateChange.PlanId)
            };
            if (updateChange.NewCoverageCode != updateChange.OldCoverageCode)
            {
                eventModel.Comment = string.Concat(eventModel.Comment, string.Format("Coverage level updated from {0} to {1}. ", updateChange.OldCoverageCode, updateChange.NewCoverageCode));
            }
            if (updateChange.RateType == "MI")
            {
                if (updateChange.NewFixedPremium != updateChange.OldFixedPremium)
                {
                    if (string.IsNullOrWhiteSpace(updateChange.NewCoverageCode))
                    {
                        eventModel.Comment = string.Concat(eventModel.Comment, string.Format("Fixed Premium updated from {0} to No Override. ", updateChange.OldCoverageCode));
                    }
                    else
                    {
                        eventModel.Comment = string.Concat(eventModel.Comment, string.Format("Fixed Premium updated from {0} to {1}. ", updateChange.OldCoverageCode, updateChange.NewCoverageCode));
                    }
                }
            }
            if (updateChange.RateType == "IR")
            {
                if (updateChange.NewFixedPremium != updateChange.OldFixedPremium)
                {
                    eventModel.Comment = string.Concat(eventModel.Comment, string.Format("Fixed Premium updated from {0} to {1}. ", updateChange.OldCoverageCode, updateChange.NewCoverageCode));
                }
            }
            return eventModel;
        }
        private static EventModel GetEventModelForNewCoverage(NewCoverageChangeModel newCoverageChange, int participantId, string userId)
        {
            EventModel eventModel = new()
            {
                ParticipantId = Convert.ToInt32(participantId),
                EventType = "C1",
                EventSource = "WEB",
                UserId = userId,
                Comment = string.Format("New Coverage Added: {0} ({1}) ", newCoverageChange.PlanName, newCoverageChange.PlanId)
            };
            eventModel.Comment = string.Concat(eventModel.Comment, string.Format("with a coverage level of {0}. ", newCoverageChange.NewCoverageCode));
            if (!string.IsNullOrEmpty(newCoverageChange.NewFixedPremium))
                eventModel.Comment = string.Concat(eventModel.Comment, string.Format("Fixed Premium: {0}", newCoverageChange.NewFixedPremium));            
            return eventModel;
        }
        private async Task<OperationResultModel> NewTakeOver(InfoSessionModel insertModel, DatabaseFacade database)
        {
            string converageState = "C";
            bool isUpdated = false;
            OperationResultModel operationResultModel = new()
            {
                Success = true,
                DependentError=false,
            };
            bool isNewParticipant = false;
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                if (string.IsNullOrEmpty(insertModel.ParticipantInfo!.ParticipantId))
                {
                    isNewParticipant = true;
                    ParticipantInsertModel insertParticipantModel = new()
                    {
                        ClientId = insertModel.ClientId,
                        Dependents = insertModel.Dependents,
                        ParticipantInfo = insertModel.ParticipantInfo,
                        PlatformName = insertModel.PlatformName,
                        SpecificFields = insertModel.SpecificFields,
                        UserId = insertModel.UserId,
                        UserType = insertModel.UserType,
                        Status = ConstantValues.PARTICIPANT_STATUS_A,
                        ParticipantType = ConstantValues.PARTICIPANT_TYPE_E
                    };

                    OperationResultModel operationResultModelNewParticipant = await NewParticipant(insertParticipantModel, database);
                    if (!operationResultModelNewParticipant.Success)
                        return operationResultModelNewParticipant;

                    insertModel.ParticipantInfo.ParticipantId = operationResultModelNewParticipant.ParticipantId;
                }
           
                if (!isNewParticipant)
                    await UpdateParticipant(insertModel.ParticipantInfo!);

                InfoResultViewModel infoOld = insertModel.ParticipantInfoOld!;
                InfoResultViewModel infoNew = insertModel.ParticipantInfo!;
                EventModel _event;
                await SaveEventParticipant(infoOld, infoNew, insertModel.UserId);

                insertModel.ParticipantInfo!.ParticipantNewId = int.Parse(insertModel.ParticipantInfo.ParticipantId!);
                EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);

                //Save Addres, but first check if some data has changed
                if(CheckAddressModification(insertModel.ParticipantInfo, insertModel.Address!))
                {
                    AddressModel address = GetAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                    await InsertAddress(address);
                    eventModel.CustomComment = GetCustomFromTakeOver(address, insertModel.Address!);
                    _event = GetEventModel(eventModel, "79");
                    await InsertEvent(_event);
                }
                //SpecificFields
                await ProcessSpecificFields(insertModel.SpecificFields!, insertModel.UserType, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
          
                if (insertModel.Dependents != null)
                {
                    List<DependentNewViewModel>? Dependents;
                    Dependents = insertModel.Dependents.Where(dep => dep.ParticipantId > 0).ToList();
                    if (Dependents.Any())
                    {
                        // await UpdateOldDependent(Dependents, insertModel.ClientId);
                        foreach (DependentNewViewModel dependentNew in Dependents)
                        {
                            DependentNewViewModel? DependentsOld = insertModel.DependentsOld?.Where(dep => dep.ParticipantId == dependentNew.ParticipantId).FirstOrDefault();
                            if (DependentsOld != null)
                            {
                                isUpdated = ValidateDependentOldModified(DependentsOld, dependentNew);
                                if (isUpdated)
                                {
                                    await UpdateOldDependent(dependentNew, insertModel.ClientId);
                                    await DependentOldModified(DependentsOld, dependentNew, insertModel.UserId, insertModel.ParticipantInfo.ParticipantNewId);
                                }
                                await MedicalDental(DependentsOld, dependentNew, insertModel.UserId, (dependentNew.ParticipantId ??0) .ToString(), insertModel.ClientId);
                            }
                        }
                    }
                    await ProcessNewDependents(insertModel.Dependents, insertModel!.ParticipantInfo.ParticipantNewId, insertModel.UserId, true);
                }

                //Coverage and Process QE
                await UpdateParticipantQE(insertModel.ProcessQE!, insertModel.ParticipantInfo.ParticipantNewId);

                await CalculateEligibilityEndDate(insertModel.ParticipantInfo.ParticipantNewId, insertModel.ProcessQE!.QeReason!, insertModel.ProcessQE!.LastDayPreCobraCoverage!);

                _event = GetEventQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId);
                await InsertEvent(_event);

                //Add Converage
                await NewCoverage(insertModel, AvailablePlanTypeEnum.New, converageState);

                await InsertEventCoverage(insertModel);

                await InsertDependentConveraege(insertModel.ParticipantInfo.ParticipantNewId);

                await transaction.CommitAsync();
                //await transaction.RollbackAsync();
                operationResultModel.ParticipantId = insertModel.ParticipantInfo.ParticipantNewId.ToString();
                return operationResultModel;
            }
            catch
            {
                await transaction.RollbackAsync();
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.TAKEOVERFAIL, insertModel.ParticipantInfo!.ParticipantId);
                return operationResultModel;
            }
        }
        private async Task<OperationResultModel> NewProcessQE(InfoSessionModel insertModel, DatabaseFacade database)
        {
            string process = "QE";
            bool isUpdated = false;
            OperationResultModel operationResultModel = new()
            {
                Success = true,
            };
            bool isNewParticipant = false;

            using var transaction = await database.BeginTransactionAsync();
            try
            {
                if (string.IsNullOrEmpty(insertModel.ParticipantInfo!.ParticipantId))
                {
                    isNewParticipant = true;
                    ParticipantInsertModel insertParticipantModel = new()
                    {
                        ClientId = insertModel.ClientId,
                        Dependents = insertModel.Dependents,
                        ParticipantInfo = insertModel.ParticipantInfo,
                        PlatformName = insertModel.PlatformName,
                        SpecificFields = insertModel.SpecificFields,
                        UserId = insertModel.UserId,
                        UserType = insertModel.UserType,
                        Status = ConstantValues.PARTICIPANT_STATUS_A,
                        ParticipantType = ConstantValues.PARTICIPANT_TYPE_E
                    };

                    OperationResultModel operationResultModelNewParticipant =  await NewParticipant(insertParticipantModel, database);
                    if (!operationResultModelNewParticipant.Success)
                        return operationResultModelNewParticipant;

                    insertModel.ParticipantInfo.ParticipantId = operationResultModelNewParticipant.ParticipantId;
                }
                 
                bool coverages = false; 
                if (!isNewParticipant)
                    await UpdateParticipant(insertModel.ParticipantInfo!);

                InfoResultViewModel infoOld = insertModel.ParticipantInfoOld!;
                InfoResultViewModel infoNew = insertModel.ParticipantInfo!;
                EventModel _event;
                await SaveEventParticipant(infoOld, infoNew, insertModel.UserId);

                insertModel.ParticipantInfo!.ParticipantNewId = int.Parse(insertModel.ParticipantInfo.ParticipantId!);
                EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
  
                //Save Addres, but first check if some data has changed
                if (CheckAddressModification(insertModel.ParticipantInfo, insertModel.Address!))
                {
                    AddressModel address = GetAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                    await InsertAddress(address);
                    eventModel.CustomComment = GetCustomFromTakeOver(address, insertModel.Address!);
                    _event = GetEventModel(eventModel, "79");
                    await InsertEvent(_event);
                }
                //CHECK LANGUAGE...Request.Form("opartlanguage") & " to " & Request.Form("partlanguage")
                await ProcessSpecificFields(insertModel.SpecificFields!, insertModel.UserType, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                if (insertModel.Dependents != null)
                {
                    List<DependentNewViewModel>? Dependents;
                    Dependents = insertModel.Dependents.Where(dep => dep.ParticipantId > 0).ToList();
                    if (Dependents.Any())
                    {
                        // await UpdateOldDependent(Dependents, insertModel.ClientId);
                        foreach (DependentNewViewModel dependentNew in Dependents)
                        {
                            DependentNewViewModel? DependentsOld = insertModel.DependentsOld?.Where(dep => dep.ParticipantId == dependentNew.ParticipantId).FirstOrDefault();
                            if (DependentsOld != null)
                            {
                                isUpdated = ValidateDependentOldModified(DependentsOld, dependentNew);
                                if (isUpdated)
                                {
                                    await UpdateOldDependent(dependentNew, insertModel.ClientId);
                                    await DependentOldModified(DependentsOld, dependentNew, insertModel.UserId,insertModel.ParticipantInfo.ParticipantNewId);
                                }
                                await MedicalDental(DependentsOld, dependentNew, insertModel.UserId, (dependentNew.ParticipantId ?? 0).ToString(), insertModel.ClientId);
                            }
                        }
                    }
                    await ProcessNewDependents(insertModel.Dependents, insertModel!.ParticipantInfo.ParticipantNewId, insertModel.UserId, true);
                }
                //Coverage and Process QE
                if (insertModel.AvailablePlans != null)
                    coverages = (insertModel.AvailablePlans.ExistingPlansClient != null && insertModel.AvailablePlans.ExistingPlansClient.Count > 0) || (insertModel.AvailablePlans.AvailablePlansClient != null && insertModel.AvailablePlans.AvailablePlansClient.Count > 0);

                DependentProcessQEModel model = new()
                {
                    ProcessQE = insertModel.ProcessQE,
                    ParticipantInfo = insertModel.ParticipantInfo,
                    ClientId = insertModel.ClientId,
                    PlatformName = insertModel.PlatformName,
                    UserId = insertModel.UserId,
                    Address = insertModel.Address,
                    AvailablePlans = insertModel.AvailablePlans,
                    Dependents = insertModel.Dependents,
                    SpecificFields = insertModel.SpecificFields,
                    UserType = insertModel.UserType,
                };

                await ProcessQualifyingEvent(model!, coverages, process);

                await InsertDependentConveraege(insertModel.ParticipantInfo.ParticipantNewId);

                await transaction.CommitAsync();
                operationResultModel.ParticipantId = insertModel.ParticipantInfo.ParticipantNewId.ToString();
                operationResultModel.ResultDescription = string.Format(ConstantValues.PROCESSQESUCCESS, insertModel.ParticipantInfo!.FirstName, insertModel.ParticipantInfo!.LastName, insertModel.ParticipantInfo!.ParticipantId);
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                string eror = ex.Message;
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.PROCESSQEFAIL, insertModel.ParticipantInfo!.ParticipantId);
                return operationResultModel;
            }
        }
        private async Task MedicalDental(DependentNewViewModel DependentsOld, DependentNewViewModel dependentNew, string userId, string participantId, string clientID)
        {
            EventModel _event;
            if (DependentsOld!.QualifiedBeneficiary != dependentNew!.QualifiedBeneficiary)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "QualifiedBeneficiary", userId, int.Parse(participantId));
                await InsertEvent(_event);
                await UpdateMedicalDent(participantId, clientID, dependentNew!.QualifiedBeneficiary);
            }
        }
        private async Task DependentOldModified(DependentNewViewModel DependentsOld, DependentNewViewModel dependentNew, string userId, int participantId)
        {
            EventModel _event;
            if (DependentsOld.LastName!.Trim() != dependentNew.LastName!.Trim() || DependentsOld.FirstName!.Trim() != dependentNew.FirstName!.Trim() || (DependentsOld.MiddleInitial ?? "").Trim() != (dependentNew.MiddleInitial ?? "").Trim())
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Names", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.SocialSecurityNumber!.Trim() != (dependentNew.SocialSecurityNumber ?? "").Trim())
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "SSN", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.BirthDate != dependentNew.BirthDate)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Birth", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.GenderDesc != dependentNew.GenderDesc)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Gender", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.Relationship != dependentNew.Relationship)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Relationship", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.Student != dependentNew.Student)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Student", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.ParticipantStatus != dependentNew.ParticipantStatus)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "Status", userId, participantId);
                await InsertEvent(_event);
            }
            if (DependentsOld.EmployeeNumber != dependentNew.EmployeeNumber)
            {
                _event = GetEventDependentModelByField(DependentsOld, dependentNew, "ID", userId, participantId);
                await InsertEvent(_event);
            }
        }
        private bool ValidateDependentOldModified(DependentNewViewModel dependentsOld, DependentNewViewModel dependentNew)
        {
            return (dependentsOld.LastName!.Trim() != dependentNew.LastName!.Trim() || dependentsOld.FirstName!.Trim() != dependentNew.FirstName!.Trim() || (dependentsOld.MiddleInitial ?? "").Trim() != (dependentNew.MiddleInitial ?? "").Trim()) ||
            (dependentsOld.SocialSecurityNumber!.Trim() != (dependentNew.SocialSecurityNumber ?? "").Trim()) || (dependentsOld.BirthDate != dependentNew.BirthDate) || (dependentsOld.GenderDesc != dependentNew.GenderDesc) ||
            (dependentsOld.Relationship != dependentNew.Relationship) || (dependentsOld.Student != dependentNew.Student) || (dependentsOld.ParticipantStatus != dependentNew.ParticipantStatus || dependentsOld!.QualifiedBeneficiary != dependentNew!.QualifiedBeneficiary
            || (dependentsOld.EmployeeNumber ?? "").Trim() != (dependentNew.EmployeeNumber ?? "").Trim());
        }
        private async Task<OperationResultModel> NewDependentProcessQE(DependentProcessQEModel insertModel, string? preferredLanguage, ParticipantPromotedModel? participantPromoted, DatabaseFacade database)
        {
            string process = "DQ";
            OperationResultModel operationResultModel = new()
            {
                Success = true,
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {                
                if (insertModel != null)
                {
                    // Check if it is not promoted
                    if (participantPromoted == null)
                    {
                        int particiapntIdNew= await InsertDependentParticipantPQE(insertModel.ParticipantInfo!, insertModel.ClientId!, preferredLanguage, insertModel.CO709!.OptionValue!);
                        insertModel.ParticipantInfo!.ParticipantNewId = particiapntIdNew;
                        EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                        EventModel _event;
                        AddressModel address = GetAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                        await InsertAddress(address);
                        eventModel.UserId = insertModel.UserId;
                        //eventModel.CustomComment = GetCustomFromTakeOver(address, insertModel.Address!);
                        _event = GetEventModel(eventModel, "08");
                        await InsertEvent(_event);
                        // SpecificFields
                        await ProcessSpecificFields(insertModel.SpecificFields!, insertModel.UserType, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                        //Dependents
                        if (insertModel?.ParticipantInfo?.RelationShip == "S")
                        {
                            await InsertDependentProcesssQE(insertModel.Dependents, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId, insertModel.UserName!);
                        }
                        await ProcessQualifyingEvent(insertModel!, true, process);
                    }
                    else if (string.IsNullOrWhiteSpace(participantPromoted?.QualifyngEventType))
                    {
                        int primaryparticipantid = participantPromoted?.ParticipantId??0;
                        if (insertModel?.ParticipantInfo?.RelationShip == "S")
                        { 
                            await InsertDependentProcesssQE(insertModel.Dependents, primaryparticipantid, insertModel.UserId, insertModel.UserName!);
                         //   await InsertDependentProcesssQE(insertModel.Dependents, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId, userName);
                        }
                        await ProcessQualifyingEvent(insertModel!, true, process);
                    }
                    else
                    {
                        operationResultModel.Success = false;
                        operationResultModel.ResultDescription = $"Promoted Dependent Already in System. (Participant {participantPromoted?.ParticipantId??0})";
                        return operationResultModel;
                    }
                    await transaction.CommitAsync();
                    operationResultModel.ParticipantId = insertModel?.ParticipantInfo?.ParticipantNewId.ToString()!;
                    operationResultModel.ResultDescription = string.Format(ConstantValues.DEPENDENTPROCESSQESUCCESS, insertModel?.ParticipantInfo!.FirstName, insertModel?.ParticipantInfo!.LastName, insertModel?.ParticipantInfo!.ParticipantId);
                }                    
                return operationResultModel;
            }
            catch(Exception ex)
            {
                await transaction.RollbackAsync();
                string eror = ex.Message;
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.DEPENDENTPROCESSQEFAIL, insertModel.ParticipantInfo!.ParticipantId);
                return operationResultModel;
            }
        }
        private async Task ProcessQualifyingEvent(DependentProcessQEModel insertModel, bool coverage, string process)
        {
            string parteld = string.Empty;
            string partmed = string.Empty;
            string converageState = "Q";
            if (insertModel != null && insertModel.ProcessQE != null && insertModel.ParticipantInfo != null)
            {
                EventModel _event=new();
                if(insertModel.ProcessQE.QeReason!="20")
                { 
                    await UpdateParticipantPQE(insertModel.ProcessQE!, insertModel.ParticipantInfo.ParticipantNewId, coverage);
                    if(coverage)
                        await CalculateEligibilityEndDate(insertModel.ParticipantInfo.ParticipantNewId, insertModel.ProcessQE!.QeReason!, insertModel.ProcessQE!.LastDayPreCobraCoverage!);
                    if (!string.IsNullOrEmpty(parteld))
                    {
                        _event = GetEventQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, insertModel.EventTypeQE!);
                        await InsertEvent(_event);
                    }
                    else
                    { 
                        if (!string.IsNullOrEmpty(partmed))
                        {
                            _event = GetEventDPQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "A1");
                            await InsertEvent(_event);
                            _event = GetEventDPQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "A2");
                            await InsertEvent(_event);
                        }
                        else
                        {
                            if(process== "DQ")
                                _event = GetEventDPQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "07");
                          else
                            {
                                if (coverage)
                                    _event = GetEventDPQE(insertModel.ProcessQE!, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "05");
                               else
                                    _event = GetEventDPQE(insertModel.ProcessQE!, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "06");
                            }
                            await InsertEvent(_event);
                        }
                    }
                }
                else
                {
                    await UpdateParticipantPQE20(insertModel.ProcessQE!, insertModel.ParticipantInfo.ParticipantNewId, true);
                    if(coverage)
                        _event = GetEventDPQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "05");
                    else
                        _event = GetEventDPQE(insertModel.ProcessQE, insertModel.ParticipantInfo.ParticipantNewId, insertModel.AvailablePlans!.AvailablePlansClient!.Count, insertModel.UserId, "06");
                    await InsertEvent(_event);
                }

                if (insertModel.AvailablePlans != null && insertModel.AvailablePlans.AvailablePlansClient != null && insertModel.AvailablePlans.AvailablePlansClient.Count > 0)
                    await NewCoverage(insertModel, AvailablePlanTypeEnum.New, converageState);

                if (insertModel.AvailablePlans != null && insertModel.AvailablePlans.ExistingPlansClient != null && insertModel.AvailablePlans.ExistingPlansClient.Count > 0)
                    await NewCoverage(insertModel, AvailablePlanTypeEnum.Existing, converageState);

                if (insertModel.ProcessQE.QeReason != "20")
                    await CallCafePlan(insertModel);
                if (process == "DQ")
                    await CallPromoted(insertModel.ParticipantInfo.ParticipantNewId.ToString(), insertModel.ProcessQE!.LastDayPreCobraCoverage!);
            }
        }
        private async Task UpdateOldDependent(DependentNewViewModel dependent, string clientId)
        {
            InfoResultViewModel ParticipantInfo = new()
            {
                ParticipantId = dependent.ParticipantId.ToString(),
                FirstName = dependent.FirstName,
                LastName = dependent.LastName,
                MiddleInitial = dependent.MiddleInitial ?? "",
                SocialSecurityNumber = dependent.SocialSecurityNumber ?? "",
                BirthDate = dependent.BirthDate,
                ParticipantStatus = dependent.ParticipantStatus,
                Student = dependent.Student,
                RelationShip = dependent.Relationship,
                Gender = dependent.Gender,
                Eligible = dependent.QualifiedBeneficiary,
                EmployeeNumber = dependent.EmployeeNumber,
            };
            await UpdateParticipant(ParticipantInfo);
        }
        private async Task UpdateParticipant(InfoResultViewModel ParticipantInfo)
        {
            Query updateParticipant = ParticipantInserts.UpdateParticipant(ParticipantInfo!);
            await ExecuteGenericNoReturn(updateParticipant);
        }
        private static bool CheckAddressModification(InfoResultViewModel participantInfo, AddressModel address) 
        {
            return (participantInfo!.Address1.Trim() != address!.Address1.Trim()
                || (participantInfo!.Address2 != null ? participantInfo!.Address2?.Trim() : "") != (address.Address2 != null ? address.Address2?.Trim() : "")
                || (participantInfo!.Zip != null ? participantInfo!.Zip?.Trim() : "") != (address.Zip != null ? address.Zip?.Trim() : "")
                || (participantInfo!.City != null ? participantInfo!.City?.Trim() : "") != (address.City != null ? address.City?.Trim() : "")
                  || (participantInfo!.State != null ? participantInfo!.State?.Trim() : "") != (address.State != null ? address.State?.Trim() : "")
                );
        }
        private static string GetCustomFromTakeOver(AddressModel addressOld, AddressModel addressNew)
        {
          return  string.Format("'Participant Address changed from {0} {1},{2} {3} to  {4} {5},{6} {7} ",
                addressOld.Address1.Trim(), (addressOld.City != null ? addressOld.City?.Trim() : ""),
                (addressOld!.State != null ? addressOld.State?.Trim() : ""), (addressOld!.Zip != null ? addressOld!.Zip?.Trim() : ""),
                 addressNew!.Address1.Trim(), (addressNew!.City != null ? addressNew!.City?.Trim() : ""),
                (addressNew!.State != null ? addressNew!.State?.Trim() : ""), (addressNew!.Zip != null ? addressNew!.Zip?.Trim() : "")
                );
        }        
        private async Task UpdateParticipantQE(ProcessQEInfoModel processQE, int participantID)
        {
            Query updateParticipant = ParticipantInserts.UpdateParticipantQE(processQE, participantID);
            await ExecuteGenericNoReturn(updateParticipant);
        }
        private async Task UpdateParticipantPQE(ProcessQEInfoModel processQE, int participantID, bool coverages)
        {
            Query updateParticipant = ParticipantInserts.UpdateParticipantPQE(processQE, participantID, coverages);
            await ExecuteGenericNoReturn(updateParticipant);
        }
        private async Task UpdateParticipantPQE20(ProcessQEInfoModel processQE, int participantID, bool coverages)
        {
            Query updateParticipant = ParticipantInserts.UpdateParticipantPQE20(processQE, participantID, coverages);
            await ExecuteGenericNoReturn(updateParticipant);
        }
        private async Task<int> InsertDependentParticipantPQE( InfoResultViewModel participantInfo, string clientId, string? preferredLanguage, string CO709)
        {
            Query insertDependentParticipantPQE = ParticipantInserts.InsertDependentParticipantPQE( participantInfo, clientId, preferredLanguage, CO709);
            string participantId = await ExecuteGenericRowOutput(insertDependentParticipantPQE, "@Pid", insertDependentParticipantPQE.Parameters != null ? insertDependentParticipantPQE.Parameters.Count - 1 : 0);
            return int.Parse(participantId);
        }        
        private async Task CalculateEligibilityEndDate(int participantId, string qeType, string lDPCC2)
        {
            Query specific = ParticipantExecSP.CalculateEligibilityEndDate(participantId, qeType, lDPCC2);
            await ExecuteGenericNoReturn(specific);
        }
        private static EventModel GetEventQE(ProcessQEInfoModel processQE, int participantID, int count, string userId, string eventType = "")
        {
            if (eventType.Equals(string.Empty))
            {
                eventType = "SZ";
                if (processQE.QeReason != "50" && processQE.QeReason != "C1")
                    eventType = "03";
            }

            string comment = eventType switch
            {
                "A4" => string.Concat(string.Format("Qualifying Event and Takeover Processed: {0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "03" => string.Concat(string.Format("Qualifying Event and Takeover Processed: {0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "A2" => string.Concat(string.Format("Qualifying Event and Takeover Processed: {0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "05" => string.Concat(string.Format("Qualifying Event for Non-Plan Participant QEDate: {0} ", processQE.QeReason)),
                "06" => string.Concat(string.Format("Qualifying Event Processed: {0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "SZ" => string.Concat(string.Format("Qualifying Event and Takeover Processed: {0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                _ => "",
            };

            EventModel eventModel = new()
            {
                ParticipantId = participantID,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private static EventModel GetEventDPQE(ProcessQEInfoModel processQE, int participantID, int count, string userId, string eventType)
        {
            string comment = eventType switch
            {
                "A2" => string.Concat(string.Format("Qualifying Event for Waiting Period Participant:{0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReason, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "A1" => string.Concat(string.Format("Election Notice Reported To Be Previously Mailed on:{0}", processQE.QeReason)),
                "06" => string.Concat(string.Format("Qualifying Event for Non-Plan Participant as of : {0} ", processQE.QEEventDate)),
                "05" => string.Concat(string.Format("Qualifying Event Processed:{0} on {1} from {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                "07" => string.Concat(string.Format("Qualifying Event Processed:{0} on {1} Eligibility {2} through {3} covered on {4} plan(s)", processQE.QeReasonDescription, processQE.QEEventDate, processQE.EligibilityStart, processQE.EligiibilityEndDate, count)),
                _ => "",
            };

            EventModel eventModel = new()
            {
                ParticipantId = participantID,
                EventType = eventType,
                EventSource = "WEB",
                Comment = comment,
                UserId = userId,
            };
            return eventModel;
        }
        private async Task NewCoverage(InfoSessionModel insertModel, AvailablePlanTypeEnum availablePlanType, string converageState)
        {
            List<DependentNewViewModel>? newDependents = insertModel.Dependents?.Where(dep => dep.ParticipantId == null && dep.QualifiedBeneficiary == "Y").ToList();
            string plsXml = string.Empty;
            string xml = string.Empty;
            string planType = string.Empty;
            bool planSubsidiy = false;
            string datePolicy = "";
            if (insertModel.AvailablePlans!.IsSubsidy)
                plsXml = string.Concat(plsXml, string.Format("'<SubsidyData ParticipantId=\"{0}\" ConcurrencyToken=\"{1}\">", insertModel.ParticipantInfo!.ParticipantNewId, "23"));
            List<AvailablePlansClientResultModel> availablePlansClient = new();

            if (availablePlanType == AvailablePlanTypeEnum.New)
                availablePlansClient = insertModel.AvailablePlans!.AvailablePlansClient!;

            if (availablePlanType == AvailablePlanTypeEnum.Existing)
                availablePlansClient = insertModel.AvailablePlans!.ExistingPlansClient!;

            foreach (AvailablePlansClientResultModel plans in availablePlansClient)
            {
                string fixedPremiun = string.Empty;
                if (plans.CoverageMember != null && plans.CoverageMember.Count > 0)
                {
                    foreach (CoverageMemberModel cm in plans.CoverageMember)
                    {
                        if (!string.IsNullOrEmpty(cm.FixedPremiun))
                            fixedPremiun = cm.FixedPremiun;
                    }
                }
                // Query coverage = ParticipantInserts.InsertCoverage(insertModel.ParticipantInfo!.ParticipantId!, plans, fixedPremiun, insertModel.ProcessQE!.BillingStartDate!);
                if (availablePlanType == AvailablePlanTypeEnum.New)
                {
                    string billingDate = insertModel.ProcessQE!.BillingStartDate!;
                    if (converageState == "Q")
                        billingDate = plans.CoverageBeginDate ?? "";
                    Query coverage = ParticipantInserts.InsertCoverage(insertModel.ParticipantInfo!.ParticipantNewId!.ToString(), plans, fixedPremiun, billingDate, converageState, insertModel.ProcessQE!.LastDayPreCobraCoverage!);
                    int coverageId = await InsertCoverage(coverage);
                    plans.Pcid = coverageId;
                }
                else
                {
                    if(insertModel.ProcessQE!.QeReason == "20")
                    {
                        Query coverage = ParticipantInserts.UpdateCoverage( plans, fixedPremiun, insertModel.ProcessQE!.BillingStartDate!, insertModel.ProcessQE!.LastDayPreCobraCoverage! );
                        await ExecuteGenericNoReturn(coverage);
                    }
                }
                ////RUN if Coverage rate Type is MR
                if (plans.RateType.Equals("MR"))
                {
                    string xmlMR = await InsertCoverageDependent(plans, insertModel.ProcessQE!.BillingStartDate! ?? insertModel.ProcessQE!.LastDayPreCobraCoverage!);
                    await InsertCoverageMR(xmlMR);
                }
                //     if (plans.RateType.Equals("RT") && plans.IsLifeInsuranceRTPlan!.Equals("1") && plans.CoverageType.Equals("F"))
                if ((plans.RateType.Equals("RT")|| plans.RateType.Equals("IR") || plans.RateType.Equals("ST") || plans.RateType.Equals("MI")) && plans.CoverageType.Equals("F"))
                {
                    datePolicy = insertModel.ProcessQE!.BillingStartDate!;
                    if (converageState == "Q")
                        datePolicy = plans.CoverageBeginDate ?? "";
                    await NewCoverageSL(plans, newDependents, datePolicy);
                }
                if (plans.SubsidyPlan != null && plans.SubsidyPlan.Count > 0)
                {
                    xml = await NewCoveragePLS(insertModel, plans);
                    plsXml = string.Concat(plsXml, xml);
                    planSubsidiy = true;
                }
            }
            if (planSubsidiy && insertModel.AvailablePlans!.IsSubsidy)
            {
                plsXml = string.Concat(plsXml, "</SubsidyData>'");
                await InsertCoveragePLS(insertModel.PlatformName, plsXml, insertModel.UserId);
            }
        }
        private async Task CallCafePlan(DependentProcessQEModel insertModel)
        {
            foreach (AvailablePlansClientResultModel plans in insertModel.AvailablePlans!.AvailablePlansClient!)
            {
                if (plans.IsCafePlan)
                {
                    Query eventCoverage = ParticipantExecSP.InsertCafePlan(insertModel.ParticipantInfo!.ParticipantNewId.ToString(), insertModel.ClientId!, plans.PlanId, insertModel.ProcessQE!.QEEventDate ?? "", insertModel.UserId!);
                    int outputParameter=8;
                    string eventDetail = await ExecuteGenericRowOutput(eventCoverage, "@ErrorCount", outputParameter);
                    if (eventDetail != "0")
                        throw new Exception("Error processing Events from Coverage");
                }
            }
        }
        private async Task CallPromoted(string participantId , string ldpcc)
        {
            Query eventCoverage = ParticipantExecSP.MLRPromoted(participantId, ldpcc);
            await ExecuteGenericNoReturn(eventCoverage);
        }
        private async Task<int> InsertCoverage(Query coverage)
        {
            string coverageId = await ExecuteGenericRowOutput(coverage, "@Pid", coverage.Parameters != null ? coverage.Parameters.Count - 1 : 0);
            return int.Parse(coverageId);
        }
        private async Task InsertEventCoverage(InfoSessionModel insertModel)
        {
            Query eventCoverage = ParticipantExecSP.InsertEventCoverage(insertModel);
            int outputParameter;
            if (string.IsNullOrEmpty(insertModel.ProcessQE!.BillingStartDate))
                outputParameter = 3;
            else
                outputParameter = 6;

            string eventDetail = await ExecuteGenericRowOutput(eventCoverage, "@ErrorCount", outputParameter);
            if (eventDetail != "0")
                throw new Exception("Error processing Events from Coverage");
        }
        private async Task InsertDependentConveraege(int participantId)
        {
            Query eventCoverage = ParticipantExecSP.InsertDependentCoverage(participantId);
            await ExecuteGenericNoReturn(eventCoverage);
        }
        private async Task NewCoverageSL(AvailablePlansClientResultModel plans, List<DependentNewViewModel>? newDependents, string billingStartDate)
        {
            if (plans.CoverageMember != null && plans.CoverageMember?.Count > 0)
            {
                int i = 0;
                int parentParticipant = 0;
                foreach (CoverageMemberModel cm in plans.CoverageMember)
                {
                    if(cm.ParticipantCoverageId=="1")
                    {
                            if (!string.IsNullOrEmpty(cm.Amount))
                            {
                                if (cm.ParticipantId.ToString()!.Length < 3)
                                {
                                    cm.ParticipantId = newDependents![i].ParticipantNewId;
                                    i++;
                                }
                            }
                            Query coverage = ParticipantExecSP.InsertPolicy(cm, plans.Pcid.ToString()!, billingStartDate);
                            await ExecuteGenericNoReturn(coverage);
                            Query participantCoverageId = ParticipantInserts.ValidateExistCoverage(cm.ParticipantId!.ToString() ?? "", plans!.Pcid.ToString());
                            await ExecuteGenericNoReturn(participantCoverageId);
                    }
                    parentParticipant++;
                }
            }
        }
        private async Task<string> NewCoveragePLS(InfoSessionModel insertModel, AvailablePlansClientResultModel plans)
        {
            string xml = string.Empty;
            if (plans.SubsidyPlan != null && plans.SubsidyPlan.Count > 0)
            {
                int pos = 1;
                foreach (SubsidyPlanModel subsidy in plans.SubsidyPlan)
                {
                    if (plans.CoverageType == "A")
                    {
                        List<PlanBenefitTypeModel>? lstPlanBenefit = await _planBenefit.GetBenefitForPlanId(insertModel.PlatformName, plans.PlanId.ToString());
                        if (lstPlanBenefit != null && lstPlanBenefit.Count > 0)
                        {
                            foreach (PlanBenefitTypeModel benefit in lstPlanBenefit)
                            {
                                xml = string.Concat(xml, string.Format("<BenefitSubsidy BenefitTypeSubtypeId=\"{0}\">", benefit.BenefitTypeSubtypeId));
                                xml = string.Concat(xml, "<SubsidyPeriods>");
                                xml = string.Concat(xml, string.Format("<SubsidyPeriod StartDate=\"{0}\" EndDate=\"{1}\" AmountTypeId=\"{2}\" Amount=\"{3}\" EmployerPaysAdminFee=\"{4}\">", subsidy.StartDate, subsidy.EndDate, subsidy.Type, subsidy.Monthly, (subsidy.PaysAdminFee ? "1" : "0")));
                                xml = string.Concat(xml, string.Format("<IsEmployerPaysAdminFee>\"{0}\"</IsEmployerPaysAdminFee>", (subsidy.PaysAdminFee ? "true" : "false")));
                                xml = string.Concat(xml, string.Format("<UniqueId>\"{0}\"</UniqueId>", pos));
                                xml = string.Concat(xml, "</SubsidyPeriod></SubsidyPeriods></BenefitSubsidy>");
                            }
                        }
                    }
                    else
                    {
                        xml = string.Concat(xml, string.Format("<BenefitSubsidy BenefitTypeSubtypeId=\"{0}\">", plans.QEPlanComponentModel!.BenType));
                        xml = string.Concat(xml, "<SubsidyPeriods>");
                        xml = string.Concat(xml, string.Format("<SubsidyPeriod StartDate=\"{0}\" EndDate=\"{1}\" AmountTypeId=\"{2}\" Amount=\"{3}\" EmployerPaysAdminFee=\"{4}\">", subsidy.StartDate, subsidy.EndDate, subsidy.Type, subsidy.Monthly, (subsidy.PaysAdminFee ? "1" : "0")));
                        xml = string.Concat(xml, string.Format("<IsEmployerPaysAdminFee>\"{0}\"</IsEmployerPaysAdminFee>", (subsidy.PaysAdminFee ? "true" : "false")));
                        xml = string.Concat(xml, string.Format("<UniqueId>\"{0}\"</UniqueId>", pos));
                        xml = string.Concat(xml, "</SubsidyPeriod></SubsidyPeriods></BenefitSubsidy>");
                    }
                    pos += 1;
                }
            }
            return xml;
        }
        private async Task InsertCoveragePLS(string platformName, string xml, string userId)
        {
            SubsidyDataModel? pls = await _subsidyData.ExecuteCoveragePLS(platformName, xml, userId);
            if (pls == null || pls.ErrorCode != 0)
                throw new Exception("An error has occurred in processing subsidy.  Please contact your Relationship Manager.");
        }
        private async Task<string> InsertCoverageDependent(AvailablePlansClientResultModel plans, string billingStartDate)
        {
            string xml = "'<Selections>";
            xml = string.Concat(xml, string.Format("<Coverage Id='{0}'>", plans.Pcid.ToString()!.Trim()));
            foreach (CoverageMemberModel cov in plans.CoverageMember!)
            {
                if (cov.ParticipantCoverageId == "1")
                {
                    Query eventCoverage = ParticipantInserts.InsertCoverageDependent(cov, plans.Pcid.ToString()!, billingStartDate);
                    await ExecuteGenericNoReturn(eventCoverage);
                    xml = string.Concat(xml, string.Format ("<Participant Id='{0}' CCSId='{1}' />", cov.ParticipantId!.ToString(), "100"));
                }
            }
            xml = string.Concat(xml, "</Coverage></Selections>");
            return xml;
        }
        private async Task UpdateMedicalDent(string participantId, string clientId, string status)
        {
            Query query = ParticipantExecSP.UpdateMedicalDent(participantId, clientId, status);
            await ExecuteGenericNoReturn(query);
        }
        private async Task InsertCoverageMR(string xml)
        {
            Query specific = ParticipantExecSP.InsertCoverageMR(xml);
            await ExecuteGenericNoReturn(specific);
        }
        private async Task<OperationResultModel> SaveUpdateGroup(UpdateModel insertModel, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,                
                ResultDescription = string.Format(ConstantValues.UPDATEGROUPSUCCESS, insertModel.GroupUpdateResult!.Count, insertModel.GroupUpdateResult!.Count > 1 ? "s" : "", insertModel.GroupUpdateResult!.Count > 1 ? "s." : ".")
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                if (insertModel.GroupUpdateResult != null && insertModel.GroupUpdateResult.Count > 0)
                {
                    foreach (var updateChange in insertModel.GroupUpdateResult)
                    {
                        var oldData = insertModel.OptionToShow switch
                        {
                            "1" => updateChange.Student!.ToString() ?? "",
                            "2" => updateChange.KeyEmployee.ToString() ?? "",
                            "3" => updateChange.ShareHolder5.ToString() ?? "",
                            "4" => updateChange.HighlyCompPop.ToString() ?? "",
                            "5" => updateChange.HighlyCompMFSA.ToString() ?? "",
                            "6" => updateChange.SalaryUnder25K.ToString() ?? "",
                            "7" => updateChange.AffiliateId.ToString() ?? "",
                            "8" => updateChange.HireDate.ToString() ?? "",
                            "9" => updateChange.QualifiedBeneficiary!.ToString() ?? "",
                            "10" => updateChange.EmployeeNumber!.ToString() ?? "",
                            "11" => updateChange.PhoneNumber!.ToString() ?? "",
                            _ => updateChange.PayScheduleId.ToString() ?? ""
                        };
                        Query groupUpdate = ParticipantInserts.UpdateGroupUpdate(updateChange.ParticipantId, insertModel.GroupUpdate, updateChange.UpdateNew!);
                        await ExecuteGenericNoReturn(groupUpdate);
                        EventModel eventModel = new()
                        {
                            ParticipantId = Convert.ToInt32(updateChange.ParticipantId),
                            EventType = "02",
                            EventSource = "WEB",
                            Comment = string.Concat(string.Format("{0} updated from {1} to {2}", insertModel.GroupUpdate.Title, oldData, updateChange.UpdateNew!)),
                            UserId = insertModel.UserId,
                        };
                        await InsertEvent(eventModel);
                    }
                }
                await transaction.CommitAsync();
                return operationResultModel;
            }
            catch
            {
                await transaction.RollbackAsync();
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.UPDATEGROUPFAIL, insertModel.GroupUpdateResult!.Count > 1 ? "s." : ".");
                return operationResultModel;
            }
        }
        private async Task<OperationResultModel> Update(InfoSaveUpdateModel insertModel, DatabaseFacade database)
        {
            bool isUpdated =false;
            OperationResultModel operationResultModel = new()
            {
                Success = true,
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                //Update Participant and Save event
                InfoResultViewModel infoOld = insertModel.ParticipantInfoOld!;
                InfoResultViewModel infoNew = insertModel.ParticipantInfo!;

                await UpdateParticipant(insertModel.ParticipantInfo!);
                insertModel.ParticipantInfo!.ParticipantNewId = int.Parse(insertModel.ParticipantInfo.ParticipantId!);
                EventParameterModel eventModel = ConvertToAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                EventModel _event;

                if (infoOld.QualifiedBeneficiary != infoNew.QualifiedBeneficiary)
                    await UpdateMedicalDent(insertModel.ParticipantInfo!.ParticipantId!, insertModel.ClientId, infoNew.QualifiedBeneficiary);
                
                await SaveEventParticipant(infoOld, infoNew, insertModel.UserId);
             
                //Save Addres, but first check if some data has changed
                if (CheckAddressModification(insertModel.ParticipantInfo, insertModel.Address!))
                {
                    AddressModel address = GetAddressModel(insertModel.ParticipantInfo, insertModel.UserId);
                    await InsertAddress(address);
                    eventModel.CustomComment = GetCustomFromTakeOver(address, insertModel.Address!);
                    _event = GetEventModel(eventModel, "79");
                    await InsertEvent(_event);

                    //Send Email
                    await CreatePrintEvents(insertModel.ParticipantInfo!.ParticipantNewId.ToString(), insertModel.UserId, insertModel.Documents!);
                }
                //SpecificFields
                await ProcessSpecificFields(insertModel.SpecificFields!, insertModel.UserType, insertModel.ParticipantInfo.ParticipantNewId, insertModel.UserId);
               
                if (insertModel.Dependents != null)
                {
                    List<DependentNewViewModel>? Dependents;
                    Dependents = insertModel.Dependents.Where(dep => dep.ParticipantId > 0).ToList();
                    if (Dependents.Any())
                    {
                        // await UpdateOldDependent(Dependents, insertModel.ClientId);
                        foreach (DependentNewViewModel dependentNew in Dependents)
                        {
                            DependentNewViewModel? DependentsOld = insertModel.DependentsOld?.Where(dep => dep.ParticipantId == dependentNew.ParticipantId).FirstOrDefault();
                            if (DependentsOld != null)
                            {
                                isUpdated = ValidateDependentOldModified(DependentsOld, dependentNew);
                                if (isUpdated)
                                {
                                    await UpdateOldDependent(dependentNew, insertModel.ClientId);
                                    await DependentOldModified(DependentsOld, dependentNew, insertModel.UserId, insertModel.ParticipantInfo.ParticipantNewId);
                                }
                                await MedicalDental(DependentsOld, dependentNew, insertModel.UserId, (dependentNew.ParticipantId ?? 0).ToString(), insertModel.ClientId);
                            }
                        }
                    }
                    await ProcessNewDependents(insertModel.Dependents, insertModel!.ParticipantInfo.ParticipantNewId, insertModel.UserId);
                }
                await transaction.CommitAsync();
                //   await transaction.RollbackAsync();
                operationResultModel.ParticipantId = insertModel.ParticipantInfo.ParticipantNewId.ToString();
                return operationResultModel;
            }
            catch(Exception ex)
            {
                await transaction.RollbackAsync();
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.UPDATEFAIL, insertModel.ParticipantInfo!.ParticipantId);
                _logger.LogError("Failed to peform Update: {ex}", ex);
                return operationResultModel;
            }
        }
        private async Task SaveEventParticipant(InfoResultViewModel infoOld, InfoResultViewModel infoNew, string userId)
        {
            EventModel _event;
            if (infoOld.LastName!.Trim() != infoNew.LastName!.Trim() || infoOld.FirstName!.Trim() != infoNew.FirstName!.Trim() || (infoOld.MiddleInitial ?? "").Trim() != infoNew.MiddleInitial!.Trim())
            {
                _event = GetEventModelByField(infoOld, infoNew, "Names", userId);
                await InsertEvent(_event);
            }
            if (infoOld.EmailAddress!.Trim() != (infoNew.EmailAddress ?? "").Trim())
            {
                _event = GetEventModelByField(infoOld, infoNew, "Email", userId);
                await InsertEvent(_event);
            }
            if ((infoOld.PhoneNumber!.Trim() ?? "") != (infoNew.PhoneNumber! ?? "").Trim())
            {
                _event = GetEventModelByField(infoOld, infoNew, "Phone", userId);
                await InsertEvent(_event);
            }
            if (infoOld.AffiliateName != infoNew.AffiliateName)
            {
                _event = GetEventModelByField(infoOld, infoNew, "Location", userId);
                await InsertEvent(_event);
            }
            if (infoOld.EmployeeNumber != infoNew.EmployeeNumber)
            {
                _event = GetEventModelByField(infoOld, infoNew, "Number", userId);
                await InsertEvent(_event);
            }
            if (infoOld.BirthDate != infoNew.BirthDate)
            {
                _event = GetEventModelByField(infoOld, infoNew, "Birth", userId);
                await InsertEvent(_event);
            }
            if (infoOld.ClassName != infoNew.ClassName)
            {
                _event = GetEventModelByField(infoOld, infoNew, "Class", userId);
                await InsertEvent(_event);
            }
            if (infoOld.QualifiedBeneficiary != infoNew.QualifiedBeneficiary)
            {
                _event = GetEventModelByField(infoOld, infoNew, "QualifiedBeneficiary", userId);
                await InsertEvent(_event);
            }
        }
        private async Task CreatePrintEvents(string participantId, string userId, List<DocumentOptionModel>? documents)
        {
            if (documents == null)
                return;
            foreach(DocumentOptionModel document in documents)
            {
                QueueAchModel queueAchModel = new()
                {
                    ParticipantId = participantId,
                    UserId = userId,
                    EventType = document.EventType,
                    EventDate = DateTime.Now.ToString(),
                    FormNumber = document.FormNumber,
                    EventSource = "WEB",
                    DueDate = DateTime.Now.AddDays(1).ToString(),
                    CouponStartDate= document.CouponStartDate??"",
                    OptionValue = document.OptionValue,
                };
                Query rehireEvent = ParticipantExecSP.CreatePrintEvents(queueAchModel);
                _ = await ExecuteGenericRowOutput(rehireEvent, "@ErrorCount", rehireEvent.Parameters!.Count-1);
            }
        }
        private static EventParameterModel ConvertToCoverageEvent(int participantId, string planName)
        {
            EventParameterModel eventModel = new()
            {
                ParticipantId = participantId,
                PlanName = planName
            };
            return eventModel;
        }
        private async Task<OperationResultModel> CoverageAcceptable(CoverageAcceptable model, DatabaseFacade database)
        {
            OperationResultModel operationResultModel = new()
            {
                Success = true,
            };
            using var transaction = await database.BeginTransactionAsync();
            try
            {
                EventParameterModel eventModel = ConvertToCoverageEvent(int.Parse(model.ParticipantId), model.PlanName);
                EventModel _event = GetEventModel(eventModel, "DP");
                await InsertEvent(_event);
              
                await transaction.CommitAsync();
                return operationResultModel;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                operationResultModel.Success = false;
                operationResultModel.ResultDescription = string.Format(ConstantValues.COVERAGEFAIL, model.ParticipantId);
                _logger.LogError("Failed to peform Update: {ex}", ex);
                return operationResultModel;
            }
        }
    }
}

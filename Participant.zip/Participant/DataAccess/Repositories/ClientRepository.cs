﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.EmployerChange;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class ClientRepository : GenericRepository<ClientModel>, IClientRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;

        public ClientRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<ClientModel>?> SearchClientforEmployerChange(InfoModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));
            Query clientList = Select.GetClientsList(model.UserId, model.ClientId);
            List<ClientModel>? lstSearch = await ExecuteGeneric(clientList);
            return lstSearch;
        }
    }
}

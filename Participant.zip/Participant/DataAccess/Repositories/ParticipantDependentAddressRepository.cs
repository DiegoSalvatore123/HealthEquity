﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    internal class ParticipantDependentAddressRepository : GenericRepository<CurrentParticipantAddressModel>, IParticipantDependentAddressRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public ParticipantDependentAddressRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<CurrentParticipantAddressResultModel?> GetParticipantDependentAddress(InfoModel participantDependent)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participantDependent.PlatformName));
            Query query = ParticipantSelect.GetDependentAddress(participantDependent.ParticipantId);
            CurrentParticipantAddressModel? search = await ExecuteGenericRow(query);
            CurrentParticipantAddressResultModel dependentResult = new()
            {
                CurrentParticipantAddressModel = search,
            };

            var states = new StateRepository(_db, _cobraConfig);
            dependentResult.States = await states.GetStates(participantDependent);

            return dependentResult;
        }
    }
}

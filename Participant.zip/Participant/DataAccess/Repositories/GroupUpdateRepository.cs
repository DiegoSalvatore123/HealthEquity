﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.GroupUpdate;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class GroupUpdateRepository: GenericRepository<GroupUpdateModel>, IGroupUpdateRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public GroupUpdateRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }
    public async Task<GroupUpdateModel?> GetByIdNumber(string idNumber, string platformName)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

        Query groupUpdateQuery = Select.GetByIdNumber(idNumber);
        GroupUpdateModel? groupUpdateResult = await ExecuteGenericRow(groupUpdateQuery);
        return groupUpdateResult;
    }
}
﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class PaymentHistoryRepository : GenericRepository<PaymentHistoryModel>, IPaymentHistory
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public PaymentHistoryRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<PaymentHistoryModel>?> GetPaymentHistoryByPid(ParticipantIdModel participant)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            Query query = ParticipantSelect.GetPaymentHistoryByPid(participant);
            List<PaymentHistoryModel>? lstSearch = await ExecuteGeneric(query);
            return lstSearch;
        }
    }
}

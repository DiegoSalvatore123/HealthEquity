﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.GroupUpdate;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;
public class GroupUpdateDropDownListRepository : GenericRepository<GroupUpdateDropDownListModel>, IGroupUpdateDropDownListRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public GroupUpdateDropDownListRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }
    public async Task<List<GroupUpdateDropDownListModel>?> GetBoolean(string tableName, string colName, string platformName)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

        Query ddlQuery = DropDownList.GetBoolean(tableName,colName);
        var ddlResult = await ExecuteGeneric(ddlQuery);
        return ddlResult;
    }
    public async Task<List<GroupUpdateDropDownListModel>?> GetAffiliate(string clientId, string divisionLevelAccess, string affiliateString, string platformName)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

        Query ddlQuery = DropDownList.GetAffiliate(clientId,divisionLevelAccess,affiliateString);
        var ddlResult = await ExecuteGeneric(ddlQuery);
        return ddlResult;
    }
    public async Task<List<GroupUpdateDropDownListModel>?> GetSchedule(string clientId, string platformName)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));

        Query ddlQuery = DropDownList.GetSchedule(clientId);
        var ddlResult = await ExecuteGeneric(ddlQuery);
        return ddlResult;
    }
}
﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class AdminFeeRepository : GenericRepository<AdminFeeModel>, IAdminFeeRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public AdminFeeRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }

    public async Task<List<AdminFeeModel>?> GetAdminFee(string platformName, string clientId)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(platformName));
        Query adminFeeQuery = AdminFee.GetAdminFee(clientId);
        List<AdminFeeModel>? adminFeeModel = await ExecuteGeneric(adminFeeQuery);
        return adminFeeModel;
    }
}
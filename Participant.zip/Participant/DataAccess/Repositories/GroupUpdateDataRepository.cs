﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.GroupUpdate;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories;

public class GroupUpdateDataRepository : GenericRepository<GroupUpdateDataResultModel>, IGroupUpdateDataRepository
{
    private readonly CobraDbContext _db;
    private readonly ICobraConfig _cobraConfig;
    public GroupUpdateDataRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
    {
        _db = db;
        _cobraConfig = cobraConfig;
    }
    public async Task<List<GroupUpdateDataResultModel>> GetData(GroupUpdateModel groupUpdateModel, GroupUpdateSearchModel groupUpdateDataModel)
    {
        var database = _db.Database;
        database.SetConnectionString(await _cobraConfig.GetCLProd(groupUpdateDataModel.PlatformName));

        Query groupUpdateQuery =  Select.GetData(groupUpdateModel, groupUpdateDataModel);
        List<GroupUpdateDataResultModel>? groupUpdateResult = await ExecuteGeneric(groupUpdateQuery);
        return groupUpdateResult!;
    }
}
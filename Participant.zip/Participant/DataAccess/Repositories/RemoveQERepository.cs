﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class RemoveQERepository : GenericRepository<RemoveQEInfoModel>, IRemoveQERepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public RemoveQERepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<OperationResultModel?> RemoveQE(RemoveQEModel removeQEModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(removeQEModel.PlatformName));
            Query removeQEInfo = ParticipantSelect.RemoveQEInfo(removeQEModel.ParticipantId);
            RemoveQEInfoModel? removeQEInfoModel = await ExecuteGenericRow(removeQEInfo);
            OperationResultModel? removeQEResultModel = new();
            if(removeQEInfoModel != null)
            {
                removeQEResultModel.Success = removeQEInfoModel.Success;
                removeQEResultModel.ResultDescription = removeQEInfoModel.ResultDescription;
                if (removeQEInfoModel.Success)
                {
                    Query removeQE = ParticipantSelect.RemoveQE(removeQEModel);
                    string errorCountremoveQE = await ExecuteGenericRowOutput(removeQE, "@Result", 3);
                    if (errorCountremoveQE == "0")
                    {
                        removeQEResultModel.Success = true;
                        removeQEResultModel.ResultDescription = "SUCCESS: removed qualifying event for " + removeQEInfoModel.FirstName + " " + removeQEInfoModel.LastName +
                                                                " (Participant " + removeQEModel.ParticipantId + "). Please notify the appropriate carrier(s) of any loss of coverage.";
                    }
                    else
                    {
                        removeQEResultModel.Success = false;
                        removeQEResultModel.ResultDescription = "There was an error removing the qualifying event (Participant " + removeQEModel.ParticipantId  + "). Please try again later.";
                    }
                }
            }
            return removeQEResultModel;
        }
    }
}

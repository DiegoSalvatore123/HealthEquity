﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class BillingRepository : GenericRepository<BillingModel>, IBillingDetailRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public BillingRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<BillingDetailModel> GetBillingDetail(ParticipantIdModel participant)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(participant.PlatformName));
            BillingDetailModel billingModel = new();
            Query participantGetByID = ParticipantExecSP.GetBillingDetail(participant.ParticipantId);

            string billDetail =await ExecuteGenericRowOutput(participantGetByID, "@ErrorCount", 1);
            billingModel.ErrorCount = int.Parse(billDetail);
            if (billDetail == "0")
            {
                participantGetByID = ParticipantSelect.GetBilling(participant);
                List<BillingModel>? lstBilling = await ExecuteGeneric(participantGetByID);
                billingModel.Billing = lstBilling;
            }
            return billingModel;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class DocumentRepository : GenericRepository<DocumentResultModel>, IDocumentRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DocumentRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<DocumentResultModel?> GetDocument(DocumentModel documentModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(documentModel.PlatformName));
            Query query = ParticipantSelect.GetFile(documentModel);
            DocumentResultModel? documentResultModel = await ExecuteGenericRow(query);
            return documentResultModel;
        }
    }
}

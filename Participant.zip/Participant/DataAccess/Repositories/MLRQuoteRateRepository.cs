﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries.CoverageChange;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class MLRQuoteRateRepository : GenericRepository<MLRQuoteGetRateModel>, IMLRQuoteRateRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public MLRQuoteRateRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<List<MlrRate>?> GetMLRQuoteGetRates(string PlatformName, List<AvailablePlansClientResultModel>? AvailablePlans, string participantId, string planData, [Optional] string platformConection)
        {
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(PlatformName));
            else
                database.SetConnectionString(platformConection);
            Query mlrQuote = SelectCoverage.GetMLRQuoteGetRates(participantId, planData);
            List<MLRQuoteGetRateModel>? quotes = await ExecuteGeneric(mlrQuote);
            List<MlrRate>? mlrRates = new();
            bool tobacco=false;
            if(quotes!=null)
            {
                foreach(MLRQuoteGetRateModel quote in quotes)
                {
                    AvailablePlansClientResultModel? plan = AvailablePlans?.FirstOrDefault(x => x.PlanId == quote.PlanId);
                    if(plan!=null)
                    {
                        int tobaco= plan.CoverageMember!.Where(x => x.ParticipantId == quote.MemberId && x.TobaccoUse=="1").Count();
                        if(tobaco>0 && quote.SmokerCCSId>0)
                        {
                            tobacco = true;
                            MlrRate rate = new()
                            {
                                Id = quote.PlanId + "-" + participantId,
                                Value = quote.SmokerRate.ToString() + "-" + quote.SmokerCCSId.ToString()
                            };
                        }
                    }

                    if (quote.NonSmokerCCSId!=0 && !tobacco)
                    {
                        MlrRate rate = new()
                        {
                            Id = quote.PlanId + "-" + participantId,
                            Value=quote.NonSmokerRate.ToString() + "-" + quote.NonSmokerCCSId.ToString()
                        };
                        mlrRates.Add(rate);
                    }
                }
            }
            return mlrRates;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace DataAccess.Repositories
{
    public class InfoRepository : GenericRepository<InfoResultModel>, IInfoRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public InfoRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<InfoResultModel?> SearchByPid(InfoModel searchModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            Query participantGetByID = ParticipantSelect.SearchByPid(searchModel);
            InfoResultModel? participant = await ExecuteGenericRow(participantGetByID);
            return participant;
        }
        public async Task<InfoUpdateModel?> SearchInfoComponent(InfoModel searchModel, [Optional] string platformConection)
        { 
            var database = _db.Database;
            if (string.IsNullOrEmpty(platformConection))
                database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            else
                database.SetConnectionString(platformConection);
            InfoResultModel? participant = new();
            if (!string.IsNullOrEmpty(searchModel.ParticipantId))
            {
                Query participantGetByID = ParticipantSelect.SearchByPid(searchModel);
                participant = await ExecuteGenericRow(participantGetByID);

                if(participant == null && !string.IsNullOrWhiteSpace(searchModel.ParticipantId) && !string.IsNullOrWhiteSpace(searchModel.ClientId))
                {
                    Query participantGetDependentInfo = ParticipantSelect.GetDependentInfo(searchModel.ParticipantId, searchModel.ClientId);
                    participant = await ExecuteGenericRow(participantGetDependentInfo);
                }
            }
            InfoUpdateModel participantToUpdate = new()
            {
                ParticipantInfo = participant
            };

            return participantToUpdate;
        }
        public async Task<PastDueCancellationModel?> SearchInfoToCancel(PastDueInfoModel searchModel)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(searchModel.PlatformName));
            InfoResultModel? participant = new();
            if (!string.IsNullOrEmpty(searchModel.ParticipantId))
            {
                Query participantGetByID = ParticipantSelect.SearchByPid(searchModel);
                participant = await ExecuteGenericRow(participantGetByID);

                if (participant == null && !string.IsNullOrWhiteSpace(searchModel.ParticipantId) && !string.IsNullOrWhiteSpace(searchModel.ClientId))
                {
                    Query participantGetDependentInfo = ParticipantSelect.GetDependentInfo(searchModel.ParticipantId, searchModel.ClientId);
                    participant = await ExecuteGenericRow(participantGetDependentInfo);
                }
            }
            InfoUpdateModel participantToUpdate = new()
            {
                ParticipantInfo = participant
            };
            PastDueCancellationModel participantToCancel = new()
            {
                InfoResult = participantToUpdate
            };

            var participantId = new ParticipantIdModel
            {
                ParticipantId = searchModel.ParticipantId,
                PlatformName = searchModel.PlatformName,
            };

            var specificFields = new SpecificFieldsRepository(_db, _cobraConfig);
            if (string.IsNullOrEmpty(searchModel.ParticipantId))
            {
                var clientId = new UserClientModel
                {
                    ClientId = searchModel.ClientId,
                    PlatformName = searchModel.PlatformName,
                };
                participantToCancel.InfoResult.ParticipantSpecificFields = await specificFields.GetSpecificFieldsByClientid(clientId);
            }
            else
                participantToCancel.InfoResult.ParticipantSpecificFields = await specificFields.GetSpecificFieldsByPid(participantId);
            if (participantToCancel.InfoResult.ParticipantSpecificFields != null && participantToCancel.InfoResult.ParticipantSpecificFields.Count > 0)
            {
                foreach (SpecificFieldsResultModel model in participantToCancel.InfoResult.ParticipantSpecificFields)
                {
                    if (model.HasDomainList == 1 || model.HasValidation)
                    {
                        var customdield = new CustomFieldDomainRepository(_db, _cobraConfig);
                        model.CustomFieldDomain = await customdield.GetSpecificFieldsByPid(searchModel.PlatformName, model.CustomFieldId);
                    }
                }
            }
            if (!string.IsNullOrEmpty(searchModel.ParticipantId))
            {
                var dependents = new DependentRepository(_db, _cobraConfig);
                participantToCancel.InfoResult.Dependents = await dependents.GetDependentByParentPid(participantId);
            }

            var relations = new RelationRepository(_db, _cobraConfig);
            participantToCancel.InfoResult.Relations = await relations.GetRelations(searchModel);

            var billing = new BillingRepository(_db, _cobraConfig);
            var participantModel = new ParticipantIdModel
            {
                ParticipantId = searchModel.ParticipantId,
                ClientId = searchModel.ClientId,
                UserId = searchModel.UserId,
                PlatformName = searchModel.PlatformName,
                PageNumber = "1",
                PageSize = "8"
            };
            participantToCancel.BillingDetail = await billing.GetBillingDetail(participantModel);


            return participantToCancel;
        }
    }
}

﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class CobraHipaaRepository : GenericRepository<CobraHipaaViewModel>, ICobraHipaaRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public CobraHipaaRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }
        public async Task<CobraHipaaViewModel?> CobraHipaaNotice(UserClientModel cobtra)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(cobtra.PlatformName));
            Query participantGetByID = ParticipantSelect.GetCobraHipaaNotice(cobtra.ClientId);
            CobraHipaaViewModel? lstSearch = await ExecuteGenericRow(participantGetByID);
            return lstSearch;
        }
    }
}

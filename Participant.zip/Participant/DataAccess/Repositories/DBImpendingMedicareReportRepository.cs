﻿using Core.Interfaces;
using Core.Model;
using Core.Util;
using DataAccess.Queries;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Repositories
{
    public class DBImpendingMedicareReportRepository : GenericRepository<DBImpendingMedicareReportModel>, IDBImpendingMedicareReportRepository
    {
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        public DBImpendingMedicareReportRepository(CobraDbContext db, ICobraConfig cobraConfig) : base(db)
        {
            _db = db;
            _cobraConfig = cobraConfig;
        }

        public async Task<List<DBImpendingMedicareReportModel>?> GetImpendingMedicareReport(PlatformModel model)
        {
            var database = _db.Database;
            database.SetConnectionString(await _cobraConfig.GetCLProd(model.PlatformName));

            Query query = DirectBillExecSP.ImpendingMedicareReport(model);
            List<DBImpendingMedicareReportModel>? dBImpendingMedicareReportModels = await ExecuteGeneric(query);
            return dBImpendingMedicareReportModels;
        }
    }
}

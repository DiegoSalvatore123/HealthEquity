﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries
{
    public class DirectBillExecSP
    {
        public static Query ImpendingMedicareReport(PlatformModel model)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"EXEC P319_ImpendingMedicare_DirectBill @ClientID, @UserID";

            dictionary.Add("@ClientID", model.ClientId);
            dictionary.Add("@UserID", model.UserId);

            query.Parameters = dictionary;
            return query;
        }
    }
}

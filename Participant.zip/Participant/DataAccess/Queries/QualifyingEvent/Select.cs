﻿using Core.Model;
using Core.Util;
//using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace DataAccess.Queries.QualifyingEvent
{
    public static class Select
    {
        public static Query SearchClientOption(ClientOptionModel model)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT ISNULL(OPTION_VALUE, '') AS OPTION_VALUE FROM CLIENT_OPTION_ALL WITH (NOLOCK)  
                        WHERE CLIENT_ID = @Client_Id  
                         AND CLIENT_OPTION_ID = @ClientOption_Id ";

            dictionary.Add("@Client_Id", model.ClientId);
            dictionary.Add("@ClientOption_Id", model.ClientOptionId.ToString());
            query.Parameters = dictionary;
            return query;
        }
        public static Query SearchClientOptionLookup(ClientOptionModel model)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT case when USE_DEFAULT= '1' then DEFAULT_VALUE else '0' end OPTION_VALUE from CLIENT_OPTION_LOOKUP WITH (NOLOCK) 
            where CLIENT_OPTION_ID = @ClientOption_Id ";

            dictionary.Add("@ClientOption_Id", model.ClientOptionId.ToString());
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetQualifyingEventType(QualifyingEventTypeModel model)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT QualifyingEventType, 
                                        QualifyingEventName, 
                                        AdminFee, 
                                        ExtensionLength, 
                                        VariableExtension, 
                                        ContinuationType,
                                        l.lookup_description AS 'QualifyingEventScope'
                                 FROM client.QualifyingEvents(@ClientId) Q 
                                 INNER JOIN dbo.lookupcodes('qualifying_event', 'type') L ON Q.QualifyingEventScope = L.lookup_code ";

            QualifyingEventTypeEnum eventType;
            if (Enum.TryParse(model.QualifyingEventType, out eventType))
            {
                switch (eventType)
                {
                    case QualifyingEventTypeEnum.Employee:
                        query.SelectFrom += @" WHERE Q.QualifyingEventScope IN ('A','B','E','L','O','R','P','T') ";
                        break;
                    case QualifyingEventTypeEnum.Spouse:
                        query.SelectFrom += @" WHERE Q.QualifyingEventScope IN ('A','D','E','L','O','R','S','T') ";
                        break;
                    case QualifyingEventTypeEnum.Child:
                        query.SelectFrom += @" WHERE Q.QualifyingEventScope IN ('A','D','C','E','L','O','R','T') ";
                        break;
                }
            dictionary.Add("@ClientId", model.ClientId);
            query.Parameters = dictionary;
         
            }
            return query;
        }
        public static Query GetLifeInsuranceRTPlan(string planId, string rateType)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select CASE WHEN count(*) > 0 THEN '1' Else '0' End Value from PLAN_RATE_TABLE WITH (NOLOCK)  where plan_id = @PlanId and RATE_TYPE =@RateType ";

            dictionary.Add("@PlanId", planId);
            dictionary.Add("@RateType", rateType);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetPlanType(string planId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @" SELECT PLAN_TYPE AS Value
                                  FROM PLAN_OPTION WITH (NOLOCK)  WHERE PLAN_ID = @PlanId ";

            dictionary.Add("@PlanId", planId);

            query.Parameters = dictionary;
            return query;
        }
        public static Query GetPlanOption(string planId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select CAST(option_value AS varchar) AS Value 
                                  FROM plan_option_all WITH (NOLOCK)  WHERE plan_option_id = 203 and PLAN_ID = @PlanId ";

            dictionary.Add("@PlanId", planId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetCoverage(string code)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select COVERAGE_CODE Code, COVERAGE_DESCRIPTION Description from COVERAGES WITH (NOLOCK)  WHERE COVERAGE_CODE =@Code ";

            dictionary.Add("@Code", code);

            query.Parameters = dictionary;
            return query;
        }
        public static Query GetQEExtension(string code)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select case when EXTENSION_LENGTH is null then '-2' else
                                case when not ISNUMERIC(EXTENSION_LENGTH) = 1 then '-2' else
                                case when VARIABLE_EXTENSION =1 then '-1' else  CAST(EXTENSION_LENGTH AS VARCHAR(1))
                            end end end Value from QUALIFYING_EVENTS WITH (NOLOCK)  where CODE = @CODE ";

            dictionary.Add("@CODE", code);
            query.Parameters = dictionary;
            return query;
        }
        public static Query SearchqQePlanComponent(string planId, string isLifeInsuranceRTPlan)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @" SELECT 
                                    CASE WHEN ((PO.RATE_TYPE = 'IR' OR PO.RATE_TYPE = 'MI') AND PO.COVERAGE_TYPE = 'A')
                                              THEN 1 
                                              ELSE CASE PO.COVERAGE_TYPE WHEN 'A' 
                                  			                             THEN ISNULL((SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
                                                                                      FROM PLAN_OPTION PO1 WITH (NOLOCK) 
                                                                                      JOIN PLAN_INTEGRATION I WITH (NOLOCK) ON PO1.PLAN_ID = I.COMPONENT_PLAN_ID 
                                                                                      JOIN PlanBenefitType B WITH (NOLOCK) ON PO1.PLAN_ID = B.PlanId 
                                                                                      WHERE I.INTEGRATED_PLAN_ID  = @PlanId
                                                                                         AND (PO1.RATE_TYPE = 'MI' OR PO1.RATE_TYPE = 'IR')),0)
                                                                         ELSE 0
                                  	             END 
                                  	    END AS DisablePLS,
                                  	    CASE PO.COVERAGE_TYPE WHEN 'A' 
                                  	                          THEN ISNULL((SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
                                                                           FROM PLAN_OPTION PO1 WITH (NOLOCK) 
                                                                           JOIN PLAN_INTEGRATION I WITH (NOLOCK) ON PO1.PLAN_ID = I.COMPONENT_PLAN_ID 
                                                                           JOIN PlanBenefitType B WITH (NOLOCK) ON PO1.PLAN_ID = B.PlanId 
                                                                           WHERE I.INTEGRATED_PLAN_ID  = @PlanId
                                                                             AND B.BenefitTypeSubtypeId > 0 ),0)
                                  	                          ELSE 0
                                  	    END AS Bentypecnt,
                                        CASE WHEN PO.COVERAGE_TYPE = 'F' AND (PO.RATE_TYPE != 'RT' OR (PO.RATE_TYPE = 'RT' AND @IsLifeInsuranceRTPlan = '0'))
                                             THEN 1
                                        	 ELSE 0
                                        END AS Salary,
                                        CASE PO.COVERAGE_TYPE WHEN 'A' 
                                                THEN 
								                ISNULL((SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
                                                        FROM PLAN_OPTION PO1 WITH (NOLOCK) 
                                                        JOIN PLAN_INTEGRATION I WITH (NOLOCK) ON PO1.PLAN_ID = I.COMPONENT_PLAN_ID 
                                                        JOIN PlanBenefitType B WITH (NOLOCK) ON PO1.PLAN_ID = B.PlanId 
                                                        WHERE I.INTEGRATED_PLAN_ID  = @PlanId),0)
                                                ELSE 
								                isnull((select benefittypesubtypeid from  PlanBenefitType with (nolock) where planID = @PlanId),0)
                                                END AS benefittypesubtypeid
                                  FROM PLAN_OPTION PO WITH (NOLOCK) 
                WHERE PO.PLAN_ID = @PlanId ";

            dictionary.Add("@PlanId", planId);
            dictionary.Add("@IsLifeInsuranceRTPlan", isLifeInsuranceRTPlan);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetTobaccoUsePlan(string planId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select CAST(TobaccoUse AS varchar) as Value from dbo.MemberLevelRatingFactor WITH (NOLOCK)
            where PlanID = @PlanId";

            dictionary.Add("@PlanId", planId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetDirectRateEntry(string clientId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select case when option_value=1 then '1' else '0' end  AS Value 
                                  FROM CLIENT_OPTION_ALL WITH (NOLOCK) 
                WHERE CLIENT_ID = @clientId and CLIENT_OPTION_ID = 172 ";

            dictionary.Add("@clientId", clientId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query QEExtension(string qeCode)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select CAST(extension_length AS VARCHAR(5))extension_length, CAST(VARIABLE_EXTENSION AS VARCHAR(5)) VARIABLE_EXTENSION,case when EXTENSION_LENGTH is null then '-2' else
                                case when not ISNUMERIC(EXTENSION_LENGTH) = 1 then '-2' else
                                case when VARIABLE_EXTENSION =1 then '-1' else  CAST(EXTENSION_LENGTH AS VARCHAR(3))
                            end end end Extension from QUALIFYING_EVENTS WITH (NOLOCK) 
                where CODE = @CODE ";
            dictionary.Add("@CODE", qeCode);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetBenefitForPlanId(string planId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select po.plan_name, po.plan_ID, i.component_plan_id, po.rate_type, b.benefittypesubtypeid, d.fulldisplayname   
				  from plan_option po with (nolock)  
				 join PLAN_INTEGRATION i with (nolock) on po.plan_ID = i.component_plan_id   
				 left join PlanBenefitType b with (nolock) on po.plan_ID = b.planid   
				 left join domain.BenefitTypeSubtypeInfo d with (nolock) on d.benefittypesubtypeid = b.benefittypesubtypeid 
                where i.INTEGRATED_PLAN_ID = @PlanId  ";

            dictionary.Add("@PlanId", planId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetPreferredLanguage(string clientId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT DEFAULT_PREFERRED_LANGUAGE as Value from client WITH (NOLOCK) 
            WHERE CLIENT_ID = @CLIENT_ID";

            dictionary.Add("@CLIENT_ID", clientId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetCafePlan(int planId)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
	                if exists(select PLAN_ID
                 from PLAN_OPTION WITH (NOLOCK)
                  where PLAN_ID =  @PlanId
                  and PLAN_TYPE in ('F','A','B' ))
                  select '1' as OPTION_VALUE
                  else 
                select '0' as OPTION_VALUE";
            dictionary.Add("@PlanId", planId.ToString());

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
        public static Query GetCoveragError(string participantId)
        {
            Query coverageCount = new();
            Dictionary<string, string> dictionary = new();
            coverageCount.SelectFrom = @"Select cast(count(v.PARTICIPANT_ID) as varchar) OPTION_VALUE from V304_WebDependentExceptions v WITH (NOLOCK) 
                         where v.PARTICIPANT_ID=@Participant";

            dictionary.Add("@Participant", participantId.ToString());
            coverageCount.Parameters = dictionary;
            return coverageCount;
        }
        public static Query GetCoveragErrorQE(string participantId)
        {
            Query coverageCount = new();
            Dictionary<string, string> dictionary = new();
            coverageCount.SelectFrom = @"Select cast(count(v.PARTICIPANT_ID) as varchar) OPTION_VALUE from V304_WebDependentExceptionsQE v WITH (NOLOCK) 
                         where v.PARTICIPANT_ID=@Participant";

            dictionary.Add("@Participant", participantId.ToString());
            coverageCount.Parameters = dictionary;
            return coverageCount;
        }
        public static Query GetCoveragExisting(string participantId)
        {
            Query coverageCount = new();
            Dictionary<string, string> dictionary = new();
            coverageCount.SelectFrom = @"select cast(count(p.PARTICIPANT_ID) as varchar) OPTION_VALUE 
	        from PARTICIPANT p WITH (NOLOCK)  
	        inner join CurrentParticipantAddress cpa WITH (NOLOCK) on p.PARTICIPANT_ID=cpa.PARTICIPANT_ID  
	        where p.PARTICIPANT_ID =@Participant";
            dictionary.Add("@Participant", participantId.ToString());
            coverageCount.Parameters = dictionary;
            return coverageCount;
        }
        public static Query GetMLRQuotitData(string Guids)
        {
            Query mlrCount = new();
            Dictionary<string, string> dictionary = new();
            int i = 0;
            var allGuid=Guids.Split(',');
            mlrCount.SelectFrom = @"Select cast(count(TypeId) as varchar) OPTION_VALUE FROM MLRQuotitData WITH (NOLOCK) where ProcessIdentifier in ( ";
            foreach (string ProcessIdentifier in allGuid)
            {
                dictionary.Add("@ProcessIdentifier" + i, ProcessIdentifier);
                mlrCount.SelectFrom += i > 0 ? "," : "";
                mlrCount.SelectFrom += " CAST(CAST(@ProcessIdentifier" + i + " as char(36)) as uniqueidentifier) ";
                i++;
            }
            mlrCount.SelectFrom += " ) AND TypeId = 5 AND NOT(CompleteDate IS NULL)";
            mlrCount.Parameters = dictionary;
            return mlrCount;
        }
        public static Query GetPlansDates(int planId)
        {
            Query mlrCount = new();
            Dictionary<string, string> dictionary = new();
           
            mlrCount.SelectFrom = @"Select CAST(RateStartDate AS VARCHAR) as Code , CAST(RateEndDate AS VARCHAR) as Description from memberlevelratingdate with(nolock)  where PlanId=@PlanId ";
            dictionary.Add("@PlanId", planId.ToString());
            mlrCount.Parameters = dictionary;
            return mlrCount;
        }
    }
}

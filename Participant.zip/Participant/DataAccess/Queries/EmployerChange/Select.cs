﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries.EmployerChange
{
    public class Select
    {
        public static Query GetClientsList(string clUserId, string clientId)
        {
            Query clients = new();
            Dictionary<string, string> dictionary = new();
            clients.SelectFrom = @"SELECT CL.CLIENT_ID,EMPLOYER_NAME,EIN FROM CLIENT CL WITH (NOLOCK) 
                   INNER JOIN CLIENT_USER CU WITH (NOLOCK) ON CL.CLIENT_ID = CU.CLIENT_ID 
                    WHERE CU.CL_USER_ID=@CL_USER_ID AND CL.CLIENT_ID!=@CLIENT_ID AND CL.CLIENT_STATUS='A'
                    ORDER BY CL.EMPLOYER_NAME";
            dictionary.Add("@CL_USER_ID", clUserId);
            dictionary.Add("@CLIENT_ID", clientId);
            clients.Parameters = dictionary;
            return clients;
        }
    }
}

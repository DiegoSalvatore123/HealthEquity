﻿using Core.Model;
using Core.Util;
namespace DataAccess.Queries
{
    public static class CobraSelect
    {
        public static Query GetEmployeeCounts(PlatformModel model)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
				select 
				case when (trans_code ='15' or trans_code ='16') and OPTION_VALUE=0 and user_type>0 then 'true' 
				else 'false' end OPTION_VALUE
				from
				(
					select top 1 
					trans_code  
					 from Contract_Fee cf with (nolock) 
					 inner join contract c with (nolock) on c.contract_id = cf.contract_id 
					 where c.client_id =   @ClientID
					 and cf.trans_code in ('15','16') 
					 and effective_Date <= getdate() and (termination_Date >= getdate() or termination_Date is null) 
				) A,
				(
					select count( OPTION_VALUE)OPTION_VALUE
					from CLIENT_OPTION_ALL WITH (NOLOCK) 
					where CLIENT_ID =  @ClientID
					and CLIENT_OPTION_ID = 1010  
					and OPTION_VALUE = '1' 
				)B,
				(
					select count(user_type)  user_type 
					from cl_user c with (nolock)  
					 where c.CL_USER_ID =  @UserID
					 and c.user_type not in ('I','O') 
					 and c.default_security_level in ('FA','NO','DE','DO')  
					 and c.lockout <> 1 and c.disabled <> 1  
				)C
			";
         
            dictionary.Add("@UserID", model.UserId);
            dictionary.Add("@ClientID", model.ClientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
        public static Query GetClientPlans(string clientId)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
				 SELECT 
				 PO.PLAN_ID,PLAN_NAME,PLAN_TYPE, 
				 CA.COVERAGE_END_TYPE,CA.WAIT_PERIOD_TYPE,CA.WAIT_PERIOD_QTY, 
				 CA.WAIT_ENDS_TYPE 
				 from PLAN_OPTION PO WITH (NOLOCK) 
				 INNER JOIN CARRIER CA WITH (NOLOCK) on PO.CARRIER_ID=CA.CARRIER_ID 
				 WHERE PLAN_STATUS='A' 
				 and PLAN_TYPE!='R'
				 and PO.CLIENT_ID= @ClientID
				 ORDER BY PLAN_TYPE,PLAN_NAME
			";
            dictionary.Add("@ClientID", clientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
    }
}

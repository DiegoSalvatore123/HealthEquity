﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries
{
    public class ParticipantInserts
    {
        public static Query InsertParticipant(ParticipantInsertModel participantInsertModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT PARTICIPANT (CLIENT_ID, ELIGIBLE ";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.AffiliateId))
            { 
                pInsert.SelectFrom += ",AFFILIATE_ID ";
                dictionary.Add("@AFFILIATE_ID", participantInsertModel.ParticipantInfo.AffiliateId.ToString());
            }
            if (participantInsertModel.Co709 != null && participantInsertModel.Co709 != "0" && participantInsertModel.ParticipantInfo.EmployeeClassId!=null)
            { 
                pInsert.SelectFrom += ",EMPLOYEE_CLASS_ID";
                dictionary.Add("@EMPLOYEE_CLASS_ID", participantInsertModel.ParticipantInfo.EmployeeClassId.ToString());
            }
            pInsert.SelectFrom += @",HIRE_DATE,PARTICIPANT_TYPE, PARTICIPANT_STATUS,LAST_NAME,FIRST_NAME";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.MiddleInitial))
            { 
                pInsert.SelectFrom += ",MIDDLE_INITIAL";
                dictionary.Add("@MIDDLE_INITIAL", participantInsertModel.ParticipantInfo.MiddleInitial ?? "");
            }
            pInsert.SelectFrom += @",GENDER,BIRTH_DATE, SOCIAL_SECURITY_NUMBER ";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.EmployeeNumber))
            { 
                pInsert.SelectFrom += ",EMPLOYEE_NUMBER";
                dictionary.Add("@EMPLOYEE_NUMBER", participantInsertModel.ParticipantInfo.EmployeeNumber ?? "");
            }
            pInsert.SelectFrom += ",EMAIL_ADDRESS";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.PhoneNumber))
            { 
                pInsert.SelectFrom += " ,PHONE_NUMBER";
                dictionary.Add("@PHONE_NUMBER", participantInsertModel.ParticipantInfo.PhoneNumber ?? "");
            }

            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.WaitingStartDate))
            {
                pInsert.SelectFrom += ", WAITING_START_DATE";
                dictionary.Add("@WAITING_START_DATE", participantInsertModel.ParticipantInfo.WaitingStartDate);
            }

            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.CoverageStartDate))
            {
                pInsert.SelectFrom += ", COVERAGE_START_DATE";
                dictionary.Add("@COVERAGE_START_DATE", participantInsertModel.ParticipantInfo.CoverageStartDate);
            }

            pInsert.SelectFrom += @",QUALIFIED_BENEFICIARY,RELATIONSHIP, PREFERRED_LANGUAGE) VALUES (@CLIENT_ID,@ELIGIBLE";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.AffiliateId))
            { 
                pInsert.SelectFrom += ",@AFFILIATE_ID";
            }
            if (participantInsertModel.Co709 != null && participantInsertModel.Co709 != "0" && participantInsertModel.ParticipantInfo.EmployeeClassId != null)
            { 
                pInsert.SelectFrom += ",@EMPLOYEE_CLASS_ID";
            }
            pInsert.SelectFrom += @",@HIRE_DATE,@PARTICIPANT_TYPE, @PARTICIPANT_STATUS,@LAST_NAME,@FIRST_NAME";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.MiddleInitial))
            { 
                pInsert.SelectFrom += ",@MIDDLE_INITIAL";
            }
            pInsert.SelectFrom += @",@GENDER,@BIRTH_DATE ,@SOCIAL_SECURITY_NUMBER";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.EmployeeNumber))
            { 
                pInsert.SelectFrom += ",@EMPLOYEE_NUMBER";
            }
            pInsert.SelectFrom += ",@EMAIL_ADDRESS";
            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.PhoneNumber))
            { 
                pInsert.SelectFrom += ",@PHONE_NUMBER";
            }

            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.WaitingStartDate))
            {
                pInsert.SelectFrom += ",@WAITING_START_DATE";
            }

            if (!string.IsNullOrWhiteSpace(participantInsertModel.ParticipantInfo.CoverageStartDate))
            {
                pInsert.SelectFrom += ",@COVERAGE_START_DATE";
            }

            pInsert.SelectFrom += " ,@QUALIFIED_BENEFICIARY,@RELATIONSHIP,@PREFERRED_LANGUAGE); set @Pid = scope_identity();";

            dictionary.Add("@CLIENT_ID", participantInsertModel.ClientId);
            dictionary.Add("@ELIGIBLE", "Y");
            dictionary.Add("@HIRE_DATE", participantInsertModel.ParticipantInfo.ReHireDate == "" ? participantInsertModel.ParticipantInfo.HireDate : participantInsertModel.ParticipantInfo.ReHireDate!);
            dictionary.Add("@PARTICIPANT_TYPE", participantInsertModel.ParticipantType);
            dictionary.Add("@PARTICIPANT_STATUS", participantInsertModel.Status);
            dictionary.Add("@LAST_NAME", participantInsertModel.ParticipantInfo.LastName);
            dictionary.Add("@FIRST_NAME", participantInsertModel.ParticipantInfo.FirstName);
            dictionary.Add("@GENDER", participantInsertModel.ParticipantInfo.Gender);
            dictionary.Add("@BIRTH_DATE", participantInsertModel.ParticipantInfo.BirthDate ?? "");
            dictionary.Add("@SOCIAL_SECURITY_NUMBER", participantInsertModel.ParticipantInfo.SocialSecurityNumber);
            dictionary.Add("@EMAIL_ADDRESS", participantInsertModel.ParticipantInfo.EmailAddress ?? "");
            dictionary.Add("@QUALIFIED_BENEFICIARY", participantInsertModel.ParticipantInfo.QualifiedBeneficiary??"");
            dictionary.Add("@RELATIONSHIP", participantInsertModel.ParticipantInfo!.RelationShip!);
            dictionary.Add("@PREFERRED_LANGUAGE", participantInsertModel.PopFlexLan?.Lan ?? "");
            dictionary.Add("@Pid", "0");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertAddress(AddressModel addressModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT ADDRESS (PARTICIPANT_ID,EFFECTIVE_DATE,ADDRESS_1,ADDRESS_2,CITY,STATE,ZIP,LOG_DATE, CL_USER_ID)
                  VALUES (@PARTICIPANT_ID,getdate(),@ADDRESS_1,@ADDRESS_2,@CITY, @STATE,@ZIP,getdate(),@CL_USER_ID);";
          
            dictionary.Add("@PARTICIPANT_ID", addressModel.ParticipantId.ToString());
            dictionary.Add("@ADDRESS_1", addressModel.Address1);
            dictionary.Add("@ADDRESS_2", addressModel.Address2);
            dictionary.Add("@CITY", addressModel.City);
            dictionary.Add("@STATE", addressModel.State );
            dictionary.Add("@ZIP", addressModel.Zip );
            dictionary.Add("@CL_USER_ID", addressModel.UserId);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertEvent(EventModel eventModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT EVENT(EVENT_TYPE,EVENT_DATE,PARTICIPANT_ID,LOG_DATE,EVENT_SOURCE,COMMENTS,[USER_ID] )
                  VALUES (@EVENT_TYPE,getdate(),@PARTICIPANT_ID,getdate(),@EVENT_SOURCE,@COMMENTS,@USER_ID)";

            dictionary.Add("@PARTICIPANT_ID", eventModel.ParticipantId.ToString());
            dictionary.Add("@EVENT_TYPE", eventModel.EventType);
            dictionary.Add("@EVENT_SOURCE", eventModel.EventSource);
            dictionary.Add("@COMMENTS", eventModel.Comment);
            dictionary.Add("@USER_ID", eventModel.UserId);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertDependentParticipant(DependentNewViewModel dependent, bool retrieveDependentId = false)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT PARTICIPANT (Parent_Participant_id,Eligible,Participant_Type,First_Name,Last_Name,MIDDLE_INITIAL,
                                SOCIAL_SECURITY_NUMBER,BIRTH_DATE,GENDER,RELATIONSHIP,STUDENT,QUALIFIED_BENEFICIARY,
                                PARTICIPANT_STATUS,WAITING_START_DATE,COVERAGE_START_DATE)
                                VALUES (@PARENT_PARTICIPANT_ID,@ELIGIBLE,@PARTICIPANT_TYPE,@FIRST_NAME,@LAST_NAME,@MIDDLE_INITIAL,
                                @SOCIAL_SECURITY_NUMBER,@BIRTH_DATE,@GENDER,@RELATIONSHIP,@STUDENT,@QUALIFIED_BENEFICIARY,
                                @PARTICIPANT_STATUS,@WAITING_START_DATE,@COVERAGE_START_DATE);";
            dictionary.Add("@ELIGIBLE", "Y");
            dictionary.Add("@PARENT_PARTICIPANT_ID", dependent.ParticipantId.ToString() ??"0");
         //   dictionary.Add("@PARTICIPANT_TYPE", dependent.ParticipantType);
            dictionary.Add("@PARTICIPANT_TYPE", "D");
            dictionary.Add("@FIRST_NAME", dependent.FirstName);
            dictionary.Add("@LAST_NAME", dependent.LastName);
            dictionary.Add("@MIDDLE_INITIAL", dependent.MiddleInitial ?? "");
            dictionary.Add("@SOCIAL_SECURITY_NUMBER", dependent.SocialSecurityNumber ?? "");
            dictionary.Add("@BIRTH_DATE", dependent.BirthDate);
            dictionary.Add("@GENDER", dependent.Gender);
            dictionary.Add("@RELATIONSHIP", dependent.Relationship);
            dictionary.Add("@STUDENT", dependent.Student);
            dictionary.Add("@QUALIFIED_BENEFICIARY", dependent.QualifiedBeneficiary);
            dictionary.Add("@PARTICIPANT_STATUS", dependent.ParticipantStatus);
            dictionary.Add("@WAITING_START_DATE", dependent.WaitingStartDate);
            dictionary.Add("@COVERAGE_START_DATE", dependent.CoverageStartDate);
            if (retrieveDependentId)
            {
                pInsert.SelectFrom += @" set @Pid = scope_identity(); ";
                dictionary.Add("@Pid", "0");
            }            

            pInsert.Parameters = dictionary;
            return pInsert;
        }        
        public static Query UpdateClientForEmployerChange(EmployerChangeUpdateModel model)
        {
            Query clientUpdate = new();
            Dictionary<string, string> dictionary = new();
            clientUpdate.SelectFrom = @"UPDATE PARTICIPANT SET CLIENT_ID = @NewClientID WHERE PARTICIPANT_ID = @PaticipantId";

            dictionary.Add("@PaticipantId", model.ParticipantId.ToString() ?? "0");
            dictionary.Add("@NewClientID", model.NewClientId! ?? "0");
            clientUpdate.Parameters = dictionary;
            return clientUpdate;
        }
        public static Query UpdateParticipant(InfoResultViewModel ParticipantInfo)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"UPDATE PARTICIPANT SET LAST_NAME =@LAST_NAME,FIRST_NAME=@FIRST_NAME ";
            if (!string.IsNullOrEmpty(ParticipantInfo.AffiliateId))
            {
                pInsert.SelectFrom += ",AFFILIATE_ID =@AFFILIATE_ID ";
                dictionary.Add("@AFFILIATE_ID", ParticipantInfo.AffiliateId.ToString());
            }
            if (!string.IsNullOrEmpty(ParticipantInfo.Gender))
            {
                pInsert.SelectFrom += ",GENDER =@GENDER ";
                dictionary.Add("@GENDER", ParticipantInfo.Gender);
            }

            if (!string.IsNullOrEmpty(ParticipantInfo.HireDate))
            {
                pInsert.SelectFrom += ",HIRE_DATE =@HIRE_DATE ";
                dictionary.Add("@HIRE_DATE", ParticipantInfo.HireDate);
            }
            pInsert.SelectFrom += ",MIDDLE_INITIAL =@MIDDLE_INITIAL";
            dictionary.Add("@MIDDLE_INITIAL", ParticipantInfo.MiddleInitial ?? "");
            pInsert.SelectFrom += ",SOCIAL_SECURITY_NUMBER =@SOCIAL_SECURITY_NUMBER";
            dictionary.Add("@SOCIAL_SECURITY_NUMBER", ParticipantInfo.SocialSecurityNumber ?? "");
            pInsert.SelectFrom += @",BIRTH_DATE=@BIRTH_DATE ";
            pInsert.SelectFrom += ",EMPLOYEE_NUMBER=@EMPLOYEE_NUMBER";
            dictionary.Add("@EMPLOYEE_NUMBER", ParticipantInfo.EmployeeNumber ?? "");
            pInsert.SelectFrom += ",EMAIL_ADDRESS=@EMAIL_ADDRESS";
            dictionary.Add("@EMAIL_ADDRESS", ParticipantInfo.EmailAddress ?? "");
            pInsert.SelectFrom += ",EMPLOYEE_CLASS_ID=@EMPLOYEE_CLASS_ID";
            dictionary.Add("@EMPLOYEE_CLASS_ID", ParticipantInfo.EmployeeClassId ?? "");
            pInsert.SelectFrom += ",PHONE_NUMBER=@PHONE_NUMBER";
            dictionary.Add("@PHONE_NUMBER", ParticipantInfo.PhoneNumber ?? "");
            if (!string.IsNullOrEmpty(ParticipantInfo.ParticipantStatus))
            {
                pInsert.SelectFrom += ",PARTICIPANT_STATUS=@PARTICIPANT_STATUS";
                dictionary.Add("@PARTICIPANT_STATUS", ParticipantInfo.ParticipantStatus ?? "");
            }
            if (!string.IsNullOrEmpty(ParticipantInfo.Student))
            {
                pInsert.SelectFrom += ",STUDENT=@STUDENT";
                dictionary.Add("@STUDENT", ParticipantInfo.Student ?? "");
            }
            if (!string.IsNullOrEmpty(ParticipantInfo.RelationShip))
            {
                pInsert.SelectFrom += " ,RELATIONSHIP=@RELATIONSHIP";
                dictionary.Add("@RELATIONSHIP", ParticipantInfo.RelationShip ?? "");
            }
            pInsert.SelectFrom += @" WHERE Participant_ID =@PARTICIPANT_ID ";
            dictionary.Add("@LAST_NAME", ParticipantInfo.LastName);
            dictionary.Add("@FIRST_NAME", ParticipantInfo.FirstName);
            dictionary.Add("@BIRTH_DATE", ParticipantInfo.BirthDate ?? "");
            dictionary.Add("@PARTICIPANT_ID", ParticipantInfo.ParticipantId ?? "");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
       
        public static Query UpdateParticipantQE(ProcessQEInfoModel processQE, int participantID)
        {
            bool severance=false;
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"UPDATE PARTICIPANT SET 
                QUALIFYING_EVENT_DATE =@QUALIFYING_EVENT_DATE,Qualifying_Event_Type=@Qualifying_Event_Type,LAST_PRECOBRA_COVERED_DATE=@LAST_PRECOBRA_COVERED_DATE,COBRA_STATUS='C' " +
               " ,BILLING_START_DATE=@BILLING_START_DATE,COVERAGE_START_DATE=@COVERAGE_START_DATE,Waiting_Start_Date=@Waiting_Start_Date,ELIGIBILITY_START_DATE=@ELIGIBILITY_START_DATE,ELIGIBILITY_END_DATE=@ELIGIBILITY_END_DATE";

            dictionary.Add("@QUALIFYING_EVENT_DATE", processQE!.QEEventDate??"");
            dictionary.Add("@BILLING_START_DATE", processQE!.BillingStartDate ?? "");
            dictionary.Add("@Waiting_Start_Date", processQE!.WaitingStartDate ?? "");
            dictionary.Add("@Qualifying_Event_Type", processQE!.QeReason ?? "");
            dictionary.Add("@LAST_PRECOBRA_COVERED_DATE", processQE!.LastDayPreCobraCoverage ?? "");
            dictionary.Add("@COVERAGE_START_DATE", processQE!.CoverageBeginDate ?? "");
            dictionary.Add("@ELIGIBILITY_START_DATE", processQE!.EligibilityStart ?? "");
            dictionary.Add("@ELIGIBILITY_END_DATE", processQE!.EligiibilityEndDate ?? "");

            if (!string.IsNullOrEmpty(processQE!.SevThrough))
            {
                severance=true;
                pInsert.SelectFrom += ",SEVERANCE_THROUGH =@SEVERANCE_THROUGH ";
                dictionary.Add("@SEVERANCE_THROUGH", processQE!.SevThrough);
            }
            if (!string.IsNullOrEmpty(processQE!.SevMonthly) && int.Parse(processQE!.SevMonthly) > 0)
            {
                severance = true;
                pInsert.SelectFrom += ",SEVERANCE_MONTHLY =@SEVERANCE_MONTHLY ";
                dictionary.Add("@SEVERANCE_MONTHLY", processQE!.SevMonthly);
            }
            if (!string.IsNullOrEmpty(processQE!.SevPercent) && int.Parse(processQE!.SevPercent)>1)
            {
                severance = true;
                pInsert.SelectFrom += ",SEVERANCE_PERCENT =@SEVERANCE_PERCENT ";
                dictionary.Add("@SEVERANCE_PERCENT", processQE!.SevPercent);
            }
            if (!string.IsNullOrEmpty(processQE!.Sev1Time) && int.Parse(processQE!.Sev1Time) > 0)
            {
                severance = true;
                pInsert.SelectFrom += ",SEVERANCE_CREDIT =@SEVERANCE_CREDIT ";
                dictionary.Add("@SEVERANCE_CREDIT", processQE!.Sev1Time);
            }
            if(severance)
                pInsert.SelectFrom += ",SEVERANCE_ER_PAYS_ADMIN_FEE=1 ";
            pInsert.SelectFrom += @" WHERE Participant_ID =@PARTICIPANT_ID ";
           
            dictionary.Add("@PARTICIPANT_ID", participantID.ToString());
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query UpdateParticipantPQE(ProcessQEInfoModel processQE, int participantID, bool coverages)
        {
            bool severance = false;
            Query pInsert = new();
            //Check Participant Status if it is X or A
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"UPDATE PARTICIPANT 
                                          SET QUALIFYING_EVENT_DATE = @QUALIFYING_EVENT_DATE,
                                              QUALIFYING_EVENT_TYPE = @QUALIFYING_EVENT_TYPE,
                                           
                                              WAITING_START_DATE = @WAITING_START_DATE,
                                             ";
            // PARTICIPANT_STATUS = 'A', COBRA_STATUS = 'Q' ";
            dictionary.Add("@QUALIFYING_EVENT_DATE", processQE!.QEEventDate ?? "");
            dictionary.Add("@QUALIFYING_EVENT_TYPE", processQE!.QeReason ?? "");

            if (string.IsNullOrWhiteSpace(processQE!.CoverageBeginDate))
                pInsert.SelectFrom += "  COVERAGE_START_DATE = null ";
            else
            {
                pInsert.SelectFrom += "  COVERAGE_START_DATE = @COVERAGE_START_DATE ";
                dictionary.Add("@COVERAGE_START_DATE", processQE!.CoverageBeginDate ?? "");
            }
            dictionary.Add("@WAITING_START_DATE", processQE!.WaitingStartDate ?? "");

            if ((processQE!.QeReason ?? "").Equals("04"))
                pInsert.SelectFrom += ", QUALIFIED_BENEFICIARY = 'N' ";

            if (!string.IsNullOrEmpty(processQE!.SevThrough))
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_THROUGH = @SEVERANCE_THROUGH ";
                dictionary.Add("@SEVERANCE_THROUGH", processQE!.SevThrough);
            }
            if (!string.IsNullOrEmpty(processQE!.SevMonthly) && int.Parse(processQE!.SevMonthly) >= 0.01)
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_MONTHLY = @SEVERANCE_MONTHLY ";
                dictionary.Add("@SEVERANCE_MONTHLY", processQE!.SevMonthly);
            }
            if (!string.IsNullOrEmpty(processQE!.SevPercent) && int.Parse(processQE!.SevPercent) >= 1)
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_PERCENT = @SEVERANCE_PERCENT ";
                dictionary.Add("@SEVERANCE_PERCENT", processQE!.SevPercent);
            }
            if (!string.IsNullOrEmpty(processQE!.Sev1Time) && int.Parse(processQE!.Sev1Time) >= 0.01)
            {
                //    severance = true;
                pInsert.SelectFrom += ", SEVERANCE_CREDIT = @SEVERANCE_CREDIT ";
                dictionary.Add("@SEVERANCE_CREDIT", processQE!.Sev1Time);
            }
            if (severance)
                pInsert.SelectFrom += ", SEVERANCE_ER_PAYS_ADMIN_FEE = 1 ";

            if (coverages)
            {
                if (!string.IsNullOrWhiteSpace(processQE!.LastDayPreCobraCoverage) &&
                    !string.IsNullOrWhiteSpace(processQE!.EligibilityStart) &&
                    !string.IsNullOrWhiteSpace(processQE!.EligiibilityEndDate))
                {
                    pInsert.SelectFrom += @", LAST_PRECOBRA_COVERED_DATE = @LAST_PRECOBRA_COVERED_DATE,
                                          ELIGIBILITY_START_DATE = @ELIGIBILITY_START_DATE,
                                          ELIGIBILITY_END_DATE = @ELIGIBILITY_END_DATE ";

                    dictionary.Add("@LAST_PRECOBRA_COVERED_DATE", processQE!.LastDayPreCobraCoverage ?? "");
                    dictionary.Add("@ELIGIBILITY_START_DATE", processQE!.EligibilityStart ?? "");
                    dictionary.Add("@ELIGIBILITY_END_DATE", processQE!.EligiibilityEndDate ?? "");
                }
            }

            if (!coverages)
                pInsert.SelectFrom += @", PARTICIPANT_STATUS = 'X', COBRA_STATUS = 'X' ";
            else
                pInsert.SelectFrom += @", COBRA_STATUS = 'Q' ";

            pInsert.SelectFrom += @" WHERE Participant_ID = @PARTICIPANT_ID ";

            dictionary.Add("@PARTICIPANT_ID", participantID.ToString());
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query UpdateParticipantPQE20(ProcessQEInfoModel processQE, int participantID, bool coverages)
        {
            bool severance = false;
            Query pInsert = new();
            //Check Participant Status if it is X or A
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"UPDATE PARTICIPANT 
                                          SET QUALIFYING_EVENT_DATE = @QUALIFYING_EVENT_DATE,
                                              QUALIFYING_EVENT_TYPE = @QUALIFYING_EVENT_TYPE,
                                              COVERAGE_START_DATE = @COVERAGE_START_DATE,
                                              WAITING_START_DATE = @WAITING_START_DATE,
                                               COBRA_STATUS =null ";

            dictionary.Add("@QUALIFYING_EVENT_DATE", processQE!.QEEventDate ?? "");
            dictionary.Add("@QUALIFYING_EVENT_TYPE", processQE!.QeReason ?? "");
            dictionary.Add("@COVERAGE_START_DATE", processQE!.CoverageBeginDate ?? "");
            dictionary.Add("@WAITING_START_DATE", processQE!.WaitingStartDate ?? "");

            pInsert.SelectFrom += ", QUALIFIED_BENEFICIARY = 'N' ";

            if (!string.IsNullOrEmpty(processQE!.SevThrough))
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_THROUGH = @SEVERANCE_THROUGH ";
                dictionary.Add("@SEVERANCE_THROUGH", processQE!.SevThrough);
            }
            if (!string.IsNullOrEmpty(processQE!.SevMonthly) && int.Parse(processQE!.SevMonthly) >= 0.01)
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_MONTHLY = @SEVERANCE_MONTHLY ";
                dictionary.Add("@SEVERANCE_MONTHLY", processQE!.SevMonthly);
            }
            if (!string.IsNullOrEmpty(processQE!.SevPercent) && int.Parse(processQE!.SevPercent) >= 1)
            {
                severance = true;
                pInsert.SelectFrom += ", SEVERANCE_PERCENT = @SEVERANCE_PERCENT ";
                dictionary.Add("@SEVERANCE_PERCENT", processQE!.SevPercent);
            }
            if (!string.IsNullOrEmpty(processQE!.Sev1Time) && int.Parse(processQE!.Sev1Time) >= 0.01)
            {
                //    severance = true;
                pInsert.SelectFrom += ", SEVERANCE_CREDIT = @SEVERANCE_CREDIT ";
                dictionary.Add("@SEVERANCE_CREDIT", processQE!.Sev1Time);
            }
            if (severance)
                pInsert.SelectFrom += ", SEVERANCE_ER_PAYS_ADMIN_FEE = 1 ";

       //     if (coverages)
                pInsert.SelectFrom += @", LAST_PRECOBRA_COVERED_DATE = @LAST_PRECOBRA_COVERED_DATE";

            pInsert.SelectFrom += @" WHERE Participant_ID = @PARTICIPANT_ID ";

            dictionary.Add("@PARTICIPANT_ID", participantID.ToString());
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertDependentParticipantPQE( InfoResultViewModel participantInfo, string clientId, string? preferredLanguage, string CO709)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT PARTICIPANT (CLIENT_ID,ELIGIBLE, AFFILIATE_ID ";
            if (!string.IsNullOrWhiteSpace(CO709) && CO709 != "0")
                pInsert.SelectFrom += ", EMPLOYEE_CLASS_ID";
            pInsert.SelectFrom += @", HIRE_DATE, PARTICIPANT_TYPE, PARTICIPANT_STATUS
                                , LAST_NAME, FIRST_NAME, MIDDLE_INITIAL, GENDER, BIRTH_DATE                                
                                , SOCIAL_SECURITY_NUMBER, QUALIFIED_BENEFICIARY, RELATIONSHIP, FORMER_DEPENDENT_ID
                                , PREFERRED_LANGUAGE, PHONE_NUMBER) VALUES (@CLIENT_ID,@ELIGIBLE ";
            if(!string.IsNullOrWhiteSpace(participantInfo.AffiliateId) && participantInfo.AffiliateId != "0")
            {
                pInsert.SelectFrom += ", @AFFILIATE_ID";
                dictionary.Add("@AFFILIATE_ID", participantInfo!.AffiliateId ?? "");
            }
            else
                pInsert.SelectFrom += ", null";
            if (!string.IsNullOrWhiteSpace(CO709) && CO709 != "0")
            {
                if(!string.IsNullOrWhiteSpace(participantInfo.EmployeeClassId) && participantInfo.EmployeeClassId != "0")
                { 
                    pInsert.SelectFrom += ", @EMPLOYEE_CLASS_ID";
                    dictionary.Add("@EMPLOYEE_CLASS_ID", participantInfo!.EmployeeClassId ?? "");
                } 
                else if(CO709 == "1" || CO709 == "2")
                    pInsert.SelectFrom += ", null";
            }
            pInsert.SelectFrom += ", null, 'E', 'A', @LAST_NAME, @FIRST_NAME";
            if (!string.IsNullOrWhiteSpace(participantInfo.MiddleInitial))
            {
                pInsert.SelectFrom += ", @MIDDLE_INITIAL";
                dictionary.Add("@MIDDLE_INITIAL", participantInfo!.MiddleInitial ?? "''");
            } 
            else 
                pInsert.SelectFrom += ", null";
           
            pInsert.SelectFrom += @", @GENDER, @BIRTH_DATE, @SOCIAL_SECURITY_NUMBER, 'Y', 'E'
                                   , @FORMER_DEPENDENT_ID, @PREFERRED_LANGUAGE, @PHONE_NUMBER); set @Pid = scope_identity();";
            
            dictionary.Add("@ELIGIBLE", "Y");
            dictionary.Add("@CLIENT_ID", clientId ?? "");
            dictionary.Add("@LAST_NAME", participantInfo!.LastName ?? "");
            dictionary.Add("@FIRST_NAME", participantInfo!.FirstName ?? "");
            dictionary.Add("@GENDER", participantInfo!.Gender ?? "");
            dictionary.Add("@BIRTH_DATE", participantInfo!.BirthDate ?? "");
            dictionary.Add("@SOCIAL_SECURITY_NUMBER", participantInfo!.SocialSecurityNumber ?? "");
       //     dictionary.Add("@QUALIFIED_BENEFICIARY", participantInfo!.QualifiedBeneficiary ?? "");
       //     dictionary.Add("@RELATIONSHIP", participantInfo!.RelationShip ?? "");
            dictionary.Add("@FORMER_DEPENDENT_ID", participantInfo!.ParticipantId ?? "");
            dictionary.Add("@PREFERRED_LANGUAGE", preferredLanguage ?? "");
            dictionary.Add("@PHONE_NUMBER", participantInfo!.PhoneNumber ?? "");
            dictionary.Add("@Pid", "0");
            pInsert.Parameters = dictionary;
            return pInsert;
        }        
        public static Query InsertCoverage(string participantID, AvailablePlansClientResultModel plans, string fixedPremiun, string billingStartDate, string converageState, string terminationDate)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = "INSERT INTO PARTICIPANT_COVERAGE (PARTICIPANT_ID,PLAN_ID,COVERAGE_CODE,EFFECTIVE_DATE ";
            if (converageState != "C")
                pInsert.SelectFrom += ",TERMINATION_DATE";
            pInsert.SelectFrom += ",COVERAGE_STATE ";
            if (!string.IsNullOrEmpty(plans.CoverageRate))
                pInsert.SelectFrom += ",FIXED_PREMIUM ";
            if (!string.IsNullOrEmpty(fixedPremiun))
                pInsert.SelectFrom += ",FIXED_PREMIUM_PRIMARY ";
            pInsert.SelectFrom += ")";

            pInsert.SelectFrom += "VALUES (@PARTICIPANT_ID,@PLAN_ID,@COVERAGE_CODE,@EFFECTIVE_DATE";
             if (converageState != "C")
                pInsert.SelectFrom += ",@TERMINATION_DATE";
            pInsert.SelectFrom += ",@COVERAGE_STATE ";
            if (!string.IsNullOrEmpty(plans.CoverageRate))
            {
                pInsert.SelectFrom += ", CONVERT(money,@FIXED_PREMIUM) ";
                dictionary.Add("@FIXED_PREMIUM", plans.CoverageRate.Replace("$","") ?? "");
            }
            if (!string.IsNullOrEmpty(fixedPremiun))
            {
                pInsert.SelectFrom += ", CONVERT(money,@FIXED_PREMIUM_PRIMARY) ";
                dictionary.Add("@FIXED_PREMIUM_PRIMARY", fixedPremiun);
            }
            pInsert.SelectFrom += "); set @Pid = scope_identity();";

            if (converageState != "C")
                dictionary.Add("@TERMINATION_DATE", terminationDate); 

            dictionary.Add("@COVERAGE_STATE", converageState);

            dictionary.Add("@PARTICIPANT_ID", participantID);
            dictionary.Add("@PLAN_ID", plans.PlanId.ToString() ?? "");
            dictionary.Add("@COVERAGE_CODE", plans.CoverageAvailablePlanCode ?? "");
            dictionary.Add("@EFFECTIVE_DATE", billingStartDate ?? "");
            dictionary.Add("@Pid", "0");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query ValidateExistCoverage(string participantId, string coverageId)
        {
            Query coverage = new();
            Dictionary<string, string> dictionary = new();
            coverage.SelectFrom = @" IF NOT EXISTS( select PC.PARTICIPANT_COVERAGE_ID 
                                     from dbo.PARTICIPANT_COVERAGE PC  with (noLock)
                                     Where PC.PARTICIPANT_ID = @Participant_Id
                                     and PC.PARTICIPANT_COVERAGE_ID = @PARTICIPANT_COVERAGE_ID)
                                     AND NOT EXISTS (
                                     SELECT 1 FROM dbo.DEPENDENT_COVERAGE WHERE COVERED_DEPENDENT_ID =@Participant_Id
									 AND PARTICIPANT_COVERAGE_ID = @PARTICIPANT_COVERAGE_ID)
                                    BEGIN
                                        INSERT INTO dbo.DEPENDENT_COVERAGE ( PARTICIPANT_COVERAGE_ID , COVERED_DEPENDENT_ID ) 
                                        SELECT @PARTICIPANT_COVERAGE_ID, @Participant_Id ;
                                        UPDATE dbo.PARTICIPANT_COVERAGE
                                        SET DEPENDENT_STATUS = 'A', 
                                        DEPENDENT_ERROR = null, 
                                        DEPENDENT_LAST_UPDATED = GetDate()  
                                        WHERE PARTICIPANT_COVERAGE_ID = @PARTICIPANT_COVERAGE_ID;
                                    END";
            dictionary.Add("@Participant_Id", participantId ?? "0");
            dictionary.Add("@PARTICIPANT_COVERAGE_ID", coverageId ?? "0");
            coverage.Parameters = dictionary;
            return coverage;
        }
        public static Query InsertCoverageDependent(CoverageMemberModel coverage,  string participantCoverage, string billingStartDate)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"INSERT INTO DEPENDENT_COVERAGE (PARTICIPANT_COVERAGE_ID, COVERED_DEPENDENT_ID, FIXED_PREMIUM, EFFECTIVE_DATE,TERMINATION_DATE) 
                    VALUES (@PARTICIPANT_COVERAGE_ID,@COVERED_DEPENDENT_ID,@FIXED_PREMIUM,@EFFECTIVE_DATE,null)";

            dictionary.Add("@PARTICIPANT_COVERAGE_ID", participantCoverage);
            dictionary.Add("@COVERED_DEPENDENT_ID", coverage.ParticipantId.ToString()!);
            dictionary.Add("@FIXED_PREMIUM", coverage.FixedPremiun ?? "");
            dictionary.Add("@EFFECTIVE_DATE", billingStartDate);

            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query UpdateGroupUpdate(int participantId, GroupUpdateSaveModel tableModel, string newData)
        {
            Query groupUpdate = new();
            Dictionary<string, string> dictionary = new();
            groupUpdate.SelectFrom = $"UPDATE ";
            groupUpdate.SelectFrom += tableModel.TableName!.Trim().ToUpper().ToString() switch
            {
                "Participant" => " PARTICIPANT ",
                _ => " PARTICIPANT ",
            };
            groupUpdate.SelectFrom += tableModel.ColumnName!.ToString() switch
            {
                "STUDENT" => " SET STUDENT= @NewData ",
                "AFFILIATE_ID" => " SET AFFILIATE_ID= @NewData ",
                "HIRE_DATE" => " SET HIRE_DATE= @NewData ",
                "EMPLOYEE_NUMBER" => " SET EMPLOYEE_NUMBER= @NewData ",
                "PHONE_NUMBER" => " SET PHONE_NUMBER= @NewData ",
                "QUALiFIED_BENEFICIARY" => " SET QUALiFIED_BENEFICIARY= @NewData ",
                _ => " SET STUDENT= @NewData ",
            };
            groupUpdate.SelectFrom += @" WHERE PARTICIPANT_ID = @PARTICIPANT_ID";

            dictionary.Add("@NEWDATA", newData!.ToString());
            dictionary.Add("@PARTICIPANT_ID", participantId.ToString());
            groupUpdate.Parameters = dictionary;
            return groupUpdate;
        }
        public static Query UpdateCoverage(AvailablePlansClientResultModel plans, string fixedPremiun, string billingStartDate, string terminationDate)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = "UPDATE PARTICIPANT_COVERAGE SET EFFECTIVE_DATE=EFFECTIVE_DATE,TERMINATION_DATE= @TERMINATION_DATE, FIXED_PREMIUM= CONVERT(money,@FIXED_PREMIUM),,FIXED_PREMIUM_PRIMARY=CONVERT(money,@FIXED_PREMIUM_PRIMARY)";
            dictionary.Add("@EFFECTIVE_DATE", billingStartDate ?? "");
            dictionary.Add("@FIXED_PREMIUM", plans.CoverageRate!.Replace("$", "") ?? "");
            dictionary.Add("@FIXED_PREMIUM_PRIMARY", fixedPremiun);
            dictionary.Add("@TERMINATION_DATE", terminationDate);

         //   pInsert.SelectFrom += " WHERE PARTICPANT_ID=@PARTICIPANT_ID and PLAN_ID=@PLAN_ID and COVERAGE_CODE=@COVERAGE_CODE and and (TERMINATION_DATE is null OR TERMINATION_DATE >=@QEDATE) ";
            pInsert.SelectFrom += " WHERE PARTICIPANT_COVERAGE_ID=@PARTICIPANT_COVERAGE_ID ";

            dictionary.Add("@PARTICIPANT_COVERAGE_ID", (plans.Pcid??0).ToString());
            //dictionary.Add("@PLAN_ID", plans.PlanId.ToString() ?? "");
            //dictionary.Add("@COVERAGE_CODE", plans.CoverageAvailablePlanCode ?? "");
            //dictionary.Add("@QEDATE", qEEventDate);

            pInsert.Parameters = dictionary;
            return pInsert;
        }
    }
}

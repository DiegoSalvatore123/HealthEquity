﻿using Core.Model;
using Core.Util;
namespace DataAccess.Queries
{
    public class ParticipantExecSP
    {
        public static Query InsertRehire(RehireModel rehireModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"exec P433_RehireCOBRAUpdate @ClientID,@NewParticipantID,@Employee_SSN,@HireDate,null,@Result,@UserId,@Debug, @DirectBill";

            dictionary.Add("@ClientID", rehireModel.ClientId);
            dictionary.Add("@NewParticipantID", rehireModel.ParticipantId.ToString());
            dictionary.Add("@Employee_SSN", rehireModel.SSN);
            dictionary.Add("@HireDate", rehireModel.HireDate ?? "");
            dictionary.Add("@Result", "0");
            dictionary.Add("@UserID", rehireModel.UserId);
            dictionary.Add("@DirectBill", rehireModel.DirectBill);
            dictionary.Add("@Debug", rehireModel.Debug);

            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertDependents(DependentOldModel dependentsModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"EXEC [dbo].[MigrateParticipantDependents] @participantID, @userId,@dependentInfo";

            dictionary.Add("@participantID", dependentsModel.ParticipantId.ToString());
            dictionary.Add("@userId", dependentsModel.UserId.ToString());
            dictionary.Add("@dependentInfo", dependentsModel.DependentInfo);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static QueryT UpdateDisability(DisabilityUpdateModel model)
        {
            QueryT pInsert = new();
            var description = "Disability Extension Processed, new Eligibility End Date: " + ((DateTime)model.EligibilityEnd!).ToString("MM/dd/yyy") + ", SSA Ineligibility Determination Date: " + ((DateTime)model.DeterminationDate!).ToString("MM/dd/yyy");
            Dictionary<string, object> dictionary = new();
            pInsert.SelectFrom = @"exec ProcessDisabilityExtension @PaticipantId, @EligibilityEndDate, @Description, @Surcharge, @UserID;";

            dictionary.Add("@PaticipantId", model.ParticipantId!);
            dictionary.Add("@EligibilityEndDate", model.EligibilityEnd!);
            dictionary.Add("@Description", description.ToString());
            dictionary.Add("@Surcharge", model.SurchargePercent!);
            dictionary.Add("@UserID", Convert.ToInt64(model.UserId));
            dictionary.Add("@returnValueParam", "");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertSpecificFields(SpecificFieldsInsertModel specificfields)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"EXEC [participant].[CustomFieldDataSet] @Xml , @UserId";

            dictionary.Add("@UserId", specificfields.UserId.ToString());
            dictionary.Add("@Xml", specificfields.Xml);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query CoveragePlanByClientId(CoveragePlanDataModel coverage)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();

            if (coverage.BillingStartDate.Equals(string.Empty))
                pInsert.SelectFrom = @"EXEC P036_AvailablePlansClient_7_to_12 @QEDate, @Action, @ClientId, @ParticipantId,@AffiliateId,null, ";
            else
                pInsert.SelectFrom = @"EXEC P036_AvailablePlansClient_Web @billingstart ,@Action, @ClientId, @ParticipantId,@AffiliateId,null, ";

            if (coverage.Zip.Trim().Length >= 5 ) 
             {
                pInsert.SelectFrom += "@Zip3,@Zip5,";
                dictionary.Add("@Zip3", coverage.Zip.Trim()[..3]);
                dictionary.Add("@Zip5", coverage.Zip.Trim()[..5]);
             }
            else
                pInsert.SelectFrom += "null,null,";
            if (coverage.State.Length == 2) 
            {
                pInsert.SelectFrom += "@State,";
                dictionary.Add("@State", coverage.State);
            }
            else
                pInsert.SelectFrom += "null,";
            pInsert.SelectFrom += "null,0,@QualifiedCode,@DateOfBirth,1,@xml";

            if (coverage.BillingStartDate.Equals(string.Empty))
                dictionary.Add("@QEDate", coverage.QualifyingEventDate); 
            else
                dictionary.Add("@billingstart", coverage.BillingStartDate);
            dictionary.Add("@Action", coverage.Action);
            dictionary.Add("@ClientId", coverage.ClientId);
            dictionary.Add("@ParticipantId", coverage.ParticipantId ?? "");

            //dictionary.Add("@ClientId","123123");
            //dictionary.Add("@ParticipantId", "4533321");

            dictionary.Add("@AffiliateId", coverage.AffiliateId ?? "");
            dictionary.Add("@QualifiedCode", coverage.QualifiedCode ?? "");
            dictionary.Add("@DateOfBirth", coverage.DateOfBirth ?? "");
            dictionary.Add("@xml", coverage.Xml ?? "");

            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query IsFeatureOn(string clientId)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"exec client.CheckFeature @ClientID,@PlanLevelSubsidy,@IsFeatureOn OUTPUT";
            dictionary.Add("@ClientID", clientId);
            dictionary.Add("@PlanLevelSubsidy", "PlanLevelSubsidy");
            dictionary.Add("@IsFeatureOn", "0");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query GetBillingDetail(string participantId)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = " Exec P913_ParticipantBillingDetail @PaticipantId ,0,@ErrorCount OUTPUT,1";
            dictionary.Add("@PaticipantId", participantId);
            dictionary.Add("@ErrorCount", "0");
            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query CalculateEligibilityEndDate(int participantId, string qeType, string lDPCC2)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"EXEC P506_CalculateEligibilityEndDate @ParticpantId , @QEType, @LDPCC2, null,2";

            dictionary.Add("@ParticpantId", participantId.ToString());
            dictionary.Add("@QEType", qeType);
            dictionary.Add("@LDPCC2", lDPCC2);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertEventCoverage(InfoSessionModel insertModel)
        {
            Query coerageGetByID = new();
            Dictionary<string, string> dictionary = new();
            if (string.IsNullOrEmpty(insertModel.ProcessQE!.BillingStartDate))
                coerageGetByID.SelectFrom = "Exec P002_CreatePrintEvents @PaticipantId, '53', NULL, @Date, 'CLH02', 'WEB', @Date, NULL, @UserID, NULL, NULL, NULL, @ErrorCount OUTPUT";
            else
            {
                coerageGetByID.SelectFrom = " Exec P002_CreatePrintEvents @PaticipantId, @EventType, NULL, @Date, @FormNumber, 'WEB', @Date, NULL, @UserID, @BillingStartDate, NULL, NULL, @ErrorCount OUTPUT";
                dictionary.Add("@EventType", insertModel.EventType!);
                dictionary.Add("@FormNumber", insertModel.FormNumber!);
                dictionary.Add("@BillingStartDate", insertModel.ProcessQE!.BillingStartDate!);
            }
            dictionary.Add("@PaticipantId", insertModel.ParticipantInfo!.ParticipantId!);
            dictionary.Add("@Date", DateTime.Now.ToShortDateString());
            dictionary.Add("@UserID", insertModel.UserId!);            
            dictionary.Add("@ErrorCount", "0");
            coerageGetByID.Parameters = dictionary;
            return coerageGetByID;
        }
        public static Query InsertPolicy(CoverageMemberModel coverage, string coverageId, string billingStartDate)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            string amount = coverage.Amount!.Replace("$", "").Trim() ?? "";
            decimal value;
            if (Decimal.TryParse(amount, out value))
                amount = Math.Round(value, 2).ToString();
         
            pInsert.SelectFrom = @"EXEC dbo.PolicyCoverageSet @ParticipantCoverageId, @CoveredIndividualId, @PolicyNumber,null, @CoverageAmount,  @StartDate, null, @Delete";
            dictionary.Add("@ParticipantCoverageId", coverageId);
            dictionary.Add("@CoveredIndividualId", coverage.ParticipantId.ToString() ?? "");
            dictionary.Add("@PolicyNumber", coverage.PolicyNumber ?? "");
            dictionary.Add("@CoverageAmount", amount);
            dictionary.Add("@StartDate", billingStartDate);
            dictionary.Add("@Delete", "0");

            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertCoveragePLS(string xml, string userId)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"exec participant.SubsidyPeriodSet @SubsidyData, @UserId";
            dictionary.Add("@SubsidyData", xml);
            dictionary.Add("@UserId", userId);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query UpdateMedicalDent(string participantId, string clientId, string status)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"EXEC P106_UpdateMedicalDental @ParticipantId, @ClientId, @Status";
            dictionary.Add("@ParticipantId", participantId);
            dictionary.Add("@ClientId", clientId);
            dictionary.Add("@Status", status);

            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertCoverageMR(string xml)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"EXEC [dbo].[MLRPostQuotItCoverageLink] @Xml";

            dictionary.Add("@Xml", xml);
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query CreatePrintEvents(QueueAchModel queueAchModel)
        {
            Query pInsert = new();
            Dictionary<string, string> dictionary = new();
            pInsert.SelectFrom = @"exec P002_CreatePrintEvents @lParticipantID,@sEventType,null,@dtmEventDate,@sFormNumber,@sEventSource,@dtmDueDate";
           
            dictionary.Add("@lParticipantID", queueAchModel.ParticipantId);
            dictionary.Add("@sEventType", queueAchModel.EventType);
            dictionary.Add("@dtmEventDate", queueAchModel.EventDate);
            dictionary.Add("@sFormNumber", queueAchModel.FormNumber);
            dictionary.Add("@sEventSource", queueAchModel.EventSource);
            dictionary.Add("@dtmDueDate", queueAchModel.DueDate);
            dictionary.Add("@lUserID", queueAchModel.UserId);
            if (!string.IsNullOrEmpty(queueAchModel.EventDescription))
            {
                pInsert.SelectFrom += ",@EventDescription ";
                dictionary.Add("@EventDescription", queueAchModel.EventDescription);
            }
            else
                pInsert.SelectFrom += ",null ";
            pInsert.SelectFrom += ",@lUserID ";
            if (!string.IsNullOrEmpty(queueAchModel.CouponStartDate))
            {
                pInsert.SelectFrom += ",@CouponStart ";
                dictionary.Add("@CouponStart", queueAchModel.CouponStartDate??"");
            }
            else
                pInsert.SelectFrom += ",null ";
            pInsert.SelectFrom += ",null ";
            if (queueAchModel.OptionValue > 0)
            {
                pInsert.SelectFrom += ",@OptionValue ";
                dictionary.Add("@OptionValue", queueAchModel.OptionValue.ToString() ?? "");
            }
            else
                pInsert.SelectFrom += ",null ";
            pInsert.SelectFrom += ",@ErrorCount ";
            dictionary.Add("@ErrorCount", "0");
            pInsert.Parameters = dictionary;
            return pInsert;
        }
        public static Query InsertDependentCoverage(int participantId)
        {
            Query coerageGetByID = new();
            Dictionary<string, string> dictionary = new();
                coerageGetByID.SelectFrom = " Exec P300_DependentCoverage @PaticipantId";
            dictionary.Add("@PaticipantId", participantId.ToString());
            coerageGetByID.Parameters = dictionary;
            return coerageGetByID;
        }
        public static Query InsertCafePlan(string participantId, string clientID, int planId, string QEDate,string userID)
        {
            Query coerageGetByID = new();
            Dictionary<string, string> dictionary = new();
                coerageGetByID.SelectFrom = "Exec P150_FSACOBRAConversion @PaticipantId, @ClientId, @PlanId, @QEDate, 'CLH02', 'WEB', @Date, 'W',0,0, @UserID, @ErrorCount OUTPUT";
            dictionary.Add("@PaticipantId", participantId);
            dictionary.Add("@ClientId", clientID);
            dictionary.Add("@PlanId", planId.ToString());
            dictionary.Add("@QEDate", QEDate);
            dictionary.Add("@UserID", userID);
            dictionary.Add("@ErrorCount", "0");
            coerageGetByID.Parameters = dictionary;
            return coerageGetByID;
        }
        public static Query MLRPromoted(string participantId, string ldpcc2)
        {
            Query coerageGetByID = new();
            Dictionary<string, string> dictionary = new();
            coerageGetByID.SelectFrom = "Exec MLRProcessPromotedParticipants @PaticipantId, @ldpcc2";
            dictionary.Add("@PaticipantId", participantId);
            dictionary.Add("@ldpcc2", ldpcc2);
            coerageGetByID.Parameters = dictionary;
            return coerageGetByID;
        }
        public static Query GetMLRQuote(string clientID, string qualifyingDate, string planData, string memberData)
        {
            Query mlrQUote = new();
            Dictionary<string, string> dictionary = new();
            mlrQUote.SelectFrom = "Exec MLR_CreateGetQuoteItXmlMessage @ClientID, @QualifyingDate,'', @PlanData, @MemberData, ';,', @GUID ";
            dictionary.Add("@ClientID", clientID);
            dictionary.Add("@QualifyingDate", qualifyingDate);
            dictionary.Add("@PlanData", planData);
            dictionary.Add("@MemberData", memberData);
            dictionary.Add("@GUID", "{00000000-0000-0000-0000-000000000000}");
            mlrQUote.Parameters = dictionary;
            return mlrQUote;
        }
        public static Query EventMLR(string clientID, string userId, string message)
        {
            Query eventMLR = new();
            Dictionary<string, string> dictionary = new();
            eventMLR.SelectFrom = "Exec P952_InsertEvent 'MI',null, @ClientId, 'CM-MR',@message,@UserId";
            dictionary.Add("@ClientID", clientID);
            dictionary.Add("@UserId", userId);
            dictionary.Add("@message", message);
            eventMLR.Parameters = dictionary;
            return eventMLR;
          
        }
    }
}

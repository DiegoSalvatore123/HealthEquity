﻿using Core.Model;
using Core.Util;
using Microsoft.IdentityModel.Abstractions;

namespace DataAccess.Queries
{
    public static class ParticipantSelect
    {
        public static Query SearchByPid(InfoModel searchModel)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = @"SELECT
            case when FORMER_DEPENDENT_ID is not null then 
             ( select parent_participant_id from participant WITH (NOLOCK) where participant_id=p.FORMER_DEPENDENT_ID)
             else
            0
            end parent_participant_id,
CASE
            WHEN @Usertype = 'I' THEN 'Yes'
            ELSE CASE when
                    (SELECT coa.OPTION_VALUE
                    FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
                    WHERE coa.CLIENT_ID = @ClientId
                        AND coa.CLIENT_OPTION_ID = 613) = 2 THEN 'Yes'
                ELSE CASE when
                            (SELECT coa.OPTION_VALUE
                                FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
                                WHERE coa.CLIENT_ID = @ClientId
                                AND coa.CLIENT_OPTION_ID = 613) = 1 and(@Usertype = 'A'
                                                                        OR @Usertype = 'V'
                                                                        OR @Usertype = 'X') THEN 'Yes'
                        ELSE 'No'
                    END
                END
            END DisplayCases,
            P.RELATIONSHIP, 
            isnull(cp.Address_1, '')Address_1,
            isnull(cp.Address_2, '')Address_2,
            isnull(cp.CITY, '')CITY,
              case when Qualifying_Event_Date is null or QUALIFYING_EVENT_TYPE='20' OR QUALIFYING_EVENT_TYPE='' then 1
              else
              0
              end IsProcessQE,
            CASE
            WHEN cp.STATE IS NOT NULL
                AND cp.ZIP IS NOT NULL THEN cp.STATE +', ' + cp.ZIP
            ELSE CASE
                    WHEN cp.STATE IS NOT NULL
                            AND cp.ZIP IS NULL THEN cp.CITY
                    ELSE CASE
                                WHEN cp.STATE IS NULL
                                    AND cp.ZIP IS NOT NULL THEN cp.ZIP
                                ELSE ''
                            END
                END
            END StateZip,
            cp.STATE,
            cp.ZIP,
            p.PARTICIPANT_ID,
            isnull(p.EMPLOYEE_CLASS_ID,'') EMPLOYEE_CLASS_ID,
            isnull(p.AFFILIATE_ID,'')AFFILIATE_ID,
            p.FIRST_NAME,
            p.LAST_NAME,
            (select EMPLOYER_NAME from  CLIENT cl WITH (NOLOCK) where CLIENT_ID =@ClientId )EMPLOYER_NAME,
            p.MIDDLE_INITIAL,
            p.GENDER,
            lgen.lookup_description AS lgen_descr,
            p.SOCIAL_SECURITY_NUMBER,
            isnull(p.EMPLOYEE_NUMBER, 'Not Assigned') EMPLOYEE_NUMBER,
            isnull(convert(varchar(10), p.HIRE_DATE, 101), '') HIRE_DATE,
            isnull(convert(varchar(10), p.BIRTH_DATE, 101), '') BIRTH_DATE,
            CASE
            WHEN p.cancellation_effective_date IS NOT NULL THEN convert(varchar(10), p.cancellation_effective_date, 101)
            ELSE CASE
                    WHEN p.PAID_THRU_DATE IS NOT NULL THEN convert(varchar(10), p.PAID_THRU_DATE, 101)
                    ELSE CASE
                                WHEN p.ELIGIBILITY_START_DATE IS NOT NULL THEN convert(varchar(10), dateadd(dd, 1, p.ELIGIBILITY_START_DATE), 101)
                                ELSE 'UNKNOWN'
                            END
                END
            END cancellation_effective_date,
            isnull(p.LAST_NAME, '') +', ' + isnull(p.FIRST_NAME, '') +' ' + isnull(p.MIDDLE_INITIAL, '') Name,
            p.PARTICIPANT_TYPE,
            p.PARTICIPANT_STATUS,
            CAST(p.FORMER_DEPENDENT_ID AS varchar) FORMER_DEPENDENT_ID,case when ELIGIBLE='' then 'N' else 'Y' end ELIGIBLE,
            isnull(convert(varchar(10), p.ELIGIBILITY_START_DATE, 101), '') ELIGIBILITY_START_DATE,
            isnull(convert(varchar(10), p.ELIGIBILITY_END_DATE, 101), '') ELIGIBILITY_END_DATE,
            isnull(convert(varchar(10), p.ELECTION_DATE, 101), '') ELECTION_DATE,
            p.COBRA_STATUS,
            isnull(convert(varchar(10), p.ELECTION_EXPIRATION_DATE, 101), '') ELECTION_EXPIRATION_DATE,
            isnull(convert(varchar(10), p.SEVERANCE_THROUGH, 101), 'none')SEVERANCE_THROUGH,
            (select EIN from CLIENT cl WITH (NOLOCK) where CLIENT_ID =@ClientId )EIN,
            a.AFFILIATE_NAME,
            p.QUALIFYING_EVENT_TYPE,
            isnull(convert(varchar(10), p.QUALIFYING_EVENT_DATE, 101), '') QUALIFYING_EVENT_DATE,
            isnull(convert(varchar(10), p.WAITING_START_DATE, 101), '') WAITING_START_DATE,
            isnull(convert(varchar(10), p.COVERAGE_START_DATE, 101), '') COVERAGE_START_DATE,
            isnull(convert(varchar(10), p.LAST_PRECOBRA_COVERED_DATE, 101), '') LAST_PRECOBRA_COVERED_DATE,
            p.QUALIFIED_BENEFICIARY,
            isnull(convert(varchar(10), p.BILLING_START_DATE, 101), '') BILLING_START_DATE,
            isnull(p.KEY_EMPLOYEE, 0)KEY_EMPLOYEE,
            isnull(p.SHARE_HOLDER5, 0)SHARE_HOLDER5,
            isnull(p.HIGHLY_COMP_MFSA, 0)HIGHLY_COMP_MFSA,
            isnull(p.HIGHLY_COMP_POP, 0)HIGHLY_COMP_POP,
            isnull(p.SALARY_UNDER_25K, 0)SALARY_UNDER_25K,
            p.PAY_SCHEDULE_ID,
            isnull(p.PHONE_NUMBER, '') PHONE_NUMBER,
            p.PREFERRED_LANGUAGE,
            isnull(ec.CLASS_NAME, 'Not Assigned') CLASS_NAME,
            isnull(convert(varchar(10), p.PAID_THRU_DATE, 101), '') PAID_THRU_DATE,
            isnull(l.LOOKUP_DESCRIPTION, 'Standard - Mail Check') AS PayPolicy,
            p.NOTICE_HOLD,
            ssnmask.LabelValue,
            ssnmask.DisplayValue,
            ssnmask.ClientOptionValue,
            isnull(l2.LOOKUP_DESCRIPTION, 'Manual, See Cases') AS NoticeHoldReason,
           (Select isnull(la.LANGUAGE_NAME, 'UNKNOWN') from LANGUAGES la WITH (NOLOCK) where la.LANGUAGE_CODE = isnull(p.PREFERRED_LANGUAGE, (select DEFAULT_PREFERRED_LANGUAGE from CLIENT cl WITH (NOLOCK) where CLIENT_ID =@ClientId)))AS LANGUAGE_NAME,
            isnull(p.EMAIL_ADDRESS, 'Not Provided')EMAIL_ADDRESS,
            CASE
            WHEN p.PARTICIPANT_STATUS ='V' THEN 'VOID'
            ELSE CASE
                    WHEN p.PARTICIPANT_STATUS ='X' THEN 'Cancelled'
                    ELSE CASE
                                WHEN PARTICIPANT_TYPE ='B' THEN 'Direct Bill Participant'
                                ELSE CASE
                                        WHEN Eligibility_Start_Date IS NULL THEN 'Employee'
                                        ELSE CASE
                                                WHEN Billing_Start_Date IS NOT NULL
                                                    AND former_dependent_id IS NULL THEN 'Takeover Continuant'
                                                ELSE CASE
                                                        WHEN Election_Date IS NULL THEN 'Continuation Pending'
                                                        ELSE 'Continuing COBRA'
                                                    END
                                            END
                                    END
                            END
                END
            END 'Status' ,
        CASE WHEN p.Participant_status = 'X' THEN 'X'
                ELSE CASE
                        WHEN p.Participant_type = 'B' THEN 'B'
                        ELSE CASE
                                    WHEN p.ELIGIBILITY_START_DATE IS NULL THEN 'E'
                                    ELSE CASE
                                            WHEN p.BILLING_START_DATE IS NOT NULL
                                                AND p.FORMER_DEPENDENT_ID IS NULL THEN 'C'
                                            ELSE 'A'
                                        END
                                END
                    END
            END AS StatusCode,
            isnull(
                    (SELECT LOOKUP_DESCRIPTION
                        FROM LOOKUP WITH (NOLOCK)
                        WHERE LOOKUP_TBL='PARTICIPANT'
                        AND LOOKUP_COL='QUALIFIED_BENEFICIARY'
                        AND LOOKUP_CODE = p.QUALIFIED_BENEFICIARY),'Unknown')LOOKUP_DESCRIPTION ,

            (SELECT coa.OPTION_VALUE
            FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
            WHERE coa.CLIENT_ID = @ClientId
            AND coa.CLIENT_OPTION_ID = 709 ) AS OptionValue ,
            isnull(
                    (SELECT EVENT_NAME
                        FROM QUALIFYING_EVENTS WITH (NOLOCK)
                        WHERE CODE=p.QUALIFYING_EVENT_TYPE),'')EVENT_NAME ,
            CASE
                WHEN EXISTS
                        (SELECT *
                        FROM Participant_Option op With(Nolock)
                        WHERE PID = P.PARTICIPANT_ID) THEN 'Yes'
                ELSE 'No'
            END AS Medicare_Eligible
            ,CASE WHEN COA.CLIENT_ID IS NULL THEN 0 ELSE 1 END Option441
            ,Case when (p.Participant_type='B' or p.BILLING_START_DATE IS NOT NULL) and (p.FORMER_DEPENDENT_ID IS NULL OR p.ELECTION_DATE IS NOT NULL) then
					case when p.Participant_type='B' and (SELECT coa.OPTION_VALUE
						FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
						WHERE coa.CLIENT_ID = @ClientId
						AND coa.CLIENT_OPTION_ID = 427 ) in(1,2)
						then 
							1
						else
							case when ((p.BILLING_START_DATE IS NOT NULL and p.FORMER_DEPENDENT_ID IS NULL) OR p.ELECTION_DATE IS NOT NULL) and
							(SELECT coa.OPTION_VALUE
							FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
							WHERE coa.CLIENT_ID = @ClientId
							AND coa.CLIENT_OPTION_ID = 427 ) in(2,3)
							then 
								1
							else
								0
							end
						end
				else
					0
				end
				 ACH2,
                Case when (p.Participant_type='B' or (p.BILLING_START_DATE IS NOT NULL and p.FORMER_DEPENDENT_ID IS NULL) OR p.ELECTION_DATE IS NOT NULL) then
					case when p.Participant_type='B' and (SELECT coa.OPTION_VALUE
						FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
						WHERE coa.CLIENT_ID = @ClientId
						AND coa.CLIENT_OPTION_ID = 427 ) in(1,2)
						then 
							1
						else
							case when ((p.BILLING_START_DATE IS NOT NULL and p.FORMER_DEPENDENT_ID IS NULL) OR p.ELECTION_DATE IS NOT NULL) and
							(SELECT coa.OPTION_VALUE
							FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
							WHERE coa.CLIENT_ID = @ClientId
							AND coa.CLIENT_OPTION_ID = 427 ) in(2,3)
							then 
								1
							else
								0
							end
						end
				else
					0
				end
				 ACH,
				 case when isnull(P.QUALIFYING_EVENT_DATE,'')='' AND P.PARTICIPANT_STATUS ='A' AND P.PARTICIPANT_TYPE!='B' then
				 isnull((select LOOKUP_DESCRIPTION from LOOKUP WITH (NOLOCK)  where LOOKUP_TBL='PARTICIPANT' and LOOKUP_COL='QUALIFIED_BENEFICIARY' and LOOKUP_CODE = P.Qualified_Beneficiary),'Unknown')
				 end CobraPlanDescription,
                case when isnull(P.QUALIFYING_EVENT_DATE,'')='' AND P.PARTICIPANT_STATUS ='A' AND P.PARTICIPANT_TYPE!='B' then
				 1
                else
                0
				 end IsCobraPlan
            FROM PARTICIPANT p
            LEFT OUTER JOIN AFFILIATE a WITH (NOLOCK) ON p.AFFILIATE_ID = a.AFFILIATE_ID
            LEFT OUTER JOIN CurrentParticipantAddress cp WITH (NOLOCK) ON p.PARTICIPANT_ID = cp.participant_id
            LEFT OUTER JOIN EMPLOYEE_CLASS ec WITH (NOLOCK) ON p.EMPLOYEE_CLASS_ID=ec.EMPLOYEE_CLASS_ID
            LEFT OUTER JOIN LOOKUP l WITH (NOLOCK) ON p.PAYMENT_POLICY=l.LOOKUP_CODE
            AND l.LOOKUP_TBL = 'PARTICIPANT'
            AND l.LOOKUP_COL = 'PAYMENT_POLICY'
            LEFT OUTER JOIN LOOKUP l2 WITH (NOLOCK) ON p.NOTICE_HOLD_REASON=l2.LOOKUP_CODE
            AND l2.LOOKUP_TBL = 'PARTICIPANT'
            AND l2.LOOKUP_COL = 'NOTICE_HOLD_REASON'
            JOIN lookup lgen WITH (nolock) ON p.gender = lgen.lookup_code
            AND lgen.lookup_col = 'gender'
            AND lgen.lookup_tbl = 'Participant'";

            participantGetByID.SelectFrom += " CROSS APPLY [dbo].[SSNMask](p.PARTICIPANT_ID) ssnmask ";
            participantGetByID.SelectFrom += " LEFT JOIN CLIENT_OPTION_ALL COA WITH (NOLOCK) ON COA.CLIENT_OPTION_ID = 441 and COA.CLIENT_ID = P.client_id and COA.OPTION_VALUE = 3 ";
            participantGetByID.SelectFrom += " WHERE P.PARTICIPANT_ID = @PaticipantId ";

            if (Convert.ToBoolean(searchModel.DivisionLevelAccess))
            {
                participantGetByID.SelectFrom += "and (p.AFFILIATE_ID in(select value FROM dbo.Split(@Affiliate,',')) OR p.AFFILIATE_ID is null OR p.PARTICIPANT_STATUS = 'X' )";
                dictionary.Add("@Affiliate", searchModel.AffiliateId);
            }
            dictionary.Add("@Usertype", searchModel.UserType);
            dictionary.Add("@ClientId", searchModel.ClientId);
            dictionary.Add("@PaticipantId", searchModel.ParticipantId);
            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query SearchPlanNameByPid(string participantId)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = @"SELECT 
                DISTINCT isnull(po.plan_name + ' : ' + c.coverage_description, '') AS PlanName
            FROM participant_coverage pc WITH (NOLOCK)
            INNER JOIN participant p WITH (NOLOCK) ON p.participant_id=pc.participant_id
            INNER JOIN coverages c WITH (NOLOCK) ON c.coverage_code = pc.coverage_code
            INNER JOIN plan_option po WITH (NOLOCK) ON po.plan_id = pc.plan_id
            LEFT JOIN lookup l WITH (NOLOCK) ON po.coverage_type = l.lookup_code
                AND l.lookup_tbl = 'PLAN_OPTION'
                AND l.lookup_col = 'COVERAGE_TYPE'
                WHERE pc.participant_id = @PaticipantId and pc.coverage_state = 'Q'
                and pc.effective_date <= p.qualifying_event_date and (pc.termination_date >= p.qualifying_event_date or pc.termination_date is null) ";
            dictionary.Add("@PaticipantId", participantId);
            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query Search(SearchModel searchModel)
        {
            Query participantGetByID = new();
            var haveFirstName = HasValue(searchModel.FirstName);
            var haveLastName = HasValue(searchModel.LastName);
            DateTime searchHireFrom = DateTime.MinValue;
            DateTime searchHireTo = DateTime.MinValue;
            Dictionary<string, string> dictionary = new();
            int pageNumber = ((int.Parse(searchModel.PageNumber) - 1) * int.Parse(searchModel.PageSize));

            participantGetByID.SelectFrom = @";WITH Main_CTE AS( ";
            participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @"SELECT ");
            if (searchModel.ViewOption == "continuing" || searchModel.ViewOption == "directbillPD")
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @" DISTINCT ");
            participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @" CASE WHEN p.Participant_status = 'X' THEN 'X'
                ELSE CASE
                        WHEN p.Participant_type = 'B' THEN 'B'
                        ELSE CASE
                                    WHEN p.ELIGIBILITY_START_DATE IS NULL THEN 'E'
                                    ELSE CASE
                                            WHEN p.BILLING_START_DATE  IS NOT NULL
                                                AND p.FORMER_DEPENDENT_ID IS NULL THEN 'C'
                                            ELSE 'A'
                                        END
                                END
                    END
            END AS Status,
            case when p.Qualifying_Event_Date is null or QUALIFYING_EVENT_TYPE='20' OR QUALIFYING_EVENT_TYPE='' then 1
            else
            0
            end IsProcessQE,
            CASE WHEN p.Participant_type = 'B' THEN '' 
			ELSE  'C' 
            END as StatusDB,
             isnull(DATEDIFF(year,p.HIRE_DATE, getdate()),0) AS AddDB,
            CASE WHEN p.Participant_status = 'X' THEN 'Cancelled' 
            ELSE CASE WHEN p.Participant_type = 'B' THEN 'Direct Bill Participant' 
            ELSE CASE WHEN p.ELIGIBILITY_START_DATE is null THEN 'Employee'
            ELSE CASE WHEN p.BILLING_START_DATE  IS NOT NULL and p.FORMER_DEPENDENT_ID is null THEN 'Takeover Continuant' 
            ELSE CASE WHEN p.ELECTION_DATE is null THEN 'Continuation Pending' 
            ELSE 'Elected COBRA'
            END
            END END END END as StatusDescription,
            CASE WHEN p.Participant_status = 'X' THEN 'Cancelled' 
            ELSE CASE WHEN p.Participant_type = 'B' THEN 'Direct Bill Participant' 
            ELSE CASE WHEN p.ELIGIBILITY_START_DATE is null THEN 'Employee'
            ELSE CASE WHEN p.BILLING_START_DATE  IS NOT NULL and p.FORMER_DEPENDENT_ID is null THEN 'Takeover Continuant' 
            ELSE CASE WHEN p.ELECTION_DATE is null THEN 'Awaiting Election' 
            ELSE 'Elected COBRA'
            END
            END END END END as StatusDescriptionDB,
            (SELECT LabelValue
            FROM SSNMask (p.PARTICIPANT_ID)) AS LabelValue, isnull(DATEDIFF(YEAR, p.HIRE_DATE, getdate()), 0) YearDifference,
            (SELECT coa.OPTION_VALUE
            FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
            WHERE coa.CLIENT_ID = @ClientId
                AND coa.CLIENT_OPTION_ID = 613 ) AS ClientOptionValue,
            (SELECT DisplayValue
            FROM SSNMask (p.PARTICIPANT_ID)) AS DisplayValue,
                p.PARTICIPANT_ID,
                p.PARENT_PARTICIPANT_ID,
                p.RELATIONSHIP,
                p.FIRST_PAYMENT_DATE,
                p.COBRA_STATUS,
                p.QUALIFYING_EVENT_TYPE,
                p.QUALIFYING_EVENT_DATE,
                p.FIRST_NAME,
                p.LAST_NAME,
                p.SOCIAL_SECURITY_NUMBER,
                p.HIRE_DATE,
                case when p.HIRE_DATE is not null then convert(varchar(10), p.HIRE_DATE, 101)
                else case when p.Participant_type ='B' then 'Former Dependent'
                else 'Dependent'
                end 
                end HireDateDescription,
                p.Participant_type,
                p.PARTICIPANT_STATUS,
                p.FORMER_DEPENDENT_ID,
                p.ELIGIBILITY_START_DATE,
                p.ELECTION_DATE,
                p.BILLING_START_DATE,
                p.AFFILIATE_ID,
                a.AFFILIATE_NAME ");
            if (string.IsNullOrEmpty(searchModel.ViewOption) || (searchModel.ViewOption != "continuing" && searchModel.ViewOption != "directbillPD"))
            {
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @" FROM PARTICIPANT p WITH (NOLOCK)
                INNER JOIN CLIENT cl WITH (NOLOCK) ON p.client_id = cl.client_id
                LEFT OUTER JOIN AFFILIATE a WITH (NOLOCK) ON p.affiliate_id = a.affiliate_id");
            }
            else
            if (searchModel.ViewOption == "continuing")
            {
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @" FROM EligibilityStatusNew es WITH (NOLOCK)
                inner join participant p WITH (NOLOCK) on p.participant_id = es.participant_id
                left outer join AFFILIATE a WITH (NOLOCK) on p.affiliate_id = a.affiliate_id");
            }
            else
            {
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, @" FROM PARTICIPANT p WITH (NOLOCK)
                INNER JOIN CLIENT cl WITH (NOLOCK) ON p.client_id = cl.client_id
                inner join Participant_Billing_New pb WITH (NOLOCK) on p.PARTICIPANT_ID = pb.PARTICIPANT_ID 
                inner join LOOKUP l WITH (NOLOCK) on l.LOOKUP_CODE = pb.STATUS
                LEFT OUTER JOIN AFFILIATE a WITH (NOLOCK) ON p.affiliate_id = a.affiliate_id");
            }
            if (HasValue(searchModel.ImageName))
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " inner join DOC_IMAGE di WITH(NOLOCK) on di.PARTICIPANT_ID = p.PARTICIPANT_ID ");
            if (HasValue(searchModel.DocumentId))
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " inner join DOC_QUEUE dq WITH(NOLOCK) on dq.PARTICIPANT_ID = p.PARTICIPANT_ID ");
            participantGetByID.SelectFrom += searchModel.ViewOption switch
            {
                "ineligible" => " WHERE p.participant_status='A' and p.participant_type not in ('B') and (p.eligible='N' or p.eligible='n') and cl.client_id = @ClientId ",
                "eligiblenoncovered" => @" WHERE p.participant_status='A' and p.participant_type not in ('B') and (p.qualifying_event_type is null OR p.qualifying_event_type = '20') 
                                            and p.parent_participant_id is null 
                                            and (
					                                p.qualified_beneficiary = 'N' 
					                                OR 
					                                (
						                                p.qualified_beneficiary='C' 
						                                and p.participant_id not in (
							                            select pc.participant_id 
							                            from participant_coverage pc WITH (NOLOCK) 
							                            inner join PLAN_OPTION po WITH (NOLOCK) on pc.PLAN_ID=po.PLAN_ID 
							                            where po.coverage_type not in ('Z','add non cobra coverage types here') 
							                            and pc.participant_id=p.participant_id
						                                ) 
					                                ) 
				                                ) 
				                                and cl.client_id = @ClientId ",
                "covered" => @" WHERE p.participant_status='A' and p.participant_type not in ('B') and p.qualifying_event_date is null and p.parent_participant_id is null
                                            and (
					                                p.qualified_beneficiary = 'Y' 
					                                OR 
					                                (
						                                p.qualified_beneficiary='C' 
						                                and p.participant_id in 
                                                        (
							                                select pc.participant_id 
							                                from participant_coverage pc WITH (NOLOCK) 
							                                inner join PLAN_OPTION po WITH (NOLOCK) on pc.PLAN_ID=po.PLAN_ID 
							                                where po.coverage_type not in ('Z') 
							                                and pc.participant_id=p.participant_id
						                                ) 
					                                ) 
				                                ) 
				                                and p.BILLING_START_DATE is null and cl.client_id = @ClientId ",
                "FSAplan" => @" WHERE p.participant_status='A' and p.participant_type not in ('B') and p.parent_participant_id is null
                                           and exists (
				                                select * 
				                                from PARTICIPANT_COVERAGE pc WITH (NOLOCK) 
				                                inner join PLAN_OPTION po WITH (NOLOCK) on po.PLAN_ID=pc.PLAN_ID 
				                                where pc.PARTICIPANT_ID = p.PARTICIPANT_ID 
				                                and po.PLAN_TYPE in ('D','F','T','U','V','K','W') 
				                                and pc.COVERAGE_STATE in ('R','E') 
				                                and p.PARTICIPANT_STATUS != 'V' 
				                                and p.PARTICIPANT_TYPE !='B' 
				                                and pc.EFFECTIVE_DATE <= pc.TERMINATION_DATE 
			                                )  
                                        and cl.client_id = @ClientId ",
                "electing" => @" WHERE p.participant_status='A' and p.participant_type not in ('B') and p.qualifying_event_date is not null and p.QUALIFYING_EVENT_TYPE <> '20'
                                        and p.election_date is null and p.billing_start_date is null and p.parent_participant_id is null
                                        and cl.client_id = @ClientId ",
                "continuing" => @" WHERE p.participant_status='A' and p.participant_type not in ('B') and p.qualifying_event_date is not null and (es.coverage_state='C' or es.coverage_state='E')
                                       and (es.BILLING_START_DATE is not null or es.election_date is not null) and p.parent_participant_id is null
                                        and (es.TERMINATION_DATE is null or es.TERMINATION_DATE > getdate())
                                        and es.client_id = @ClientId ",
                "directbill" => @" WHERE p.participant_status='A' and p.participant_type ='B'
                                            and p.parent_participant_id is null
                                            and cl.client_id = @ClientId ",
                "directbillPD" => @" WHERE p.participant_status='A' and pb.STATUS in ('CP','PD')
                                            and l.LOOKUP_TBL='PARTICIPANT_BILLING' and l.LOOKUP_COL='STATUS' and p.participant_type = 'B' and p.parent_participant_id is null
                                            and cl.client_id = @ClientId ",
                "cancelled60" => @" WHERE p.participant_status='X'
                                            and cl.client_id = @ClientId
                                            and p.parent_participant_id is null
                                            and p.participant_id in 
                                            (
                                                select e.participant_id 
					                            from event e WITH (NOLOCK) 
					                            where e.event_type in ('71','75','06','84','CE') 
					                            and e.participant_id=p.participant_id 
					                            and e.event_date>DateAdd(dy,-60,getdate())
				                            ) 
                                            and cl.client_id = @ClientId ",
                "cancelled" => @" WHERE p.participant_status='X'
                                        and p.parent_participant_id is null
                                        and cl.client_id = @ClientId ",
                _ => " WHERE p.participant_status != 'V' and cl.client_id = @ClientId",
            };

            if (Convert.ToBoolean(searchModel.DivisionLevelAccess))
            {
                participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and (p.AFFILIATE_ID in(select value FROM dbo.Split(@Affiliate,',')))");
                dictionary.Add("@Affiliate", searchModel.AffiliateId);
            }
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", searchModel.PageSize);
            if (searchModel.OptionSearch != "1")
            {
                if (!string.IsNullOrWhiteSpace(searchModel.SSN))
                {
                    string ssn = searchModel.SSN.Trim().Replace("-", "");

                    if (ssn.Length > 3 && ssn.Length <= 5)
                    {
                        ssn = string.Concat(ssn.AsSpan(0, 3), "-", ssn.AsSpan(3, ssn.Length - 3));
                    }
                    else if (ssn.Length > 5)
                    {
                        ssn = string.Concat(ssn.AsSpan(0, 3), "-", string.Concat(ssn.AsSpan(3, 2), "-", ssn.AsSpan(5, ssn.Length - 5)));
                    }

                    if (ssn.Length == 11)
                    {
                        participantGetByID.SelectFrom += " and p.social_security_number = @SSN";
                    }
                    else
                    {
                        participantGetByID.SelectFrom += " and p.social_security_number like @SSN +'%'";
                    }

                    dictionary.Add("@SSN", ssn);
                }
                else if (HasValue(searchModel.EmployeeNumber))
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.employee_number = @EmployeeNumber ");
                    dictionary.Add("@EmployeeNumber", searchModel.EmployeeNumber ?? string.Empty);
                }
                else if (haveFirstName)
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.first_name like + @FirstName +'%'");
                    dictionary.Add("@FirstName", searchModel.FirstName?.Trim() ?? string.Empty);
                    if (haveLastName)
                    {
                        participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.last_name like + @LastName +'%'");
                        dictionary.Add("@LastName", searchModel.LastName?.Trim() ?? string.Empty);
                    }
                }
                else if (!haveFirstName && haveLastName)
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.last_name like + @LastName +'%'");
                    dictionary.Add("@LastName", searchModel.LastName?.Trim() ?? string.Empty);
                }
                else if (HasValue(searchModel.Account))
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.PARTICIPANT_ID = TRY_PARSE(@Account as int)");
                    dictionary.Add("@Account", searchModel.Account?.Trim() ?? string.Empty);
                }
                else if (HasValue(searchModel.DocumentId))
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and dq.DOC_ID = @DocumentId");
                    dictionary.Add("@DocumentId", searchModel.DocumentId?.Trim() ?? string.Empty);
                }
                else if (HasValue(searchModel.ImageName))
                {
                    participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and di.IMAGE_NAME like '%" + searchModel.ImageName?.Trim() + "%'");
                }
                else if (searchModel.HireFrom != null && searchModel.HireFrom != "" || searchModel.HireTo != null && searchModel.HireTo != "")
                {
                    if (searchModel.HireFrom != null && searchModel.HireFrom != "")
                    {
                        if (DateTime.TryParse(searchModel.HireFrom, out searchHireFrom))
                            dictionary.Add("@HireFrom", searchHireFrom.ToShortDateString());
                    }
                    if (searchModel.HireTo != null && searchModel.HireTo != "")
                    {
                        if (DateTime.TryParse(searchModel.HireTo, out searchHireTo))
                            dictionary.Add("@HireTo", searchHireTo.ToShortDateString());
                    }
                    if (searchHireFrom != DateTime.MinValue && searchHireTo != DateTime.MinValue)
                    {
                        participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.hire_date between @HireFrom and @HireTo ");
                    }
                    else if (searchHireFrom != DateTime.MinValue && searchHireTo == DateTime.MinValue)
                    {
                        participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.hire_date>= @HireFrom ");
                    }
                    else if (searchHireFrom == DateTime.MinValue && searchHireTo != DateTime.MinValue)
                    {
                        participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " and p.hire_date<= @HireTo ");
                    }
                }
            }
            participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, ")");
            participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, ", Count_CTE AS (SELECT COUNT(*) AS [TotalCount] FROM Main_CTE ) SELECT * FROM Main_CTE, Count_CTE ");
            participantGetByID.SelectFrom += searchModel.Sort switch
            {
                "SSN_ASC" => " ORDER BY DisplayValue asc",
                "SSN_DESC" => " ORDER BY DisplayValue DESC",
                "LastName_ASC" => " ORDER BY LAST_NAME asc, FIRST_NAME asc",
                "LastName_DESC" => " ORDER BY LAST_NAME DESC, FIRST_NAME asc",
                "FirstName_ASC" => " ORDER BY FIRST_NAME asc",
                "FirstName_DESC" => " ORDER BY FIRST_NAME DESC",
                "Division_ASC" => " ORDER BY AFFILIATE_NAME asc",
                "Division_DESC" => " ORDER BY AFFILIATE_NAME DESC",
                "HireDate_ASC" => " ORDER BY HIRE_DATE asc",
                "HireDate_DESC" => " ORDER BY HIRE_DATE DESC",
                "Status_ASC" => " ORDER BY StatusDescription asc",
                "Status_DESC" => " ORDER BY StatusDescription DESC",
                _ => "ORDER BY LAST_NAME, FIRST_NAME ",
            };

            participantGetByID.SelectFrom = string.Concat(participantGetByID.SelectFrom, " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY");

            dictionary.Add("@ClientId", searchModel.ClientId);

            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query GetSubsidybyPid(string participantId)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = " Exec participant.SubsidyPeriodGet @PaticipantId ,null";
            dictionary.Add("@PaticipantId", participantId);
            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        private static bool HasValue(string? field)
        {
            return !string.IsNullOrWhiteSpace(field);
        }
        public static Query GetActivityByPid(ParticipantIdModel searchModel)
        {
            Query activityByID = new();
            Dictionary<string, string> dictionary = new();
            int pageNumber = ((int.Parse(searchModel.PageNumber) - 1) * int.Parse(searchModel.PageSize));

            activityByID.SelectFrom = @";WITH Main_CTE AS(
      SELECT *
      FROM (
       SELECT 
       LOOKUP_DESCRIPTION,
       isnull(USER_NAME, 'System')USER_NAME,       
       isnull(FORMAT(LOG_DATE, 'MM/dd/yyyy HH:mm:ss tt'), 'System') AS LOG_DATE,  
       isnull(FORMAT(LOG_DATE, 'MM/dd/yyyy HH:mm:ss.fff'), 'System') AS LOGDATE,
       CASE
           WHEN COMMENTS IS NULL THEN 'N/A'
           ELSE CASE
            WHEN CHARINDEX('ABA Routing Number changed', COMMENTS)= 0
                AND CHARINDEX('Bank Account Number changed', COMMENTS)= 0 THEN CASE
                    WHEN CHARINDEX('Direct Bill Participant Added:', COMMENTS)= 0
                            AND CHARINDEX('Participant Added:', COMMENTS)= 0
                            AND CHARINDEX('Employee Added:', COMMENTS)= 0
                            AND CHARINDEX('SSN:', COMMENTS)= 0
                            AND CHARINDEX('Social Security Number Updated FROM', COMMENTS)= 0
                            AND CHARINDEX('Security # changed FROM', COMMENTS)= 0
                            AND CHARINDEX('SS# changed FROM', COMMENTS)= 0
                            AND CHARINDEX('SSN changed FROM', COMMENTS)= 0
                            AND CHARINDEX('Social Security Number Updated', COMMENTS)= 0 THEN COMMENTS
                    ELSE CASE
                            WHEN CHARINDEX('Direct Bill Participant Added:', COMMENTS)> 0 THEN 'Direct Bill Participant ' + cast(@PaticipantId AS varchar(20)) + ' Added'
                            ELSE CASE
                                    WHEN CHARINDEX('Participant Added:', COMMENTS)> 0
                                        OR CHARINDEX('Employee Added:', COMMENTS)> 0 THEN 'Participant ' + cast(@PaticipantId AS varchar(20)) + ' Added'
                                    ELSE CASE
                                            WHEN CHARINDEX('Dependent Updated', COMMENTS)> 0 THEN CASE
                                                    WHEN CHARINDEX('SSN changed FROM', COMMENTS)> 0 THEN Left(COMMENTS, (CHARINDEX('SSN changed FROM', COMMENTS)-3))
                                                    ELSE Replace('Participant' + Replace(Left(COMMENTS, (CHARINDEX('Social Security', COMMENTS) - 1)), 'Dependent', '') + ' - updated SSN', '#', '')
                                                END
                                            ELSE 'Participant ' + cast(@PaticipantId AS varchar(20)) + ' - updated SSN'
                                        END
                                END
                        END
                END
            END
       END COMMENTS
       FROM dbo.Client_Activity WITH(NOLOCK)";
            activityByID.Where = " Where Participant_ID =  @PaticipantId ";
            if (searchModel?.FilterConditions?.Count > 0)
            {
                activityByID.Where += " And ";
                if (searchModel.FilterConditions.ContainsKey("key1"))
                {
                    activityByID.Where += " LOOKUP_DESCRIPTION  like '%" + searchModel.FilterConditions["key1"] + "%' AND";
                    dictionary.Add("@TypeFilter", searchModel.FilterConditions["key1"] ?? string.Empty);
                }
                if (searchModel.FilterConditions.ContainsKey("key2"))
                {
                    activityByID.Where += " LOG_DATE >=  CONVERT(datetime, @StartDateFilter, 120) AND";
                    dictionary.Add("@StartDateFilter", searchModel.FilterConditions["key2"] ?? string.Empty);
                }
                if (searchModel.FilterConditions.ContainsKey("key3"))
                {
                    activityByID.Where += " LOG_DATE <= CONVERT(datetime, CONCAT(@EndDateFilter, ' 23:59:59'), 120)";
                    dictionary.Add("@EndDateFilter", searchModel.FilterConditions["key3"] ?? string.Empty);
                }
                else
                {
                    activityByID.Where = activityByID.Where.TrimEnd()[..(activityByID.Where.Length - 4)];
                }
            }
            activityByID.Where += " ) AS SubQuery )";
            activityByID.SelectFrom += activityByID.Where;

            activityByID.SelectFrom += ", Count_CTE AS (SELECT COUNT(*) AS [TotalCount] FROM Main_CTE) SELECT * FROM Main_CTE, Count_CTE ";
            activityByID.SelectFrom += searchModel?.Sort switch
            {
                "COMMENTS_ASC" => " ORDER BY COMMENTS ASC",
                "COMMENTS_DESC" => " ORDER BY COMMENTS DESC",
                "USER_NAME_ASC" => " ORDER BY USER_NAME ASC",
                "USER_NAME_DESC" => " ORDER BY USER_NAME DESC",
                "LOOKUP_DESCRIPTION_ASC" => " ORDER BY LOOKUP_DESCRIPTION ASC",
                "LOOKUP_DESCRIPTION_DESC" => " ORDER BY LOOKUP_DESCRIPTION DESC",
                "LOG_DATE_ASC" => " ORDER BY CONVERT(DATETIME, LOGDATE, 101) ASC",
                "LOG_DATE_DESC" => " ORDER BY CONVERT(DATETIME, LOGDATE, 101) DESC",
                _ => " ORDER BY CONVERT(DATETIME, LOGDATE, 101) DESC ",
            };
            activityByID.SelectFrom += " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY";
            dictionary.Add("@PaticipantId", searchModel!.ParticipantId);
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", searchModel.PageSize);
            activityByID.Parameters = dictionary;
            return activityByID;
        }
        public static Query GetCarrierRemittanceByPid(ParticipantIdModel searchModel)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            int pageNumber = ((int.Parse(searchModel.PageNumber) - 1) * int.Parse(searchModel.PageSize));

            query.SelectFrom = @";WITH Main_CTE AS(
                                                   SELECT CR.PARTICIPANT_ID, 
                                                   CR.PERIOD_END_DATE AS PERIOD_END_DATE,
                                                   CR.COVERAGE_START_DATE, 
                                                   CR.STATEMENT_PERIOD, 
                                                   CONVERT(VARCHAR, CR.COVERAGE_START_DATE, 101) + ' - ' + CONVERT(VARCHAR, CR.PERIOD_END_DATE, 101) AS COVERAGE_PERIOD, 
                                                   CR.CARRIER_NAME, 
                                                   CR.PLAN_NAME, 
                                                   CR.COVERAGE_DESCRIPTION, 
                                                   CR.AMOUNT AS AMOUNT,
                                                   CR.COMMENTS, 
                                                   CR.FINAL, 
                                                   CR.STATEMENT_ID, 
                                                   P.FIRST_NAME, 
                                                   P.LAST_NAME, 
                                                   P.SOCIAL_SECURITY_NUMBER,
                                                   CASE WHEN CR.FINAL= 1 THEN 'Finalized' ELSE 'OPEN' END AS STATUS_DESCRIPTION
                                            FROM V506_CARRIERREMITTANCE CR WITH (NOLOCK) 
                                            INNER JOIN PARTICIPANT P WITH (NOLOCK) ON CR.PARTICIPANT_ID = P.PARTICIPANT_ID 
                WHERE CR.PARTICIPANT_ID = @PaticipantId AND P.CLIENT_ID = @ClientId 
                )
            , Count_CTE AS (SELECT COUNT(*) AS [TotalCount] FROM Main_CTE ) SELECT * FROM Main_CTE, Count_CTE ";
            query.SelectFrom += searchModel.Sort switch
            {
                "PERIOD_ASC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, PERIOD_END_DATE ASC",
                "PERIOD_DESC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, PERIOD_END_DATE DESC",
                "COVERAGEDESCRIPTION_ASC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, COVERAGE_DESCRIPTION ASC",
                "COVERAGEDESCRIPTION_DESC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, COVERAGE_DESCRIPTION DESC",
                "AMOUNT_ASC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, AMOUNT ASC",
                "AMOUNT_DESC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, AMOUNT DESC",
                "COVERAGEPERIOD_ASC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, COVERAGE_START_DATE ASC",
                "COVERAGEPERIOD_DESC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, COVERAGE_START_DATE DESC",
                "STATUS_ASC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, STATUS_DESCRIPTION ASC",
                "STATUS_DESC" => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, STATUS_DESCRIPTION DESC",
                _ => " ORDER BY CARRIER_NAME DESC, PLAN_NAME DESC, PERIOD_END_DATE ASC ",
            };
            query.SelectFrom += " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY";

            dictionary.Add("@PaticipantId", searchModel.ParticipantId);
            dictionary.Add("@ClientId", searchModel.ClientId);
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", searchModel.PageSize);

            query.Parameters = dictionary;
            return query;
        }
        public static Query GetPaymentHistoryByPid(ParticipantIdModel searchModel)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            int pageNumber = ((int.Parse(searchModel.PageNumber) - 1) * int.Parse(searchModel.PageSize));
            query.SelectFrom = @";WITH Main_CTE AS(
                                                   SELECT PP.PAYMENT_ID, 
                                                          PP.CHECK_NO, 
                                                          PP.AMOUNT AS AMOUNT,
                                                          PP.PAYMENT_TYPE, 
                                                          PP.DOC_IMAGE_ID, 
                                                          PP.POSTMARK_DATE AS POSTMARK_DATE,
                                                          PP.PAYMENT_STATUS, 
                                                          L1.LOOKUP_DESCRIPTION AS PTypeDesc, 
                                                           L2.LOOKUP_DESCRIPTION AS PStatusDesc,
                                                         isnull(FORMAT (sp.period_start_date, 'MMMM, yyyy'),'')period_start_date
                                                   FROM PARTICIPANT_PAYMENT PP WITH (NOLOCK) 
                                                   INNER JOIN LOOKUP L1 WITH (NOLOCK) ON L1.LOOKUP_CODE = PP.PAYMENT_TYPE AND 
                                                                                         L1.LOOKUP_TBL = 'PARTICIPANT_PAYMENT' AND L1.LOOKUP_COL = 'PAYMENT_TYPE'
                                                   INNER JOIN LOOKUP L2 WITH (NOLOCK) ON L2.LOOKUP_CODE = PP.PAYMENT_STATUS AND 
                                                                                         L2.LOOKUP_TBL = 'PARTICIPANT_PAYMENT' AND 
									                                                     L2.LOOKUP_COL = 'PAYMENT_STATUS'
                                                left join event e With(Nolock) on pp.event_id=e.event_id 
                                                Left Join Participant_Payment_Entry ppe With(Nolock) on ppe.ID = pp.Payment_Entry_ID 
                                                left join statement_periods sp With(Nolock) on e.statement_id = sp.statement_id
            WHERE PP.PARTICIPANT_ID =@PaticipantId AND
                                   PP.PAYMENT_STATUS != 'V' 
            ), Count_CTE AS (SELECT COUNT(*) AS [TotalCount] FROM Main_CTE ) SELECT * FROM Main_CTE, Count_CTE ";
            query.SelectFrom += searchModel.Sort switch
            {
                "PAYMENTID_ASC" => " ORDER BY PAYMENT_ID ASC",
                "PAYMENTID_DESC" => " ORDER BY PAYMENT_ID DESC",
                "POSTMARK_ASC" => " ORDER BY POSTMARK_DATE ASC",
                "POSTMARK_DESC" => " ORDER BY POSTMARK_DATE DESC",
                "AMOUNT_ASC" => " ORDER BY AMOUNT ASC",
                "AMOUNT_DESC" => " ORDER BY AMOUNT DESC",
                "CHECKNUMBER_ASC" => " ORDER BY CHECK_NO ASC",
                "CHECKNUMBER_DESC" => " ORDER BY CHECK_NO DESC",
                "PAYMENTTYPE_ASC" => " ORDER BY PTypeDesc ASC",
                "PAYMENTTYPE_DESC" => " ORDER BY PTypeDesc DESC",
                "STATUS_ASC" => " ORDER BY PStatusDesc ASC",
                "STATUS_DESC" => " ORDER BY PStatusDesc DESC",
                "PAYMENTPERIOD_ASC" => " ORDER BY period_start_date ASC",
                "PAYMENTPERIOD_DESC" => " ORDER BY period_start_date DESC",
                _ => " ORDER BY PAYMENT_ID ASC ",
            };
            query.SelectFrom += " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY";

            dictionary.Add("@PaticipantId", searchModel.ParticipantId);
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", searchModel.PageSize);

            query.Parameters = dictionary;
            return query;
        }
        public static Query GetCoverageByPid(string participantId, string sort, string status)
        {
            Query coverageByPid = new();
            Dictionary<string, string> dictionary = new();

            coverageByPid.SelectFrom = @"SELECT pc.PARTICIPANT_ID,
               po.PLAN_NAME,
               po.plan_ID,
               CASE
                   WHEN pc.FIXED_PREMIUM IS NULL
                        OR pc.FIXED_PREMIUM ='' THEN c.COVERAGE_DESCRIPTION
                   ELSE 'Fixed Premium: $' + convert(varchar, cast(pc.FIXED_PREMIUM AS MONEY), 0)
               END COVERAGE_DESCRIPTION,
               pc.PARTICIPANT_COVERAGE_ID,
               ISNULL(CONVERT(VARCHAR(10), PC.EFFECTIVE_DATE, 101), '') AS EFFECTIVE_DATE,
               ISNULL(CONVERT(VARCHAR(10), PC.TERMINATION_DATE, 101), '') AS TERMINATION_DATE,
               pc.FIXED_PREMIUM,
               l.LOOKUP_DESCRIPTION,
              isnull((SELECT CASE COALESCE(mrs.TobaccoUse, '-1')
                          WHEN 0 THEN 'No'
                          WHEN 1 THEN 'Yes'
                          ELSE '-'
                      END AS TobaccoUse
               FROM dbo.MLRDataForCoverageRatesScreen mrs
               INNER JOIN dbo.MemberLevelRatingFactor mr WITH (nolock) ON mrs.PlanID = mr.PlanID
               AND mr.TobaccoUse = 1
               WHERE SubscriberID = @PARTICIPANT_ID
                 AND ((mrs.PlanID = po.plan_ID
                       AND Participant_Coverage_ID IS NULL)
                      AND mrs.PlanID = po.plan_ID
                      OR (Participant_Coverage_ID = pc.PARTICIPANT_COVERAGE_ID
                          AND Relationship = 1))),'-') AS TobaccoUse,
                   CASE
                       WHEN po.COVERAGE_TYPE = 'F'
                            AND po.RATE_TYPE = 'RT'
                            AND EXISTS
                              (SELECT PLAN_ID
                               FROM dbo.PLAN_RATE_TABLE
                               WHERE RATE_TYPE = 'LA'
                                 AND PLAN_ID = po.PLAN_ID) THEN '1'
                       ELSE '0'
                   END AS IsInsurancePlan
                  ,isnull(p.FIRST_NAME, '')+ case when p.MIDDLE_INITIAL is not null then ' '+p.MIDDLE_INITIAL else '' end+' '+isnull(p.LAST_NAME,'')as NAME 
            FROM dbo.PARTICIPANT_COVERAGE pc WITH(NOLOCK)
            INNER JOIN PARTICIPANT P  WITH(NOLOCK) ON pc.PARTICIPANT_ID = p.PARTICIPANT_ID
            INNER JOIN PLAN_OPTION po WITH(NOLOCK) ON po.PLAN_ID = pc.PLAN_ID
            LEFT OUTER JOIN COVERAGES c WITH(NOLOCK) ON c.COVERAGE_CODE = pc.COVERAGE_CODE
            LEFT JOIN LOOKUP l WITH(NOLOCK) ON po.COVERAGE_TYPE = l.LOOKUP_CODE
            AND l.LOOKUP_TBL = 'PLAN_OPTION'
            AND l.LOOKUP_COL = 'COVERAGE_TYPE'
            LEFT JOIN xw.CrosswalkResult cr WITH(NOLOCK) ON cr.ParticipantCoverageId = pc.PARTICIPANT_COVERAGE_ID
            AND cr.MemberId = pc.PARTICIPANT_COVERAGE_ID
            LEFT JOIN xw.CarrierCodeStorage ccs WITH(NOLOCK) ON ccs.CarrierCodeStorageID = cr.CarrierCodeStorageId
            WHERE pc.PARTICIPANT_ID = @PARTICIPANT_ID";
            if (status == "E")
            {
                coverageByPid.SelectFrom += @" and (pc.COVERAGE_STATE = 'Q')
                    and (pc.EFFECTIVE_DATE <= pc.TERMINATION_DATE or pc.TERMINATION_DATE is null) ";
            }
            else
                coverageByPid.SelectFrom += " and pc.COVERAGE_STATE in ('E','C') ";

            coverageByPid.SelectFrom += sort switch
            {
                "PLAN_ASC" => " ORDER BY PLAN_NAME asc",
                "PLAN_DESC" => " ORDER BY PLAN_NAME DESC",
                "LOOKUP_ASC" => " ORDER BY LOOKUP_DESCRIPTION asc",
                "LOOKUP_DESC" => " ORDER BY LOOKUP_DESCRIPTION DESC",
                "COVERAGE_ASC" => " ORDER BY COVERAGE_DESCRIPTION asc",
                "COVERAGE_DESC" => " ORDER BY COVERAGE_DESCRIPTION DESC",
                "EFFECTIVE_ASC" => " ORDER BY EFFECTIVE_DATE asc",
                "EFFECTIVE_DESC" => " ORDER BY EFFECTIVE_DATE DESC",
                "TERMINATION_ASC" => " ORDER BY TERMINATION_DATE asc",
                "TERMINATION_DESC" => " ORDER BY TERMINATION_DATE DESC",
                "TOBACCO_ASC" => " ORDER BY TobaccoUse asc",
                "TOBACCO_DESC" => " ORDER BY TobaccoUse DESC",
                _ => " ORDER BY pc.PARTICIPANT_COVERAGE_ID DESC ",
            };

            dictionary.Add("@PARTICIPANT_ID", participantId);
            coverageByPid.Parameters = dictionary;
            return coverageByPid;
        }
        public static Query GetDependentByParentPid(ParticipantIdModel participant)
        {
            Query dependentByPid = new();
            Dictionary<string, string> dictionary = new();
            dependentByPid.SelectFrom = @"
                                          SELECT  P.PARTICIPANT_ID, 
                                                 P.FIRST_NAME, 
                                                 P.LAST_NAME, 
                                                 (P.LAST_NAME + ', ' + P.FIRST_NAME) AS FULL_NAME, 
                                                 isnull(P.MIDDLE_INITIAL,'')MIDDLE_INITIAL,  
                                                 LTRIM(rtrim(isnull(P.SOCIAL_SECURITY_NUMBER,'')))SOCIAL_SECURITY_NUMBER,  
                                                 ISNULL(CONVERT(VARCHAR(10), P.BIRTH_DATE, 101), '') AS BIRTH_DATE, 
                                                 P.PARTICIPANT_STATUS, 
                                                 P.QUALIFIED_BENEFICIARY, 
                                                 P.STUDENT, 
                                                 P.RELATIONSHIP, 
                                                 ISNULL(L1.LOOKUP_DESCRIPTION, 'Unknown') AS DepRelation, 
                                                 ISNULL(L2.LOOKUP_DESCRIPTION, 'Unknown') AS DepStudent, 
                                                 ISNULL(L3.LOOKUP_DESCRIPTION, 'Unknown') AS DepStatus, 
                                                 (SELECT CASE WHEN EXISTS (SELECT * FROM PARTICIPANT_OPTION OP WITH(NOLOCK) WHERE PID = P.PARTICIPANT_ID) 
                                                             THEN 'Yes' 
                                                             ELSE 'No' 
                                                         END) AS MedicareEligible, 
                                                 CAST(0 AS BIT) AS HasTabaccoReated, 
                                                 P.GENDER,
		                                         CASE P.GENDER WHEN 'F' THEN 'Female' 
                                                               WHEN 'M' THEN 'Male'
                                                               ELSE ''
                                                 END AS GENDER_DESCRIPTION,
                                                  CASE when P.WAITING_START_DATE is null then
									             case when (SELECT hire_date from participant where participant_id=@PARTICIPANT_ID)is null then ''
									             else
									              (SELECT  CONVERT(VARCHAR(10), hire_date, 101) from participant where participant_id=@PARTICIPANT_ID)
									             end 
									             else
									             CONVERT(VARCHAR(10), P.WAITING_START_DATE, 101)
									             end WAITING_START_DATE,
                                                 P.EMPLOYEE_NUMBER,

                                                 ISNULL(CONVERT(VARCHAR(10), P.COVERAGE_START_DATE, 101), '') AS COVERAGE_START_DATE,
                                                 NULL AS DependentDetailModel 
                                          FROM PARTICIPANT P WITH(NOLOCK) 
                                          LEFT OUTER JOIN LOOKUP L1 WITH(NOLOCK) ON P.RELATIONSHIP = L1.LOOKUP_CODE AND L1.LOOKUP_TBL = 'PARTICIPANT' AND L1.LOOKUP_COL = 'RELATIONSHIP' 
                                          LEFT OUTER JOIN LOOKUP L2 WITH(NOLOCK) ON P.STUDENT = L2.LOOKUP_CODE  AND L2.LOOKUP_TBL = 'PARTICIPANT' AND L2.LOOKUP_COL = 'STUDENT' 
                                          LEFT OUTER JOIN LOOKUP L3 WITH(NOLOCK) ON P.PARTICIPANT_STATUS = L3.LOOKUP_CODE AND L3.LOOKUP_TBL = 'PARTICIPANT' AND L3.LOOKUP_COL = 'PARTICIPANT_STATUS' 

                                     WHERE P.PARENT_PARTICIPANT_ID = @PARTICIPANT_ID AND 
                                     P.PARTICIPANT_STATUS != 'V' ";

            dependentByPid.SelectFrom += participant.Sort switch
            {
                "LastName_ASC" => @" ORDER BY LAST_NAME ASC ",
                "LastName_DESC" => @" ORDER BY LAST_NAME DESC ",
                "FirstName_ASC" => @" ORDER BY P.FIRST_NAME ASC ",
                "FirstName_DESC" => @" ORDER BY P.FIRST_NAME DESC ",
                "DateOfBirth_ASC" => @" ORDER BY P.BIRTH_DATE ASC ",
                "DateOfBirth_DESC" => @" ORDER BY P.BIRTH_DATE DESC ",
                "Type_ASC" => @" ORDER BY DepRelation ASC ",
                "Type_DESC" => @" ORDER BY DepRelation DESC ",
                "Student_ASC" => @" ORDER BY DepStudent ASC",
                "Student_DESC" => @" ORDER BY DepStudent DESC",
                "Status_ASC" => @" ORDER BY DepStatus ASC",
                "Status_DESC" => @" ORDER BY DepStatus DESC",
                "CoveredByEligiblePlan_ASC" => @" ORDER BY MedicareEligible ASC ",
                "CoveredByEligiblePlan_DESC" => @" ORDER BY MedicareEligible DESC ",
                _ => @" ORDER BY P.BIRTH_DATE ",
            };

            dictionary.Add("@PARTICIPANT_ID", participant.ParticipantId);
            dependentByPid.Parameters = dictionary;
            return dependentByPid;
        }
        public static Query GetDependentDetailByParentPidAndPid(string parentParticipantId, string participantId)
        {
            Query dependentDetailByPid = new();
            Dictionary<string, string> dictionary = new();

            dependentDetailByPid.SelectFrom = @"SELECT 
            0 AS DependentModelId, 
            PO.PLAN_NAME, 
            COALESCE(DC.PARTICIPANT_COVERAGE_ID, 0) AS COVERAGE_ID, 
            CONVERT(VARCHAR(10), COALESCE(DC.EFFECTIVE_DATE, PC.EFFECTIVE_DATE), 101) AS EFFECTIVE_DATE, 
            CONVERT(VARCHAR(10), COALESCE(DC.TERMINATION_DATE, PC.TERMINATION_DATE), 101) AS TERMINATION_DATE, 
            COALESCE(DC.FIXED_PREMIUM, -1) AS FIXED_PREMIUM, 
            COALESCE(MLRF.TobaccoUse, CONVERT(BIT, 0)) As IsTobaccoRated, 
            CASE COALESCE(CCS.CarrierCode3, '-1') WHEN 0 THEN 'No' WHEN 1 THEN 'Yes' ELSE 'N/A' END AS TobaccoUse, 
            CASE COALESCE(DC.PARTICIPANT_COVERAGE_ID, 0) WHEN 0 
                THEN 'NA' 
                    ELSE CASE COALESCE(DC.FIXED_PREMIUM, -1) WHEN -1 THEN '-' 
                        ELSE FORMAT(COALESCE(DC.FIXED_PREMIUM, -1), 'C') 
                        END 
                END AS RateDescription 
            FROM PARTICIPANT_COVERAGE PC WITH(NOLOCK) 
            INNER JOIN PLAN_OPTION PO WITH(NOLOCK) ON PC.PARTICIPANT_ID = @ParentParticipantId AND (PC.COVERAGE_STATE IN ('E', 'C')) AND PO.PLAN_ID = PC.PLAN_ID 
            INNER JOIN DEPENDENT_COVERAGE DC WITH(NOLOCK) ON PC.PARTICIPANT_COVERAGE_ID = DC.PARTICIPANT_COVERAGE_ID AND DC.COVERED_DEPENDENT_ID = @ParticipantId 
            LEFT JOIN MemberLevelRatingFactor MLRF WITH(NOLOCK) ON MLRF.PlanID = PO.PLAN_ID 
            LEFT JOIN xw.CrosswalkResult CR WITH(NOLOCK) ON CR.ParticipantCoverageId = PC.PARTICIPANT_COVERAGE_ID AND CR.MemberId = DC.COVERED_DEPENDENT_ID 
            LEFT JOIN xw.CarrierCodeStorage CCS WITH(NOLOCK) ON CCS.CarrierCodeStorageID = CR.CarrierCodeStorageId 
            ORDER BY COALESCE(DC.EFFECTIVE_DATE, PC.EFFECTIVE_DATE) DESC, 
                                                       COALESCE(DC.TERMINATION_DATE, PC.TERMINATION_DATE, DATEADD(YEAR, 10, GETDATE())) DESC, 
                                                       1 ASC";

            dictionary.Add("@ParentParticipantId", parentParticipantId);
            dictionary.Add("@ParticipantId", participantId);
            dependentDetailByPid.Parameters = dictionary;
            return dependentDetailByPid;
        }
        public static Query GetDependentAddress(string dependentId)
        {
            Query dependentAddress = new();
            Dictionary<string, string> dictionary = new();
            dependentAddress.SelectFrom = @" SELECT * FROM CurrentParticipantAddress WITH (NOLOCK) 
                                    WHERE Participant_ID = @DependentId ";

            dictionary.Add("@DependentId", dependentId);
            dependentAddress.Parameters = dictionary;
            return dependentAddress;
        }
        public static Query GetDependentInfo(string dependentId, string clientId)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = @"SELECT CASE
            WHEN @Usertype = 'I' THEN 'Yes'
            ELSE CASE when
                    (SELECT coa.OPTION_VALUE
                    FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
                    WHERE coa.CLIENT_ID = @ClientId
                        AND coa.CLIENT_OPTION_ID = 613) = 2 THEN 'Yes'
                ELSE CASE when
                            (SELECT coa.OPTION_VALUE
                                FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
                                WHERE coa.CLIENT_ID = @ClientId
                                AND coa.CLIENT_OPTION_ID = 613) = 1 and(@Usertype = 'A'
                                                                        OR @Usertype = 'V'
                                                                        OR @Usertype = 'X') THEN 'Yes'
                        ELSE 'No'
                    END
                END
            END DisplayCases,
            isnull(cp.Address_1, '')Address_1,
            isnull(cp.Address_2, '')Address_2,
            P.RELATIONSHIP, 
            isnull(cp.CITY, '')CITY,
            1 as  IsProcessQE,
            CASE
            WHEN cp.STATE IS NOT NULL
                AND cp.ZIP IS NOT NULL THEN cp.STATE + ', ' + cp.ZIP
            ELSE CASE
                    WHEN cp.STATE IS NOT NULL
                            AND cp.ZIP IS NULL THEN cp.CITY
                    ELSE CASE
                                WHEN cp.STATE IS NULL
                                    AND cp.ZIP IS NOT NULL THEN cp.ZIP
                                ELSE ''
                            END
                END
            END StateZip,
            isnull(cp.STATE, '')STATE,
            isnull(cp.ZIP, '')ZIP,
            p.PARTICIPANT_ID,
            isnull(p.EMPLOYEE_CLASS_ID, '') EMPLOYEE_CLASS_ID,
            isnull(p.AFFILIATE_ID, '')AFFILIATE_ID,
            p.FIRST_NAME,
            p.LAST_NAME,
            isnull(p.parent_participant_id,0) parent_participant_id,
            cl.EMPLOYER_NAME,
            p.MIDDLE_INITIAL,
            p.GENDER,
            lgen.lookup_description AS lgen_descr,
            p.SOCIAL_SECURITY_NUMBER,
            isnull(p.EMPLOYEE_NUMBER, 'Not Assigned') EMPLOYEE_NUMBER,
            isnull(convert(varchar(10), p.HIRE_DATE, 101), '') HIRE_DATE,
            isnull(convert(varchar(10), p.BIRTH_DATE, 101), '') BIRTH_DATE,
            CASE
            WHEN p.cancellation_effective_date IS NOT NULL THEN convert(varchar(10), p.cancellation_effective_date, 101)
            ELSE CASE
                    WHEN p.PAID_THRU_DATE IS NOT NULL THEN convert(varchar(10), p.PAID_THRU_DATE, 101)
                    ELSE CASE
                                WHEN p.ELIGIBILITY_START_DATE IS NOT NULL THEN convert(varchar(10), dateadd(dd, 1, p.ELIGIBILITY_START_DATE), 101)
                                ELSE 'UNKNOWN'
                            END
                END
            END cancellation_effective_date,
            isnull(p.LAST_NAME, '') +', ' + isnull(p.FIRST_NAME, '') + ' ' + isnull(p.MIDDLE_INITIAL, '') Name,
            p.PARTICIPANT_TYPE,
            p.PARTICIPANT_STATUS,
            CAST(p.FORMER_DEPENDENT_ID AS varchar) FORMER_DEPENDENT_ID,ELIGIBLE,
            isnull(convert(varchar(10), p.ELIGIBILITY_START_DATE, 101), '') ELIGIBILITY_START_DATE,
            isnull(convert(varchar(10), p.ELIGIBILITY_END_DATE, 101), '') ELIGIBILITY_END_DATE,
            isnull(convert(varchar(10), p.ELECTION_DATE, 101), '') ELECTION_DATE,
            p.COBRA_STATUS,
            isnull(convert(varchar(10), p.ELECTION_EXPIRATION_DATE, 101), '') ELECTION_EXPIRATION_DATE,
            isnull(convert(varchar(20), p.SEVERANCE_THROUGH), 'none')SEVERANCE_THROUGH,
            cl.EIN,
            a.AFFILIATE_NAME,
            p.QUALIFYING_EVENT_TYPE,
            isnull(convert(varchar(10), p.QUALIFYING_EVENT_DATE, 101), '') QUALIFYING_EVENT_DATE,
            isnull(convert(varchar(10), p.WAITING_START_DATE, 101), '') WAITING_START_DATE,
            isnull(convert(varchar(10), p.COVERAGE_START_DATE, 101), '') COVERAGE_START_DATE,
            isnull(convert(varchar(10), p.LAST_PRECOBRA_COVERED_DATE, 101), '') LAST_PRECOBRA_COVERED_DATE,
            p.QUALIFIED_BENEFICIARY,
            isnull(convert(varchar(10), p.BILLING_START_DATE, 101), '') BILLING_START_DATE,
            isnull(p.KEY_EMPLOYEE, 0)KEY_EMPLOYEE,
            isnull(p.SHARE_HOLDER5, 0)SHARE_HOLDER5,
            isnull(p.HIGHLY_COMP_MFSA, 0)HIGHLY_COMP_MFSA,
            isnull(p.HIGHLY_COMP_POP, 0)HIGHLY_COMP_POP,
            isnull(p.SALARY_UNDER_25K, 0)SALARY_UNDER_25K,
            p.PAY_SCHEDULE_ID,
            isnull(p.PHONE_NUMBER, '') PHONE_NUMBER,
            p.PREFERRED_LANGUAGE,
            isnull(ec.CLASS_NAME, 'Not Assigned') CLASS_NAME,
            isnull(convert(varchar(10), p.PAID_THRU_DATE, 101), '') PAID_THRU_DATE,
            isnull(l.LOOKUP_DESCRIPTION, 'Standard - Mail Check') AS PayPolicy,
            p.NOTICE_HOLD,
            ssnmask.LabelValue,
            ssnmask.DisplayValue,
            ssnmask.ClientOptionValue,
            isnull(l2.LOOKUP_DESCRIPTION, 'Manual, See Cases') AS NoticeHoldReason,
            isnull(la.LANGUAGE_NAME, 'UNKNOWN') AS LANGUAGE_NAME,
            isnull(p.EMAIL_ADDRESS, 'Not Provided')EMAIL_ADDRESS,
            CASE
            WHEN p.PARTICIPANT_STATUS = 'V' THEN 'VOID'
            ELSE CASE
                    WHEN p.PARTICIPANT_STATUS = 'X' THEN 'Cancelled'
                    ELSE CASE
                                WHEN PARTICIPANT_TYPE = 'B' THEN 'Direct Bill Participant'
                                ELSE CASE
                                        WHEN Eligibility_Start_Date IS NULL THEN 'Employee'
                                        ELSE CASE
                                                WHEN Billing_Start_Date IS NOT NULL
                                                    AND former_dependent_id IS NULL THEN 'Takeover Continuant'
                                                ELSE CASE
                                                        WHEN Election_Date IS NULL THEN 'Continuation Pending'
                                                        ELSE 'Continuing COBRA'
                                                    END
                                            END
                                    END
                            END
                END
            END 'Status' ,
            CASE WHEN p.Participant_status = 'X' THEN 'X'
                ELSE CASE
                        WHEN p.Participant_type = 'B' THEN 'B'
                        ELSE CASE
                                    WHEN p.ELIGIBILITY_START_DATE IS NULL THEN 'E'
                                    ELSE CASE
                                            WHEN p.BILLING_START_DATE  IS NOT NULL
                                                AND p.FORMER_DEPENDENT_ID IS NULL THEN 'C'
                                            ELSE 'A'
                                        END
                                END
                    END
            END AS StatusCode,
            isnull(
                    (SELECT LOOKUP_DESCRIPTION
                        FROM LOOKUP WITH(NOLOCK)
                        WHERE LOOKUP_TBL = 'PARTICIPANT'
                        AND LOOKUP_COL = 'QUALIFIED_BENEFICIARY'
                        AND LOOKUP_CODE = p.QUALIFIED_BENEFICIARY),'Unknown')LOOKUP_DESCRIPTION ,

            (SELECT coa.OPTION_VALUE
            FROM CLIENT_OPTION_ALL coa WITH(NOLOCK)
            WHERE coa.CLIENT_ID = cl.CLIENT_ID
            AND coa.CLIENT_OPTION_ID = 709 ) AS OptionValue,
            isnull(
                    (SELECT EVENT_NAME
                        FROM QUALIFYING_EVENTS WITH(NOLOCK)
                        WHERE CODE = p.QUALIFYING_EVENT_TYPE),'')EVENT_NAME ,
            CASE
                WHEN EXISTS
            (SELECT *
                        FROM Participant_Option op With(Nolock)
                        WHERE PID = P.PARTICIPANT_ID) THEN 'Yes'
                ELSE 'No'
            END AS Medicare_Eligible
            ,CASE WHEN COA.CLIENT_ID IS NULL THEN 0 ELSE 1 END Option441,
            Case when (p.Participant_type='B' or p.BILLING_START_DATE IS NOT NULL) and (p.FORMER_DEPENDENT_ID IS NULL OR p.ELECTION_DATE IS NOT NULL) then
					case when p.Participant_type='B' and (SELECT coa.OPTION_VALUE
						FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
						WHERE coa.CLIENT_ID = @ClientId
						AND coa.CLIENT_OPTION_ID = 427 ) in(1,2)
						then 
							1
						else
							case when ((p.BILLING_START_DATE IS NOT NULL and p.FORMER_DEPENDENT_ID IS NULL) OR p.ELECTION_DATE IS NOT NULL) and
							(SELECT coa.OPTION_VALUE
							FROM CLIENT_OPTION_ALL coa WITH (NOLOCK)
							WHERE coa.CLIENT_ID = @ClientId
							AND coa.CLIENT_OPTION_ID = 427 ) in(2,3)
							then 
								1
							else
								0
							end
						end
				else
					0
				end
				 ACH
            FROM PARTICIPANT p
            LEFT JOIN CLIENT cl WITH(NOLOCK) ON p.CLIENT_ID = cl.CLIENT_ID
            LEFT OUTER JOIN AFFILIATE a WITH(NOLOCK) ON p.AFFILIATE_ID = a.AFFILIATE_ID
            LEFT OUTER JOIN CurrentParticipantAddress cp WITH(NOLOCK) ON p.PARTICIPANT_ID = cp.participant_id
            LEFT OUTER JOIN EMPLOYEE_CLASS ec WITH(NOLOCK) ON p.EMPLOYEE_CLASS_ID = ec.EMPLOYEE_CLASS_ID
            LEFT OUTER JOIN LOOKUP l WITH(NOLOCK) ON p.PAYMENT_POLICY = l.LOOKUP_CODE
            AND l.LOOKUP_TBL = 'PARTICIPANT'
            AND l.LOOKUP_COL = 'PAYMENT_POLICY'
            LEFT OUTER JOIN LOOKUP l2 WITH(NOLOCK) ON p.NOTICE_HOLD_REASON = l2.LOOKUP_CODE
            AND l2.LOOKUP_TBL = 'PARTICIPANT'
            AND l2.LOOKUP_COL = 'NOTICE_HOLD_REASON'
            LEFT OUTER JOIN LANGUAGES la WITH(NOLOCK) ON la.LANGUAGE_CODE = isnull(p.PREFERRED_LANGUAGE, cl.DEFAULT_PREFERRED_LANGUAGE)
            JOIN lookup lgen WITH(nolock) ON p.gender = lgen.lookup_code
            AND lgen.lookup_col = 'gender'
            AND lgen.lookup_tbl = 'Participant'";

            participantGetByID.SelectFrom += " CROSS APPLY [dbo].[SSNMask](p.PARTICIPANT_ID) ssnmask ";
            participantGetByID.SelectFrom += " LEFT JOIN CLIENT_OPTION_ALL COA WITH (NOLOCK) ON COA.CLIENT_OPTION_ID = 441 and COA.CLIENT_ID = P.client_id and COA.OPTION_VALUE = 3 ";
            participantGetByID.SelectFrom += " WHERE P.PARTICIPANT_ID = @PaticipantId ";
            dictionary.Add("@Usertype", "");
            dictionary.Add("@PaticipantId", dependentId);
            dictionary.Add("@ClientId", clientId.ToString());

            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query GetBilling(ParticipantIdModel searchModel)
        {
            Query billingByPid = new();
            int pageNumber = ((int.Parse(searchModel.PageNumber) - 1) * int.Parse(searchModel.PageSize));


            Dictionary<string, string> dictionary = new();
            billingByPid.SelectFrom = @";WITH Main_CTE AS( 
                SELECT 
               CovPeriodDesc,
               isnull(FORMAT(Due_Date, 'MM/dd/yyyy'), '') Due_Date,
			   due_date as DueDate,
               isnull(FORMAT(Deadline_Date, 'MM/dd/yyyy'), '') Deadline_Date,
			   Deadline_Date as DeadlineDate,
               '$' + LTRIM(STR(Amount_Due, 15, 2)) Amount_Due,
               '$' + LTRIM(STR(ER_Sev, 15, 2)) ER_Sev,
               LTRIM(STR(Fed_Sub, 15, 2))Fed_Sub,
               '$' +LTRIM(STR(ER_Paid, 15, 2))ER_Paid,
               '$' +LTRIM(STR(ER_Owed, 15, 2))ER_Owed,
               ER_Status AS ER_CODE,
               ER_Status_Description AS ER_STATUS,
               '$' + LTRIM(STR(Participant_Paid, 15, 2)) Participant_Paid,
               '$' + LTRIM(STR(Participant_Owed, 15, 2)) Participant_Owed,
               EE_Status,
               EE_Status_Description,
               '$' + LTRIM(STR(Paid_Total, 15, 2)) Paid_Total,
               '$' + LTRIM(STR(Admin_Fee, 15, 2)) Admin_Fee,
               '$' + LTRIM(STR(Prorated_Premium, 15, 2)) Prorated_Premium,
               '$' + LTRIM(STR(Monthly_Premium, 15, 2)) Monthly_Premium
            FROM finance.LoadParticipantBillingInfo(@PARTICIPANT_ID)
            ), Count_CTE AS (SELECT COUNT(*) AS [TotalCount] FROM Main_CTE) SELECT * FROM Main_CTE, Count_CTE ";

            billingByPid.SelectFrom += searchModel.Sort switch
            {
                "COV_ASC" => " ORDER BY DueDate asc",
                "COV_DESC" => " ORDER BY DueDate DESC",
                "Amount_ASC" => " ORDER BY Amount_Due asc",
                "Amount_DESC" => " ORDER BY Amount_Due DESC",
                "Due_ASC" => " ORDER BY DueDate asc",
                "Due_DESC" => " ORDER BY DueDate DESC",
                "Deadline_ASC" => " ORDER BY DeadlineDate asc",
                "Deadline_DESC" => " ORDER BY DeadlineDate DESC",
                "Owed_ASC" => " ORDER BY ER_Owed asc",
                "Owed_DESC" => " ORDER BY ER_Owed DESC",
                "Paid_ASC" => " ORDER BY ER_Paid asc",
                "Paid_DESC" => " ORDER BY ER_Paid DESC",
                "Sev_ASC" => " ORDER BY ER_Sev asc",
                "Sev_DESC" => " ORDER BY ER_Sev DESC",
                "Sub_ASC" => " ORDER BY Fed_Sub asc",
                "Sub_DESC" => " ORDER BY Fed_Sub DESC",
                "PPaid_ASC" => " ORDER BY Participant_Paid asc",
                "PPaid_DESC" => " ORDER BY Participant_Paid DESC",
                "POwed_ASC" => " ORDER BY Participant_Owed asc",
                "POwed_DESC" => " ORDER BY Participant_Owed DESC",
                "EFStatus_ASC" => " ORDER BY EE_Status_Description asc",
                "EFStatus_DESC" => " ORDER BY EE_Status_Description DESC",
                "ERStatus_ASC" => " ORDER BY ER_STATUS asc",
                "ERStatus_DESC" => " ORDER BY ER_STATUS DESC",
                _ => " ORDER BY DueDate",
            };

            billingByPid.SelectFrom += " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY";
            dictionary.Add("@PARTICIPANT_ID", searchModel.ParticipantId);
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", searchModel.PageSize);
            billingByPid.Parameters = dictionary;
            return billingByPid;
        }
        public static Query RemoveQEInfo(string participantId)
        {
            Query removeQEInfo = new();
            Dictionary<string, string> dictionary = new();
            removeQEInfo.SelectFrom = @" SELECT SOCIAL_SECURITY_NUMBER
                                              , HIRE_DATE
                                              , PARTICIPANT_TYPE
                                              , QUALIFYING_EVENT_DATE
                                              , FIRST_PAYMENT_DATE 
                                              , PARTICIPANT_ID
                                              , FIRST_NAME
                                              , LAST_NAME
                                              , CASE WHEN QUALIFYING_EVENT_DATE IS NULL 
                                                     THEN 'This participant does not have a processed qualifying event on file.' 
                                                     ELSE CASE WHEN FIRST_PAYMENT_DATE IS NOT NULL
                                                               THEN 'This participant has already had payments processed so the qualifying event cannot be removed.' 
                                                               ELSE ''
                                                          END
                                                END AS ResultDescription
                                              , CONVERT(BIT,  CASE WHEN QUALIFYING_EVENT_DATE IS NULL 
                                                                   THEN 0
                                                                   ELSE CASE WHEN FIRST_PAYMENT_DATE IS NOT NULL
                                                                             THEN 0
                                                                             ELSE 1
                                                                        END
                                                              END) AS Success
                                              , '''' AS ErrorDetails
                                              , CONVERT(BIT, 0) AS DependentError 
                                         FROM PARTICIPANT WITH (NOLOCK) 
                                    WHERE PARTICIPANT_ID = @PaticipantId ";

            dictionary.Add("@PaticipantId", participantId);
            removeQEInfo.Parameters = dictionary;
            return removeQEInfo;
        }
        public static Query RemoveQE(RemoveQEModel removeQEModel)
        {
            Query removeQE = new();
            Dictionary<string, string> dictionary = new();
            removeQE.SelectFrom = " EXEC P875_RemovePartQE @PaticipantId, 2, @Reason, @UserId, @Result OUTPUT ";

            dictionary.Add("@PaticipantId", removeQEModel.ParticipantId);
            dictionary.Add("@Reason", removeQEModel.Reason);
            dictionary.Add("@UserId", removeQEModel.UserId);
            dictionary.Add("@Result", "0");
            removeQE.Parameters = dictionary;
            return removeQE;
        }
        public static Query RemoveQEDetail(RemoveQEModel model)
        {
            Query removeQEDetail = new();
            Dictionary<string, string> dictionary = new();
            removeQEDetail.SelectFrom = @" 
                                           SELECT PARTICIPANT_ID
                                                , SOCIAL_SECURITY_NUMBER
                                                , HIRE_DATE
                                                , PARTICIPANT_TYPE
                                                , QUALIFYING_EVENT_DATE
                                                , FIRST_PAYMENT_DATE
                                                , 'SET TRANSACTION ISOLATION LEVEL READ COMMITTED; 
                                                   SET XACT_ABORT ON; SET NOCOUNT ON; SET ANSI_WARNINGS OFF; 
                                                   SET ARITHABORT ON; 
                                                   BEGIN TRANSACTION SQLCHECK DECLARE @PID INT; DECLARE @PID2 INT; 
                                                   SELECT @PID2 = ' +  CONVERT(VARCHAR(10),  PARTICIPANT_ID) +
                                                 ' SELECT @PID = PARTICIPANT_ID FROM PARTICIPANT WITH (NOLOCK)
                                                   WHERE SOCIAL_SECURITY_NUMBER = ''' + SOCIAL_SECURITY_NUMBER + ''' AND 
                                                   PARTICIPANT_TYPE = ''' + PARTICIPANT_TYPE + ''' AND 
                                                   HIRE_DATE = ''' + CONVERT(VARCHAR, HIRE_DATE, 23) + ''' AND CLIENT_ID = ' + CONVERT(VARCHAR(10),  CLIENT_ID) + ' AND 
                                                   PARTICIPANT_STATUS != ''V'' ORDER BY PARTICIPANT_ID DESC 
                                                   EXEC P875_RemovePartQE @PID, 2, ''" + model.Reason + @"'', ' +
                                                   CONVERT(VARCHAR(10), " + model.UserId + @") + ' COMMIT TRANSACTION SQLCHECK' AS TextMessage
                                           FROM PARTICIPANT WITH (NOLOCK) 
                                      WHERE PARTICIPANT_ID = @ParticipantId  ";

            dictionary.Add("@ParticipantId", model.ParticipantId);
            removeQEDetail.Parameters = dictionary;
            return removeQEDetail;
        }
        public static Query GetSystemSettingByName(string settingName)
        {
            Query systemSetting = new();
            Dictionary<string, string> dictionary = new();
            systemSetting.SelectFrom = @" SELECT SETTING_NAME AS SettingNameId
                                               , EXPLANATION
                                               , SETTING_VALUE
                                               , USED_BY
                                         FROM SYSTEM_SETTINGS WITH (NOLOCK) 
                                    WHERE SETTING_NAME = @SettingName ";

            dictionary.Add("@SettingName", settingName);
            systemSetting.Parameters = dictionary;
            return systemSetting;
        }
        public static Query GetSpecificFieldsByPid(string participantId)
        {
            Query SpecificFieldsByPid = new();
            Dictionary<string, string> dictionary = new();
            SpecificFieldsByPid.SelectFrom = @"SELECT 
               ClientId,
               TPAId,
               ConfigurationLevel,
               ParticipantId,
               CustomFieldId,
               ShowOnWeb,
               ShowOnReports,
               isnull(FieldName,'')FieldName ,
               IntegrationName,
               IsRequired,
               ValidTypeId,
               HasValidation,
               FieldValue,
               0 as HasDomainList ,
               DomainValueCount
            FROM participant.CustomFieldValue with (nolock)
            WHERE ParticipantId = @ParticipantId
            ORDER BY CustomFieldId ";

            dictionary.Add("@ParticipantId", participantId);
            SpecificFieldsByPid.Parameters = dictionary;
            return SpecificFieldsByPid;
        }
        public static Query GetSpecificFieldsByClientId(string clientId)
        {
            Query SpecificFieldsByPid = new();
            Dictionary<string, string> dictionary = new();
            SpecificFieldsByPid.SelectFrom = @"SELECT 
               ClientId,
               CustomFieldId,
               ShowOnWeb,
               ShowOnReports,
               isnull(FieldName,'')FieldName ,
               IntegrationName,
               IsRequired,
               ValidTypeId,
               HasValidation,
               '' as FieldValue,
              case when (select count(*) from client.CustomFieldDomain where client.CustomFieldDomain.customfieldid = client.CustomField.customfieldid) > 0 then 1 else 0 end HasDomainList 
            FROM client.CustomField with (nolock)
            WHERE clientid = @clientid
        ORDER BY CustomFieldId ";

            dictionary.Add("@clientid", clientId);
            SpecificFieldsByPid.Parameters = dictionary;
            return SpecificFieldsByPid;
        }
        public static Query GetCutomFieldsById(int CustomField)
        {
            Query SpecificFieldsByPid = new();
            Dictionary<string, string> dictionary = new();
            SpecificFieldsByPid.SelectFrom = @"SELECT 
               value as DomainValue,
               CustomFieldId,
               isnull(IsDefault, 0) IsDefault
            FROM client.CustomFieldDomain with (nolock)
            WHERE client.CustomFieldDomain.customfieldid = @CustomField
            order by DisplayOrder asc";
            dictionary.Add("@CustomField", CustomField.ToString());
            SpecificFieldsByPid.Parameters = dictionary;
            return SpecificFieldsByPid;
        }
        public static Query GetDivisionLocation(InfoModel searchModel)
        {
            Query DivisionLocations = new();
            Dictionary<string, string> dictionary = new();
            DivisionLocations.SelectFrom = @"SELECT AFFILIATE_ID, AFFILIATE_NAME 
	            FROM AFFILIATE WITH (NOLOCK) 
	            WHERE CLIENT_ID = @ClientId
	            AND AFFILIATE_STATUS = 'A'";
            if (searchModel.DivisionLevelAccess.ToUpper() == "True".ToUpper())
            {
                DivisionLocations.SelectFrom += " and AFFILIATE_ID in (@AffiliateId) ";
                dictionary.Add("@AffiliateId", searchModel.AffiliateId);
            }
            DivisionLocations.SelectFrom += " ORDER BY AFFILIATE_NAME ";
            dictionary.Add("@ClientId", searchModel.ClientId);

            DivisionLocations.Parameters = dictionary;
            return DivisionLocations;
        }
        public static Query GetStates()
        {
            Query states = new()
            {
                SelectFrom = @"SELECT  STATE_CODE, STATE_DESCRIPTION
                               FROM    STATE WITH (NOLOCK) 
                               WHERE   ACTIVE = 'Y' 
                            ORDER BY DISPLAY_ORDER "
            };

            return states;
        }
        public static Query GetRelations()
        {
            Query relations = new()
            {
                SelectFrom = @"SELECT LOOKUP_CODE, LOOKUP_DESCRIPTION
		                        FROM LOOKUP WITH (NOLOCK)
		                        WHERE LOOKUP_TBL='PARTICIPANT'
		                        AND LOOKUP_COL='RELATIONSHIP'
		                        AND ACTIVE='Y'
		                        AND LOOKUP_CODE <> 'E'
                    ORDER BY DISPLAY_ORDER "
            };

            return relations;
        }
        public static Query GetEmployeeClasses(InfoModel searchModel)
        {
            Query EmployeeClasses = new();
            Dictionary<string, string> dictionary = new();
            EmployeeClasses.SelectFrom = @"DECLARE @SQL nvarchar(1000)
                DECLARE @Client NVARCHAR(50) = @ClientId
                DECLARE @CO709 NVARCHAR(50)
                DECLARE @CO709IsNumeric bit
                DECLARE @CO713 NVARCHAR(50)
                DECLARE @CO713IsNumeric bit
                SET @CO709 = (SELECT TOP(1) OPTION_VALUE 
	                from CLIENT_OPTION_ALL WITH (NOLOCK) 
	                where CLIENT_OPTION_ID = 709 
	                and CLIENT_ID = @Client)
                SET @CO709IsNumeric = (SELECT ISNUMERIC(@CO709))
                SET @CO713 = (SELECT TOP(1) OPTION_VALUE 
	                from CLIENT_OPTION_ALL WITH (NOLOCK) 
	                where CLIENT_OPTION_ID = 713 
	                and CLIENT_ID = @Client)
                SET @CO713IsNumeric = (SELECT ISNUMERIC(@CO713))
                IF ( @CO709 IS NULL OR @CO709IsNumeric = 0 )
                BEGIN
                  SET @CO709 = 0
                END
                IF ( @CO713 IS NULL OR @CO713IsNumeric = 0 )
                BEGIN
                  SET @CO713 = 1
                END

                SET @SQL = 'SELECT EMPLOYEE_CLASS_ID, CLASS_NAME 
			                from EMPLOYEE_CLASS WITH (NOLOCK) 
			                where CLASS_STATUS = ''A''
			                AND (CLIENT_ID = ' + @Client 
			                IF( @CO713 = 1 )
			                begin
				                SET @SQL = @SQL + ' OR CLIENT_ID is null'
			                end
			                SET @SQL = @SQL + ')'
                Exec(@SQL)";

            dictionary.Add("@ClientId", searchModel.ClientId);
            EmployeeClasses.Parameters = dictionary;
            return EmployeeClasses;
        }
        public static Query GetFile(DocumentModel documentModel)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @" SELECT DI.DOC_IMAGE_ID
                                                 , DI.PATH
                                                 , DI.EXTENSION
                                                 , CASE DI.EXTENSION WHEN '' THEN 'PDF' 
                                                 	                         WHEN 'FMF' THEN 'TIF'
                                                 		     				 ELSE DI.EXTENSION 
                                                   END AS CURRENTEXTENSION
                                                 , CASE DI.EXTENSION WHEN '' THEN 'PDF' 
                                                 	                         WHEN 'FMF' THEN LTRIM(RTRIM(DI.EXTENSION))
                                                 				    		 ELSE LTRIM(RTRIM(DI.EXTENSION))
                                                   END AS OLDEXTENSION
                                                 , DI.PARTICIPANT_ID
                                                 , DI.CLIENT_ID
                                                 , DI.DOC_IMAGE_TYPE
                                                 , DI.DOC_IMAGE_STATUS
                                                 , DI.NOTATION
                                                 , DI.CL_USER_ID
                                                 , DI.LOG_DATE
                                                 , DI.SECURE_ID
                                                 , DI.EVENT_TYPE
                                                 , DI.EVENT_ID
                                                 , DI.IMAGE_NAME
                                                 , DI.IMAGE_ROUTING
                                                 , DI.TRANS_START_TIME
                                                 , DI.BATCH_ID
                                                 , DI.SESSION_ID
                                                 , DI.PARTNER_CODE 
                                                 , '' AS Base64File
                                            FROM DOC_IMAGE DI WITH (NOLOCK) 
                    WHERE DI.SECURE_ID = @SecureId";

            dictionary.Add("@SecureId", documentModel.SecureId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query SearchBySSNHireDate(ValidateHireDataModel searchModel)
        {
            Query participantGetByID = new();
            Dictionary<string, string> dictionary = new();
            participantGetByID.SelectFrom = @"SELECT participant_id from participant WITH (NOLOCK) 
            where participant_status!='V' and social_security_number=@SSN and hire_date=@HireDate and client_id=@CLIENT_D ";

            dictionary.Add("@SSN", searchModel.SSN);
            dictionary.Add("@HireDate", searchModel.HireDate);
            dictionary.Add("@CLIENT_D", searchModel.ClientId);
            participantGetByID.Parameters = dictionary;
            return participantGetByID;
        }
        public static Query GetAffiliateName(string clientId, string AffiliateName)
        {
            Query DivisionLocations = new();
            Dictionary<string, string> dictionary = new();
            DivisionLocations.SelectFrom = @"SELECT AFFILIATE_ID, AFFILIATE_NAME
	            FROM AFFILIATE WITH (NOLOCK) 
	            WHERE CLIENT_ID = @ClientId
	            AND AFFILIATE_NAME = @AffiliateName";

            dictionary.Add("@ClientId", clientId);
            dictionary.Add("@AffiliateName", AffiliateName);
            DivisionLocations.Parameters = dictionary;
            return DivisionLocations;
        }
        public static Query GetIncludeSCCobraElig(SCCobraEligModel model)
        {
            Query inlcudeSC = new();
            Dictionary<string, string> dictionary = new();
            string where = model.CallingPage switch
            {
                "DepQE" => " ,'07','51','53','63'",
                "DepQEConfirm" => ",'07'",
                "DepQEProcess" => ",'07'",
                "QE" => ",'05','51','53','63' ",
                "QEConfirm" => ",'05'",
                "QEProcess" => ",'05'",
                "TC" => ",'03'",
                "NE" => ",'03','05','07','51','53','63'",
                _ => "",
            };

            if (model.PlatformName != "CXA")
            {
                inlcudeSC.SelectFrom = @"select CobraElig.counter as IncludeCobraElig, SC.counter as IncludeSC from(
             select COUNT(distinct cf.TRANS_CODE) as counter from dbo.CLI_StatementContracts csc WITH (NOLOCK) 
                inner join dbo.Contract_Fee cf on cf.Contract_ID = csc.Contract_ID 
                where csc.CLIENT_ID = @ClientID and csc.Statement_ID in (@Statement, @StatementOne) and cf.TRANS_CODE in ('S2','10'))SC,
                (select  COUNT(distinct cf.TRANS_CODE) as counter from dbo.CLI_StatementContracts csc WITH (NOLOCK)
                inner join dbo.Contract_Fee cf on cf.Contract_ID = csc.Contract_ID 
                inner join lookup l WITH (NOLOCK) on l.lookup_CODE = cf.trans_CODE and l.lookup_tbl = 'contract_fee'
                where csc.CLIENT_ID = @ClientID and csc.Statement_ID in (@Statement, @StatementOne) and left(l.lookup_description,1) in ('D','C','H','M','S' " + where + "))CobraElig";
            }
            else
            {
                inlcudeSC.SelectFrom = @"select CobraElig.counter as IncludeCobraElig, SC.counter as IncludeSC from(
             select COUNT(distinct cf.TRANS_CODE) as counter from dbo.CLI_StatementContracts csc WITH (NOLOCK) 
                inner join dbo.Contract_Fee cf on cf.Contract_ID = csc.Contract_ID  
                where csc.CLIENT_ID = @ClientID and csc.Statement_ID in (@Statement, @StatementOne) and cf.TRANS_CODE in ('S2','10'))SC,
                (select  COUNT(distinct cf.TRANS_CODE) as counter from dbo.CLI_StatementContracts csc WITH (NOLOCK)
                inner join dbo.Contract_Fee cf on cf.Contract_ID = csc.Contract_ID                 
                where csc.CLIENT_ID = @ClientID and csc.Statement_ID in (@Statement, @StatementOne) and cf.TRANS_CODE in ('29','52','Z1','Z2','H1'" + where + "))CobraElig";
            }

            dictionary.Add("@ClientID", model.ClientId);
            dictionary.Add("@Statement", model.Statement);
            dictionary.Add("@StatementOne", (int.Parse(model.Statement) + 1).ToString());
            inlcudeSC.Parameters = dictionary;
            return inlcudeSC;
        }
        public static Query GetCobraHipaaNotice(string clientId)
        {
            Query cobtraHipaa = new();
            Dictionary<string, string> dictionary = new();

            cobtraHipaa.SelectFrom = @"select Cobra.counter as Cobra, Hipaa.counter as Hipaa from
                                (select count(amount)as counter 
 				                                from contract_fee cf WITH (NOLOCK)  
 				                                inner join contract c WITH (NOLOCK) on cf.contract_id = c.contract_id  
 				                                where c.client_id = @ClientID
 				                                and c.EFFECTIVE_DATE <=GetDate()
 				                                and (c.TERMINATION_DATE is null OR c.TERMINATION_DATE >= GetDate())  
 				                                and cf.TRANS_CODE='46')Cobra,
                                (select count(amount)as counter   
 			                                from contract_fee cf WITH (NOLOCK)  
 			                                inner join contract c WITH (NOLOCK) on cf.contract_id = c.contract_id  
 			                                where c.client_id = @ClientID
 			                                and c.EFFECTIVE_DATE <= GetDate()
 			                                and ( c.TERMINATION_DATE is null OR c.TERMINATION_DATE >= GetDate())  
 			                                and cf.TRANS_CODE='47' )Hipaa";
            dictionary.Add("@ClientID", clientId);
            cobtraHipaa.Parameters = dictionary;
            return cobtraHipaa;
        }
        #region VoidParticipant        
        public static Query UpdateParticipant(VoidModel voidModel)
        {
            Query voidParticipantQuery = new();
            Dictionary<string, string> dictionary = new();
            voidParticipantQuery.SelectFrom = " Exec P212_VoidParticipantNew @pid, @reason, @IUserID, @ReturnValue OUTPUT";
            dictionary.Add("@pid", voidModel.ParticipantId.ToString());
            dictionary.Add("@reason", voidModel.Reason ?? string.Empty);
            dictionary.Add("@IUserID", voidModel.UserId);
            dictionary.Add("@ReturnValue", "0");
            voidParticipantQuery.Parameters = dictionary;
            return voidParticipantQuery;
        }
        public static Query CheckIfParticipantFound(VoidModel voidModel)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT p.PARTICIPANT_ID, p.FIRST_NAME, p.LAST_NAME, p.MIDDLE_INITIAL, ssnmask.LabelValue, ssnmask.DisplayValue, ssnmask.ClientOptionValue,
                            p.GENDER, lgen.lookup_description as lgen_descr, p.SOCIAL_SECURITY_NUMBER, p.EMPLOYEE_NUMBER, p.HIRE_DATE,
                            p.BIRTH_DATE, p.PARTICIPANT_TYPE, p.PARTICIPANT_STATUS,  p.cancellation_effective_date,
                            p.FORMER_DEPENDENT_ID, p.ELIGIBILITY_START_DATE, p.ELIGIBILITY_END_DATE,
                            p.ELECTION_DATE, p.COBRA_STATUS, p.ELECTION_EXPIRATION_DATE,
                            p.SEVERANCE_THROUGH, cl.EIN,
                            a.AFFILIATE_NAME, p.QUALIFYING_EVENT_TYPE, p.QUALIFYING_EVENT_DATE,
                            p.WAITING_START_DATE, p.COVERAGE_START_DATE, p.LAST_PRECOBRA_COVERED_DATE,
                            p.QUALIFIED_BENEFICIARY, p.BILLING_START_DATE, p.PHONE_NUMBER,
                            ec.CLASS_NAME, p.PAID_THRU_DATE,
                            isnull(l.LOOKUP_DESCRIPTION, 'Standard - Mail Check') as PayPolicy,
                            p.NOTICE_HOLD,
                            isnull(l2.LOOKUP_DESCRIPTION, 'Manual, See Cases') as NoticeHoldReason,
                            isnull(la.LANGUAGE_NAME, 'UNKNOWN') as LANGUAGE_NAME,
                            p.EMAIL_ADDRESS
                            from PARTICIPANT p
                            inner join CLIENT cl WITH (NOLOCK) on p.CLIENT_ID = cl.CLIENT_ID
                            left outer join AFFILIATE a WITH (NOLOCK) on p.AFFILIATE_ID = a.AFFILIATE_ID
                            left outer join QUALIFYING_EVENTS qe WITH (NOLOCK) on p.QUALIFYING_EVENT_TYPE=qe.CODE
                            left outer join EMPLOYEE_CLASS ec WITH (NOLOCK) on ec.EMPLOYEE_CLASS_ID=p.EMPLOYEE_CLASS_ID
                            left outer join LOOKUP l WITH (NOLOCK) on p.PAYMENT_POLICY=l.LOOKUP_CODE
                            and l.LOOKUP_TBL = 'PARTICIPANT'
                            and l.LOOKUP_COL = 'PAYMENT_POLICY'
                            left outer join LOOKUP l2 WITH (NOLOCK) on p.NOTICE_HOLD_REASON=l2.LOOKUP_CODE
                            and l2.LOOKUP_TBL = 'PARTICIPANT'
                            and l2.LOOKUP_COL = 'NOTICE_HOLD_REASON'
                            left outer join LANGUAGES la WITH (NOLOCK) on la.LANGUAGE_CODE = isnull(p.PREFERRED_LANGUAGE, cl.DEFAULT_PREFERRED_LANGUAGE)
                            join lookup lgen with (nolock) on  p.gender = lgen.lookup_code and lgen.lookup_col = 'gender' and lgen.lookup_tbl = 'Participant'
                            CROSS APPLY [dbo].[SSNMask](p.participant_id) ssnmask
                WHERE p.PARENT_PARTICIPANT_ID is null
                   and cl.CLIENT_ID = @ClientId
                   and PARTICIPANT_ID = @ParticipantId
            ORDER BY p.LAST_NAME, p.FIRST_NAME, p.HIRE_DATE";

            dictionary.Add("@ClientId", voidModel.ClientId);
            dictionary.Add("@ParticipantId", voidModel.ParticipantId.ToString());
            query.Parameters = dictionary;
            return query;
        }
        #endregion
        public static Query GetDependentCoverageByParticipantCoverageIdAndClientId(string participantCoverageId, string clientId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT			p.PARTICIPANT_ID
                                ,				p.SOCIAL_SECURITY_NUMBER
                                ,				p.FIRST_NAME
                                ,				p.LAST_NAME
                                ,               p.Middle_Initial
                                ,				p.BIRTH_DATE
                                ,				ssnmask.LabelValue
                                ,				ssnmask.DisplayValue
                                ,				ssnmask.ClientOptionValue
                                ,				p.PARENT_PARTICIPANT_ID
                                ,				p.RELATIONSHIP
                                ,				p.PARTICIPANT_STATUS
                                ,				p1.QUALIFYING_EVENT_DATE
                                ,				p1.PARTICIPANT_STATUS as PARENT_STATUS
                                ,				l1.LOOKUP_DESCRIPTION as RELATIONSHIP_DESC
                                ,				case when p.RELATIONSHIP in ('R','S','W') then 1 
				                                else 2 
				                                end as ORDERER 
                                from			dbo.DEPENDENT_COVERAGE dc WITH (NOLOCK) 
                                inner join		dbo.PARTICIPANT p WITH (NOLOCK) 
                                on				p.PARTICIPANT_ID = dc.COVERED_DEPENDENT_ID
                                inner join		dbo.PARTICIPANT_COVERAGE pc WITH (NOLOCK) 
                                on				pc.PARTICIPANT_COVERAGE_ID = dc.PARTICIPANT_COVERAGE_ID 
                                inner join		dbo.PARTICIPANT p1 WITH (NOLOCK) 
                                on				p1.PARTICIPANT_ID = pc.PARTICIPANT_ID 
                                inner join		dbo.CLIENT cl WITH (NOLOCK) 
                                on				cl.CLIENT_ID = p1.CLIENT_ID 
                                inner join		dbo.LOOKUP l1 WITH (NOLOCK) 
                                on				l1.LOOKUP_CODE = p.RELATIONSHIP 
                                and				l1.LOOKUP_TBL='PARTICIPANT' 
                                and				l1.LOOKUP_COL='RELATIONSHIP'
                                CROSS APPLY		[dbo].[SSNMask](P.PARTICIPANT_ID) ssnmask
            WHERE   dc.PARTICIPANT_COVERAGE_ID = @PARTICIPANT_COVERAGE_ID AND p1.CLIENT_ID = @CLIENT_ID 
            ORDER by  ORDERER,p.LAST_NAME,p.FIRST_NAME,p.MIDDLE_INITIAL,p.PARTICIPANT_ID ";
            dictionary.Add("@PARTICIPANT_COVERAGE_ID", participantCoverageId);
            dictionary.Add("@CLIENT_ID", clientId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetParticipantCoveragePlanOptionByParticipantCoverageId(string participantCoverageId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"select		po.PLAN_NAME
                                ,			po.PLAN_ID
                                ,			p.FIRST_NAME
                                ,			p.LAST_NAME
                                ,			pc.EFFECTIVE_DATE 
                                from		dbo.PLAN_OPTION po WITH (NOLOCK) 
                                inner join	dbo.PARTICIPANT_COVERAGE pc WITH (NOLOCK) 
                                on			pc.PLAN_ID = po.PLAN_ID 
                                inner join	dbo.PARTICIPANT p WITH (NOLOCK) 
                                on			p.PARTICIPANT_ID = pc.PARTICIPANT_ID 
            WHERE  pc.PARTICIPANT_COVERAGE_ID = @PARTICIPANT_COVERAGE_ID";
            dictionary.Add("@PARTICIPANT_COVERAGE_ID", participantCoverageId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetParticipantInfoByParticipantId(string participantId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT			P.PARTICIPANT_ID
                                ,				P.FIRST_NAME
                                ,				P.LAST_NAME
                                ,				P.SOCIAL_SECURITY_NUMBER
                                ,				ssnmask.LabelValue
                                ,				ssnmask.DisplayValue
                                ,				ssnmask.ClientOptionValue 
                                ,				CASE WHEN COA.CLIENT_ID IS NULL THEN 0 ELSE 1 END Option441
                                FROM			PARTICIPANT P WITH (NOLOCK) 
                                CROSS APPLY		[dbo].[SSNMask](PARTICIPANT_ID) ssnmask 
                                LEFT JOIN		CLIENT_OPTION_ALL COA WITH (NOLOCK) 
                                ON				COA.CLIENT_OPTION_ID = 441 
                                AND				COA.CLIENT_ID = P.client_id 
                                AND				COA.OPTION_VALUE = 3 
                                WHERE PARTICIPANT_ID = @PARTICIPANT_ID ";
            dictionary.Add("@PARTICIPANT_ID", participantId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetParticipantPromoted(string socialSecurityNumber, string formerDependentId, string clientId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT     PARTICIPANT_ID
                                ,           QUALIFYING_EVENT_TYPE
                                FROM PARTICIPANT WITH (NOLOCK)
            WHERE SOCIAL_SECURITY_NUMBER = @SOCIAL_SECURITY_NUMBER AND FORMER_DEPENDENT_ID = @FORMER_DEPENDENT_ID AND CLIENT_ID = @CLIENT_ID AND PARTICIPANT_STATUS <> 'V'";
            dictionary.Add("@SOCIAL_SECURITY_NUMBER", socialSecurityNumber);
            dictionary.Add("@FORMER_DEPENDENT_ID", formerDependentId);
            dictionary.Add("@CLIENT_ID", clientId);
            query.Parameters = dictionary;
            return query;
        }
        public static Query GetEmail(string participantId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @" select rm.DOC_ID, f.DESCRIPTION, 1 as REQUEUE, 'Returned' as DOC_STATUS, 
		            CONVERT(varchar(12),rm.DATE_MAILED,101) as DATE_MAILED, 
		            CONVERT(varchar(12),rm.DATE_RETURNED,101) as DATE_RETURNED 
		            from RETURNED_MAIL rm WITH (NOLOCK) 
		            inner join FORM f WITH (NOLOCK) on f.FORM_ID = rm.FORM_ID 
		            where rm.PARTICIPANT_ID =  @ParticipantId 
		            and f.form_id != 331 
		            and rm.STATUS = 'N' 
		            UNION 
		            select dq.DOC_ID, f.DESCRIPTION, 
		            case when db.DATE_MAILED > DateAdd(dd,-(CONVERT(Integer,IsNull(coa.OPTION_VALUE,'30'))), GetDate()) then 1 
		            else 0 
		            end as REQUEUE, 'Mailed' as DOC_STATUS, CONVERT(varchar(12),db.DATE_MAILED,101) as DATE_MAILED, null 
		            from DOC_QUEUE dq WITH (NOLOCK) 
		            inner join PARTICIPANT p WITH (NOLOCK) on p.PARTICIPANT_ID = dq.PARTICIPANT_ID 
		            inner join CLIENT_OPTION_ALL coa WITH (NOLOCK) on coa.CLIENT_ID = p.CLIENT_ID 
		            and coa.CLIENT_OPTION_ID=805 
		            inner join DOC_BATCH db WITH (NOLOCK) on db.DOC_BATCH_ID=dq.DOC_BATCH_ID 
		            inner join FORM f WITH (NOLOCK) on f.FORM_ID = dq.FORM_ID 
		            where dq.PARTICIPANT_ID =  @ParticipantId 
		            and db.DATE_MAILED > DateAdd(dd,-180, GetDate()) 
		            and f.form_id != 331 
		            and dq.DOC_ID not in (
		            select rm1.DOC_ID 
		            from RETURNED_MAIL rm1 WITH (NOLOCK) 
		            where rm1.DOC_ID = dq.DOC_ID 
		            ) 
		            order by DATE_MAILED desc ";

            dictionary.Add("@ParticipantId", participantId);
            query.Parameters = dictionary;
            return query;
        }

        public static Query SearchDependentBySSN(SearchModel model)
        {
            Query query = new Query();
            Dictionary<string, string> dictionary = new Dictionary<string, string>();

            // Base SQL part
            string sql = @"
            SELECT 
                COALESCE(p.SOCIAL_SECURITY_NUMBER,'') as SOCIAL_SECURITY_NUMBER, 
                ISNULL(p.PARTICIPANT_ID, 0) AS PARTICIPANT_ID, 
                ISNULL(p.PARENT_PARTICIPANT_ID, 0) AS PARENT_PARTICIPANT_ID,
                ISNULL(CONVERT(VARCHAR(10), p.LAST_NAME, 101), '') AS LAST_NAME, 
                ISNULL(CONVERT(VARCHAR(10), p.FIRST_NAME, 101), '') AS FIRST_NAME, 
                COALESCE(p.MIDDLE_INITIAL,'') as MIDDLE_INITIAL, 
                ISNULL(CONVERT(VARCHAR(10), p.STUDENT, 101), '') AS STUDENT,
                ISNULL(CONVERT(VARCHAR(10), p.RELATIONSHIP, 101), '') AS RELATIONSHIP,
                ISNULL(CONVERT(VARCHAR(10), p.PARTICIPANT_STATUS, 101), '') AS PARTICIPANT_STATUS,
                COALESCE((DATEDIFF(m, p.BIRTH_DATE, GETDATE())/12), 0) AS Age,
                ISNULL(CONVERT(VARCHAR(10), p1.BIRTH_DATE, 101), '') AS BIRTH_DATE, 
                ISNULL(CONVERT(VARCHAR(10), p1.LAST_NAME, 101), '') AS LAST_NAME1,
                ISNULL(CONVERT(VARCHAR(10), p1.FIRST_NAME, 101), '') AS FIRST_NAME1,
				ISNULL(CONVERT(VARCHAR(10), p1.QUALIFYING_EVENT_DATE, 101), '') AS QUALIFYING_EVENT_DATE,
                ISNULL(CONVERT(VARCHAR(10), p1.ELIGIBILITY_END_DATE, 101), '') AS ELIGIBILITY_END_DATE,
                ISNULL(p1.AFFILIATE_ID, 0) AS AFFILIATE_ID,
                ISNULL(CONVERT(VARCHAR(10), a.AFFILIATE_NAME, 101), '') AS AFFILIATE_NAME,
                '' as DivisionLevelAccess,
                COALESCE(ssn.LabelValue,'') as LabelValue, 
                COALESCE(ssn.DisplayValue,'') as DisplayValue, 
                COALESCE(ssn.ClientOptionValue,'') as ClientOptionValue
            FROM PARTICIPANT p WITH (NOLOCK) 
            INNER JOIN PARTICIPANT p1 WITH (NOLOCK) ON p.PARENT_PARTICIPANT_ID = p1.PARTICIPANT_ID 
            LEFT OUTER JOIN AFFILIATE a WITH (NOLOCK) on p1.AFFILIATE_ID = a.AFFILIATE_ID 
            CROSS APPLY [dbo].[SSNMask](p.PARTICIPANT_ID) as ssn 
            WHERE p1.CLIENT_ID = @ClientId ";

            if (model.DivisionLevelAccess == "Yes")
            {
                sql += "AND (p1.AFFILIATE_ID IN (@AffiliateString) ";
                if (model.SSN.Length == 11)
                {
                    sql += "OR p1.AFFILIATE_ID IS NULL) ";
                }
                else
                {
                    sql += ") ";
                }
            }

            if (model.OptionSearch == "primary")
            {
                sql += @"AND p1.SOCIAL_SECURITY_NUMBER LIKE '%' + @SsnSearch + '%' ";
            }
            else if (model.OptionSearch == "dependent")
            {
                sql += @"AND p.SOCIAL_SECURITY_NUMBER LIKE '%' + @SsnSearch + '%' ";
            }

            sql += @"
            AND p1.PARTICIPANT_STATUS NOT IN ('X', 'R', 'V') AND 
            p.PARTICIPANT_STATUS = 'A'
            ORDER BY p.LAST_NAME, p.FIRST_NAME, p.MIDDLE_INITIAL, p1.LAST_NAME, p1.FIRST_NAME, p1.MIDDLE_INITIAL";

            query.SelectFrom = sql;
            dictionary.Add("@ClientId", model.ClientId);
            dictionary.Add("@AffiliateString", model.AffiliateId);
            dictionary.Add("@SsnSearch", model.SSN);

            query.Parameters = dictionary;
            return query;
        }


        public static Query GetCoveragesPlans(string participantCoverageId)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            query.SelectFrom = @"SELECT pc.PARTICIPANT_COVERAGE_ID, pci.CoveredIndividualId, 
                 isnull(pt.FIRST_NAME, '')+ ' '+isnull(pt.LAST_NAME,'')as PARTICIPANT_NAME 
                 , pci.CoverageAmount 
                 , pci.PolicyNumber 
                 , pc.PLAN_ID 
                 , po.PLAN_NAME 
                 FROM dbo.PARTICIPANT_COVERAGE pc WITH (NOLOCK) 
                 INNER JOIN dbo.PolicyCoverageInfo pci with (NOLOCK) ON pci.ParticipantCoverageId = pc.PARTICIPANT_COVERAGE_ID
                 INNER JOIN dbo.PARTICIPANT pt WITH (NOLOCK) ON  pt.PARTICIPANT_ID = pci.CoveredIndividualId
                 INNER JOIN PLAN_OPTION po WITH (NOLOCK) on po.PLAN_ID = pc.PLAN_ID 
                 where  pc.PARTICIPANT_COVERAGE_ID  = @PARTICIPANT_COVERAGE_ID  and pc.COVERAGE_STATE in ('E', 'C')
                 ORDER BY PARTICIPANT_NAME ";
            dictionary.Add("@PARTICIPANT_COVERAGE_ID", participantCoverageId);
            
            query.Parameters = dictionary;
            return query;
        }
    }
}

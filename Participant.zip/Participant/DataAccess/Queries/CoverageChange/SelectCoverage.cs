﻿using Core.Util;
using System;
using System.Data.SqlTypes;

namespace DataAccess.Queries.CoverageChange
{
    public static class SelectCoverage
    {
        public static Query GetParticipantCoverageId(int participantId, int planId, string effectiveDate)
        {
            Query coverageId = new();
            Dictionary<string, string> dictionary = new();
            coverageId.SelectFrom = @"SELECT CAST(PARTICIPANT_COVERAGE_ID AS varchar) as Value
		                            FROM PARTICIPANT_COVERAGE
                                WHERE PARTICIPANT_ID = @Participant_Id
		                        AND PLAN_ID = @Plan_Id 
                                AND (TERMINATION_DATE is null OR TERMINATION_DATE >= @Effective_Date)
                                AND EFFECTIVE_DATE <= @Effective_Date";
            dictionary.Add("@Participant_Id", participantId.ToString() ?? "0");
            dictionary.Add("@Plan_Id", planId.ToString() ?? "0");
            dictionary.Add("@Effective_Date", effectiveDate.ToString() ?? "");
            coverageId.Parameters = dictionary;
            return coverageId;
        }
        public static Query GetTerminationDate(int participantId, int planId, string effectiveDate)
        {
            Query effectiveDateQ = new();
            Dictionary<string, string> dictionary = new();

            effectiveDateQ.SelectFrom = @"SELECT
                                            CASE WHEN min(EFFECTIVE_DATE) IS NOT NULL AND min(EFFECTIVE_DATE) <> ''  THEN convert(varchar(10), dateadd(d, -1, min(EFFECTIVE_DATE)), 101)
                                                ELSE '0'
                                            END AS Value
                                        FROM PARTICIPANT_COVERAGE   
                                WHERE PARTICIPANT_ID = @Participant_Id
                                    AND PLAN_ID = @Plan_Id
                                    AND EFFECTIVE_DATE >= @Effective_Date
                                    AND (TERMINATION_DATE >= EFFECTIVE_DATE OR TERMINATION_DATE is null)
                                    AND EFFECTIVE_DATE is not null";            
            dictionary.Add("@Participant_Id", participantId.ToString() ?? "0");
            dictionary.Add("@Plan_Id", planId.ToString() ?? "0");
            dictionary.Add("@Effective_Date", effectiveDate.ToString() ?? "");
            effectiveDateQ.Parameters = dictionary;
            return effectiveDateQ;
        }
        public static Query GetCoverageError(string participantId)
        {
            Query coverageerror = new();
            Dictionary<string, string> dictionary = new();

            coverageerror.SelectFrom = @"select v.participant_coverage_id, v.Dependent_error,v.PLAN_NAME,v.Coverage_description, V.Name
                       from V304_WebDependentExceptions v WITH (NOLOCK) 
                         where v.PARTICIPANT_ID=@Participant_Id";
            dictionary.Add("@Participant_Id", participantId ?? "0");
            coverageerror.Parameters = dictionary;
            return coverageerror;
        }
        public static Query GetCoverageErrorQE(string participantId)
        {
            Query coverageerror = new();
            Dictionary<string, string> dictionary = new();

            coverageerror.SelectFrom = @"select v.participant_coverage_id, v.Dependent_error,v.PLAN_NAME,v.Coverage_description, V.Name
                       from V304_WebDependentExceptionsQE v WITH (NOLOCK) 
                         where v.PARTICIPANT_ID=@Participant_Id";
            dictionary.Add("@Participant_Id", participantId ?? "0");
            coverageerror.Parameters = dictionary;
            return coverageerror;
        }
        public static Query GetMLRQuoteGetRates(string participantId, string planData)
        {
            Query coverage = new();
            string rateWhereSqlMn = "";
            string rateWhereSqlMs = "";

            string where = "";
            Dictionary<string, string> dictionary = new();

            coverage.SelectFrom = @"SELECT PlanId, MemberId, NonSmokerRate, NonSmokerCCSId, SmokerRate, SmokerCCSId    
			FROM    
			(    
				SELECT mn.PlanId, mn.MemberId, mn.Rate As NonSmokerRate, mn.CarrierCodeStorageId As NonSmokerCCSId, ms.Rate As SmokerRate, ms.CarrierCodeStorageId As SmokerCCSId    
				FROM MemberLevelRatingParticipantRateInfo mn with (nolock)   
					LEFT JOIN MemberLevelRatingParticipantRateInfo ms   with (nolock)    
						ON mn.SubscriberId = ms.SubscriberId AND mn.MemberId = ms.MemberId AND mn.PlanId = ms.PlanId AND mn.EffectiveDate = ms.EffectiveDate AND ms.TobaccoUse = 1    
				WHERE    
		 	 	(mn.SubscriberId =  @mlrParentParticipantId ) AND
				(mn.TobaccoUse = 0)    
			 	AND (@WHERECLAUSEN)    
			              AND (mn.EndDate >= getdate() OR mn.enddate IS NULL)     
			UNION    
				SELECT ms.PlanId, ms.MemberId, mn.Rate As NonSmokerRate, mn.CarrierCodeStorageId As NonSmokerCCSId, ms.Rate As SmokerRate, ms.CarrierCodeStorageId As SmokerCCSId    
			 FROM MemberLevelRatingParticipantRateInfo ms  with (nolock)     
				  LEFT JOIN MemberLevelRatingParticipantRateInfo mn  with (nolock)   
					  ON mn.SubscriberId = ms.SubscriberId AND mn.MemberId = ms.MemberId AND mn.PlanId = ms.PlanId AND mn.EffectiveDate = ms.EffectiveDate AND mn.TobaccoUse = 0    
				WHERE    
			 	(ms.SubscriberId = @mlrParentParticipantId) AND
				(ms.TobaccoUse = 1)    
				 	AND (@WHERECLAUSES)    
			         AND ( mn.EndDate >= getdate() OR mn.enddate IS NULL)      
			) m ";
            var planMemberArray=planData.Split('|');
            foreach (var iIdx in planMemberArray)
            {
                where = " ((mn.PlanId = " + iIdx.Split(';')[0].Split('~')[0] + ") And (mn.MemberId IN (" + iIdx.Split(';')[1] + "))) ";
                rateWhereSqlMn = string.Concat(rateWhereSqlMn, string.Format("{0}{1}", rateWhereSqlMn == String.Empty ? "" : " OR ", where));
                //rateWhereSqlMn += rateWhereSqlMn != "" ? " OR " : "";
                //rateWhereSqlMn += " ((pfx.PlanId = " + iIdx.Split(';')[0].Split('~')[0] + ") And (pfx.MemberId IN (" + iIdx.Split(';')[1] + "))) ";
            }
            rateWhereSqlMs = rateWhereSqlMn.Replace("mn.", "ms.");
            dictionary.Add("@mlrParentParticipantId", participantId ?? "0");
            dictionary.Add("@WHERECLAUSEN", rateWhereSqlMn ?? "");
            dictionary.Add("@WHERECLAUSES", rateWhereSqlMs ?? "");

            coverage.Parameters = dictionary;
            return coverage;
        }
        public static Query GetMLRQuoteGetNewRates(string mlrGuids)
        {
            Query newRates = new();
            int i = 0;
            string where = "";
            Dictionary<string, string> dictionary = new();
            var allGuid = mlrGuids.Split(',');
            foreach (string ProcessIdentifier in allGuid)
            {
                dictionary.Add("@mlrGuids" + i, ProcessIdentifier);
                where += i > 0 ? "," : "";
                where += " CAST(CAST(@mlrGuids" + i + " as char(36)) as uniqueidentifier) ";
                i++;
            }
            newRates.SelectFrom = @"SELECT
                Response.Member.value('./MemberId[1]', 'int') AS MemberId,
                Response.Member.value('../../PlanId[1]', 'int') AS PlanId,
                Response.Member.value('./SRate[1]', 'decimal(10,2)') AS Rate,
                ccs.CarrierCodeStorageID AS CCSId
            FROM (
                SELECT t1.XmlPayload AS RequestXml, t2.XmlPayload AS ResponseXml
                FROM MLRQuotitData t1
                INNER JOIN MLRQuotitData t2 ON t1.ProcessIdentifier IN (" + where;
     
            newRates.SelectFrom += @")
                    AND t2.ProcessIdentifier = t1.ProcessIdentifier
                    AND t1.TypeId = 6 AND t2.TypeId = 5
                    AND t1.APICallResult = 1 AND t2.APICallResult = 1
            ) AS QuotitXml
            CROSS APPLY QuotitXml.RequestXml.nodes('/Inputs/Family/Members/Member') AS Request(Member)
            CROSS APPLY Request.Member.nodes('./MemberPlans/MemberPlan') AS Req(Plans)
            CROSS APPLY QuotitXml.ResponseXml.nodes('/GetCustomProductsQuoteResponse/CustomProductsQuote/FamilyQuotes/FamilyQuote/Carriers/Carrier/PlanRates/PlanRate/MemberRates/MemberRate') AS Response(Member)
            LEFT JOIN dbo.County c ON (c.State = QuotitXml.RequestXml.value('/Inputs[1]/ClientState[1]', 'varchar(2)'))
                AND (COALESCE(LEFT('000', 3-LEN(RTRIM(c.CountyFIPS)))+RTRIM(c.CountyFIPS), 'N/A') = QuotitXml.RequestXml.value('/Inputs[1]/ClientCountyFIPS[1]', 'varchar(5)'))
            INNER JOIN xw.CarrierCodeStorage ccs ON ccs.CarrierCode1 = Response.Member.value('../../PlanId[1]', 'int')
                AND ccs.CarrierCode2 = FLOOR(Response.Member.value('./Age[1]', 'decimal(5,2)'))
                AND ccs.CarrierCode3 = CASE Response.Member.value('./SmokerSurcharge[1]', 'decimal(10,2)') WHEN 0 THEN 0 ELSE 1 END
                AND ccs.CarrierCode4 = COALESCE(c.County, 'N/A')
                AND ccs.CarrierCode5 = QuotitXml.RequestXml.value('/Inputs[1]/ClientState[1]', 'varchar(2)')
                AND ccs.CarrierCode6 = QuotitXml.RequestXml.value('/Inputs[1]/ClientCountyFIPS[1]', 'varchar(5)')
                AND ccs.CarrierCode7 = Request.Member.value('./ZipCode[1]', 'varchar(10)')
                AND ccs.CarrierCode8 = QuotitXml.RequestXml.value('/Inputs[1]/EffectiveDate[1]', 'varchar(10)')
            WHERE Request.Member.value('./MemberPID[1]', 'int') = Response.Member.value('./MemberId[1]', 'int')
                AND Req.Plans.value('./PlanId[1]', 'int') = Response.Member.value('../../PlanId[1]', 'int')";
            
            dictionary.Add("@mlrGuids", mlrGuids.ToString());

            newRates.Parameters = dictionary;
            return newRates;
        }
    }
}

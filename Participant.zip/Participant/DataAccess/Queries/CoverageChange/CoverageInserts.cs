﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries.CoverageChange
{
    public static class CoverageInserts
    {
        public static Query UpdateCoverageForParticipantChange(UpdateCoverageChangeModel model)
        {
            Query coveragetUpdate = new();
            Dictionary<string, string> dictionary = new();
            coveragetUpdate.SelectFrom = @"UPDATE PARTICIPANT_COVERAGE SET COVERAGE_CODE = @Coverage_Code";
            if (!string.IsNullOrEmpty(model.RateType)) {
                if (model.RateType == "MI")
                {
                    if (string.IsNullOrWhiteSpace(model.NewFixedPremium))
                        coveragetUpdate.SelectFrom += ", FIXED_PREMIUM = null";
                    else
                        coveragetUpdate.SelectFrom += ", FIXED_PREMIUM = @Fixed_Premium";
                }
                else if (model.RateType == "IR")
                    coveragetUpdate.SelectFrom += ", FIXED_PREMIUM = @Fixed_Premium";
            }
            coveragetUpdate.SelectFrom += @" WHERE PARTICIPANT_ID = @Participant_Id
                                    AND PLAN_ID = @Plan_Id
                                    AND EFFECTIVE_DATE = @Effective_Date";
            dictionary.Add("@Coverage_Code", model.NewCoverageCode?.ToString() ?? "null");
            dictionary.Add("@Fixed_Premium", model.NewFixedPremium?.ToString() ?? "null");
            dictionary.Add("@Participant_Id", model.ParticipantId.ToString() ?? "0");
            dictionary.Add("@Plan_Id", model.PlanId.ToString() ?? "0");
            dictionary.Add("@Effective_Date", model.EffectiveDate.ToString() ?? "");
            coveragetUpdate.Parameters = dictionary;
            return coveragetUpdate;
        }
        public static Query AddCoverageForParticipantChange(NewCoverageChangeModel model)
        {
            Query coveragetAdd = new();
            Dictionary<string, string> dictionary = new();            
            coveragetAdd.SelectFrom = @"INSERT PARTICIPANT_COVERAGE 
			                            (PLAN_ID, COVERAGE_CODE, PARTICIPANT_ID, FIXED_PREMIUM, 
			                            EFFECTIVE_DATE, COVERAGE_STATE, TERMINATION_DATE) 
			                            VALUES (@Plan_Id, @Coverage_Code, @Participant_Id";
            if (!string.IsNullOrEmpty(model.RateType))
            {
                if (model.RateType == "MI")
                {
                    if (string.IsNullOrWhiteSpace(model.NewFixedPremium))
                        coveragetAdd.SelectFrom += ", null";
                    else
                        coveragetAdd.SelectFrom += ", @Fixed_Premium";
                }
                else if (model.RateType == "IR")
                    coveragetAdd.SelectFrom += ", @Fixed_Premium";
                else
                    coveragetAdd.SelectFrom += ", null";
            }
            else
                coveragetAdd.SelectFrom += ", null";
            coveragetAdd.SelectFrom += @", @Effective_Date, @Coverage_State";
            if(model.TerminationDate == null)
                coveragetAdd.SelectFrom += @", null)";
            else
                coveragetAdd.SelectFrom += @", @Termination_Date)";
            dictionary.Add("@Plan_Id", model.PlanId.ToString() ?? "0");
            dictionary.Add("@Coverage_Code", model.NewCoverageCode?.ToString() ?? "null");
            dictionary.Add("@Participant_Id", model.ParticipantId.ToString() ?? "0");
            dictionary.Add("@Fixed_Premium", model.NewFixedPremium?.ToString() ?? "null");
            dictionary.Add("@Effective_Date", model.EffectiveDate.ToString() ?? "");
            dictionary.Add("@Termination_Date", model.TerminationDate?.ToString() ?? "");
            dictionary.Add("@Coverage_State", "Q");
            coveragetAdd.Parameters = dictionary;
            return coveragetAdd;
        }        
        public static Query DropCoverageForParticipantChange(CoverageChangeModel model)
        {
            Query coveragetDrop = new();
            Dictionary<string, string> dictionary = new();
            coveragetDrop.SelectFrom = @"UPDATE PARTICIPANT_COVERAGE SET TERMINATION_DATE = DATEADD(day, -1, @Effective_Date)";
            if (!string.IsNullOrEmpty(model.RateType))
            {
                if (model.RateType == "MI")
                {
                    if (string.IsNullOrWhiteSpace(model.NewFixedPremium))
                        coveragetDrop.SelectFrom += ", FIXED_PREMIUM = null";
                    else
                        coveragetDrop.SelectFrom += ", FIXED_PREMIUM = @Fixed_Premium";
                }
                else if (model.RateType == "IR")
                    coveragetDrop.SelectFrom += ", FIXED_PREMIUM = @Fixed_Premium";
            }
            coveragetDrop.SelectFrom += @" WHERE PARTICIPANT_ID = @Participant_Id
                                         AND PLAN_ID = @Plan_Id
                                         AND EFFECTIVE_DATE = @Effective_Date";
            dictionary.Add("@Fixed_Premium", model.NewFixedPremium?.ToString() ?? string.Empty);
            dictionary.Add("@Participant_Id", model.ParticipantId.ToString() ?? "0");
            dictionary.Add("@Plan_Id", model.PlanId.ToString() ?? "0");
            dictionary.Add("@Effective_Date", model.EffectiveDate.ToString() ?? "");
            coveragetDrop.Parameters = dictionary;
            return coveragetDrop;
        }
    }
}

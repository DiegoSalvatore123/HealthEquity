﻿using Core.Util;

namespace DataAccess.Queries.CoverageChange;

public static class AdminFee
{
    public static Query GetAdminFee(string clientId)
    {
        Query adminFeeQuery = new();
        Dictionary<string, string> dictionary = new();
        adminFeeQuery.SelectFrom = @"DECLARE @AdminFee DECIMAL(8,2) = 0.00;
                                    DECLARE @DEFAULT_VALUE VARCHAR(1500);
                                    DECLARE @OPTION_VALUE varchar(1500);
                                    DECLARE @USE_DEFAULT BIT;
                                    IF EXISTS(SELECT 1 FROM CLIENT_OPTION_ALL WITH (NOLOCK) 
                                      WHERE CLIENT_ID = @ClientID AND CLIENT_OPTION_ID = 200)
                                        BEGIN
                                            SELECT @OPTION_VALUE = OPTION_VALUE
                                            FROM CLIENT_OPTION_ALL WITH (NOLOCK) 
                                            WHERE CLIENT_ID = @ClientID AND CLIENT_OPTION_ID = 200;
	                                        SET @AdminFee = CAST(@OPTION_VALUE AS DECIMAL(8,2)) / 100;
                                        END
                                        ELSE
                                        BEGIN
                                            SELECT @DEFAULT_VALUE = DEFAULT_VALUE, @USE_DEFAULT = USE_DEFAULT
                                            FROM CLIENT_OPTION_LOOKUP WITH (NOLOCK) 
                                            WHERE CLIENT_OPTION_ID = 200;
                                            
                                            IF @USE_DEFAULT = 1
                                            BEGIN
                                                SET @AdminFee = CAST(@DEFAULT_VALUE AS DECIMAL(8,2)) / 100;
                                            END
                                        END;

                                        SELECT @AdminFee as Fee";
        dictionary.Add("@ClientID", clientId);
        adminFeeQuery.Parameters = dictionary;
        return adminFeeQuery;
    }
}
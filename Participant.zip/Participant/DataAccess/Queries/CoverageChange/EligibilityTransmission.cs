﻿using Core.Util;

namespace DataAccess.Queries.CoverageChange
{
    public static class EligibilityTransmission
    {
        public static Query GetEligibilityTransmissionByPid(string participantId)
        {
            Query eligibilityTranmission = new();
            Dictionary<string, string> dictionary = new();
            eligibilityTranmission.SelectFrom = @"SELECT DISTINCT	ecd.PARTICIPANT_ID,ecdist.EVENT_COMM_ID AS REFERENCE_NUMBER
                                                , co.FIRST_NAME + ' ' + co.LAST_NAME AS SENT_TO
                                                , co.CONTACT_ID
                                                , CONVERT(varchar(20),dq.COUPON_START_DATE,101) AS REPORT_DATA_START
                                                , dq.DOC_ID
                                                , dq.DOC_IMAGE_ID
                                                , CONVERT(varchar(12),dq.SEND_DATE,101) AS SEND_DATE
                                                , CONVERT(varchar(20),dq.SEND_DATE,101) AS REPORT_DATA_END
                                                , ecd.PLAN_NAME
                                                , ecd.COVERAGE_CODE
                                                , ecd.COVERAGE_DESCRIPTION
                                                , ecd.EFFECTIVE_DATE
                                                , ecd.TERMINATION_DATE
                                                , ecd.PAID_THRU
                                                , CASE WHEN		ec.CLIENT_ID = p.CLIENT_ID THEN 1 ELSE 0 END AS ALLOW_VIEW 
                                                FROM		EVENT_COMMUNICATION_DATA ecd	WITH (NOLOCK) 
                                                INNER JOIN	PARTICIPANT p	WITH (NOLOCK) ON	p.PARTICIPANT_ID = ecd.PARTICIPANT_ID 
                                                INNER JOIN	DOC_QUEUE dq	WITH (NOLOCK) ON dq.DOC_ID = ecd.DOC_ID 
                                                INNER JOIN	EVENT_COMMUNICATION_DISTRIBUTION ecdist WITH (NOLOCK) ON dq.EVENT_COMM_DIST_ID=ecdist.EVENT_COMM_DIST_ID 
                                                INNER JOIN	EVENT_COMMUNICATION ec WITH (NOLOCK) ON ec.EVENT_COMM_ID=ecdist.EVENT_COMM_ID 
                                                INNER JOIN	CONTACT co ON ecdist.CONTACT_ID=co.CONTACT_ID 
                                 WHERE				ecd.PARTICIPANT_ID = @Participant_Id
		                        AND					dq.DOC_STATUS in ('E','F') 
                                ORDER BY			dq.DOC_ID DESC";
            dictionary.Add("@Participant_Id", participantId.ToString() ?? "0");
            eligibilityTranmission.Parameters = dictionary;
            return eligibilityTranmission;
        }
        public static Query GetDocumentOption(string docId)
        {
            Query eligibilityTranmission = new();
            Dictionary<string, string> dictionary = new();
            eligibilityTranmission.SelectFrom = @"select dq.DOC_ID, ISNULL(CASE WHEN CONVERT(DATE, dq.COUPON_START_DATE) = '1900-01-01' THEN '' ELSE CONVERT(CHAR(10), dq.COUPON_START_DATE, 103) END, '') COUPON_START_DATE, dq.OPTION_VALUE,  
		                     e.EVENT_TYPE, 
		                     f.FORM_NUMBER, 
		                     rm.RETURNED_MAIL_ID 
		                     from DOC_QUEUE dq WITH (NOLOCK) 
		                     inner join EVENT e WITH (NOLOCK) on e.EVENT_ID = dq.EVENT_ID 
		                     inner join FORM f WITH (NOLOCK) on f.FORM_ID = dq.FORM_ID 
		                     left outer join RETURNED_MAIL rm WITH (NOLOCK) on rm.DOC_ID = dq.DOC_ID 
		                     where dq.DOC_ID =  @DocId
		                     and f.form_id != 331";
            dictionary.Add("@DocId", docId);
            eligibilityTranmission.Parameters = dictionary;
            return eligibilityTranmission;
        }
    }
}

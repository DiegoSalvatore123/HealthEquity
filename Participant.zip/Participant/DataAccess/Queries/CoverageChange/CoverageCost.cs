﻿using Core.Util;

namespace DataAccess.Queries.CoverageChange;

public static class CoverageCost
{
    public static Query GetCoverageCost(string PlanId, string CoverageCode)
    {
        Query coverageCostQuery = new();
        Dictionary<string, string> dictionary = new();
        coverageCostQuery.SelectFrom = @"SELECT COVERAGE_COST 
                                        FROM COVERAGE_RATE WITH (NOLOCK) 
                                    WHERE PLAN_ID = @PLAN_ID
                                    and COVERAGE_CODE = @COVERAGE_CODE
                                    AND ( (TERMINATION_DATE is null and EFFECTIVE_DATE <= getdate()) 
                                    OR (TERMINATION_DATE >= getdate()) )";
        dictionary.Add("@PLAN_ID", PlanId);
        dictionary.Add("@COVERAGE_CODE", CoverageCode);
        coverageCostQuery.Parameters = dictionary;
        return coverageCostQuery;
    }
}
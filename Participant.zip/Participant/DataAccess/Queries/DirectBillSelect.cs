﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries
{
    public static class DirectBillSelect
    {
        public static Query GetClientAcivePlans(PlatformModel model)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
				if exists(
	                select OPTION_VALUE 
	                from CLIENT_OPTION_ALL WITH (NOLOCK) 
	                where CLIENT_ID = @ClientID
	                and CLIENT_OPTION_ID = 300
                ) 
                select OPTION_VALUE 
                from CLIENT_OPTION_ALL WITH (NOLOCK) 
                where CLIENT_ID = @ClientID
                and CLIENT_OPTION_ID = 300
                else
                select 
	                  case when USE_DEFAULT =1 then DEFAULT_VALUE
	                  else
	                  3
	                  end 
	                  from CLIENT_OPTION_LOOKUP WITH (NOLOCK) 
	                  where CLIENT_OPTION_ID = 300
			";
            dictionary.Add("@ClientID", model.ClientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
        public static Query GetClientPlans(string clientId)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
				 SELECT 
				 PO.PLAN_ID,PLAN_NAME,PLAN_TYPE, 
				 CA.COVERAGE_END_TYPE,CA.WAIT_PERIOD_TYPE,CA.WAIT_PERIOD_QTY, 
				 CA.WAIT_ENDS_TYPE 
				 from PLAN_OPTION PO WITH (NOLOCK) 
				 INNER JOIN CARRIER CA WITH (NOLOCK) on PO.CARRIER_ID=CA.CARRIER_ID 
				 WHERE PLAN_STATUS='A' 
				 and PLAN_TYPE!='F' 
				 and PLAN_TYPE2 not in ('C','E') 
				 and PO.CLIENT_ID= @ClientID
				 ORDER BY PLAN_TYPE,PLAN_NAME
			";
            dictionary.Add("@ClientID", clientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
        public static Query GetDirectBillTypes(string clientId)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
					select qe.EVENT_NAME  as Description, Code
					from QUALIFYING_EVENTS qe WITH (NOLOCK) 
					where qe.TYPE in ('B','E','L','R') 
					and (
						(qe.ALL_CLIENTS = 1) 
						OR 
						( 
							qe.ALL_CLIENTS = 0 
							and 
							exists (
								select * 
								from QUALIFYING_EVENTS_CLIENTS qec WITH (NOLOCK) 
								where qec.CODE = qe.CODE 
								and qec.CLIENT_ID = 50714
							) 
						) 
					) 
					ORDER BY qe.DISPLAY_ORDER
			";
            dictionary.Add("@ClientID", clientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
        public static Query GetPastDue(SearchModel model)
        {
            Query query = new();
            Dictionary<string, string> dictionary = new();
            int pageNumber = ((int.Parse(model.PageNumber) - 1) * int.Parse(model.PageSize));
            query.SelectFrom = @";WITH Main_CTE AS ( SELECT DISTINCT 
                                                            P.PARTICIPANT_ID,
                                                            P.FIRST_NAME,
                                                            P.LAST_NAME,
                                                            P.SOCIAL_SECURITY_NUMBER,
                                                            SSNMASK.LabelValue,
                                                            SSNMASK.DisplayValue,
                                                            SSNMASK.ClientOptionValue,
                                                            QE.EVENT_NAME,
                                                            A.AFFILIATE_NAME
                                                     FROM PARTICIPANT_BILLING_NEW PB WITH (NOLOCK) 
                                                     INNER JOIN PARTICIPANT P WITH (NOLOCK) ON PB.PARTICIPANT_ID = P.PARTICIPANT_ID 
                                                     INNER JOIN CLIENT C WITH (NOLOCK) ON P.CLIENT_ID = C.CLIENT_ID 
                                                     LEFT OUTER JOIN AFFILIATE A WITH (NOLOCK) ON A.AFFILIATE_ID = p.AFFILIATE_ID 
                                                     LEFT OUTER JOIN qualifying_events QE WITH (NOLOCK) ON P.qualifying_event_type = QE.code 
                                                     CROSS APPLY dbo.SSNMask (P.PARTICIPANT_ID) SSNMASK
                                                     WHERE PB.DEADLINE_DATE < GETDATE() 
                                                     AND PB.Status IN ('NP', 'PD', 'CP') 
                                                     AND P.PARTICIPANT_STATUS = 'A' 
                                                     AND PARTICIPANT_TYPE = 'B' 
                                                     AND P.CLIENT_ID = @ClientID ";

            if (model.DivisionLevelAccess!.Equals("Yes"))
                query.SelectFrom += @" AND P.AFFILIATE_ID IN (' + @AffiliateString + ') ";

            query.SelectFrom += @"), Count_CTE AS (
                                                     SELECT COUNT(*) AS [TotalCount] FROM Main_CTE) 
                                                     
                                                     SELECT *
                                                     INTO #TempTable 
                                                     FROM Main_CTE, Count_CTE 
                                                     ORDER BY LAST_NAME ASC
                                                     OFFSET CONVERT(INT, @PageNumber) ROWS 
                                                     FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY;";

            query.SelectFrom += @"SELECT P.PARTICIPANT_ID,
                                         P.FIRST_NAME,
                                         P.LAST_NAME,
                                         P.SOCIAL_SECURITY_NUMBER,
                                         PB.COVERAGE_START,
                                         SSNMASK.LabelValue,
                                         SSNMASK.DisplayValue,
                                         SSNMASK.ClientOptionValue,
                                         PB.COVERAGE_END,
                                         PB.AMOUNT_DUE AS AMOUNT,
                                         PB.DUE_DATE,
                                         PB.ER_PAID,
                                         PB.PARTICIPANT_OWED AS OWED,
                                         PB.PARTICIPANT_PAID AS PAID,
                                         L.LOOKUP_DESCRIPTION AS STATUS,
                                         QE.EVENT_NAME,
                                         A.AFFILIATE_NAME,
                                         T.TotalCount
                                  FROM PARTICIPANT_BILLING_NEW PB WITH (NOLOCK) 
                                  INNER JOIN PARTICIPANT P WITH (NOLOCK) ON PB.PARTICIPANT_ID = P.PARTICIPANT_ID 
                                  INNER JOIN CLIENT C WITH (NOLOCK) ON P.CLIENT_ID = C.CLIENT_ID 
                                  INNER JOIN LOOKUP L WITH (NOLOCK) ON L.LOOKUP_CODE = PB.STATUS  AND L.LOOKUP_TBL = 'PARTICIPANT_BILLING' AND L.LOOKUP_COL = 'STATUS' 
                                  LEFT OUTER JOIN AFFILIATE A WITH (NOLOCK) ON A.AFFILIATE_ID = p.AFFILIATE_ID 
                                  LEFT OUTER JOIN qualifying_events QE WITH (NOLOCK) ON P.qualifying_event_type = QE.code 
                                  CROSS APPLY dbo.SSNMask (P.PARTICIPANT_ID) SSNMASK
                                  INNER JOIN #TempTable T ON P.PARTICIPANT_ID = T.PARTICIPANT_ID 
                                  WHERE PB.DEADLINE_DATE < GETDATE() 
                                  AND PB.Status in ('NP','PD','CP') 
                                  AND P.PARTICIPANT_STATUS = 'A' 
                                  AND PARTICIPANT_TYPE = 'B' 
                                  AND P.CLIENT_ID = @ClientID ";

            if (model.DivisionLevelAccess!.Equals("Yes"))
                query.SelectFrom += @" AND P.AFFILIATE_ID IN (' + @AffiliateString + ') ";

            query.SelectFrom += @"ORDER BY LAST_NAME ASC 

                                  DROP TABLE #TempTable ";

            dictionary.Add("@ClientID", model.ClientId);
            dictionary.Add("@PageNumber", pageNumber.ToString());
            dictionary.Add("@PageSize", model.PageSize);
            if (model.DivisionLevelAccess!.Equals("Yes"))
                dictionary.Add("@AffiliateString", model.AffiliateId!);

            query.Parameters = dictionary;
            return query;
        }
        public static Query GetClientCobraPlans(string clientId)
        {
            Query employeeCount = new();
            Dictionary<string, string> dictionary = new();
            employeeCount.SelectFrom = @"
				 SELECT 
				 PO.PLAN_ID,PLAN_NAME,PLAN_TYPE, 
				 CA.COVERAGE_END_TYPE,CA.WAIT_PERIOD_TYPE,CA.WAIT_PERIOD_QTY, 
				 CA.WAIT_ENDS_TYPE 
				 from PLAN_OPTION PO WITH (NOLOCK) 
				 INNER JOIN CARRIER CA WITH (NOLOCK) on PO.CARRIER_ID=CA.CARRIER_ID 
				 WHERE PLAN_STATUS='A' 
				 and PLAN_TYPE!='F' 
				 and PLAN_TYPE2 not in ('C','E') 
				 and PO.CLIENT_ID= @ClientID
				 ORDER BY PLAN_TYPE,PLAN_NAME
			";
            dictionary.Add("@ClientID", clientId);

            employeeCount.Parameters = dictionary;
            return employeeCount;
        }
    }
}

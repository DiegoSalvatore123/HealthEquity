﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries.DisabilityExtension
{
    public static class Select
    {
        public static Query GetDisabilitySurchargePercent(string clientId)
        {
            Query surchargePercent = new();
            Dictionary<string, string> dictionary = new();
            surchargePercent.SelectFrom = @"SELECT
                    CASE WHEN c.OPTION_VALUE IS NOT NULL THEN c.OPTION_VALUE
                         WHEN l.USE_DEFAULT = 1 THEN l.DEFAULT_VALUE
                         ELSE NULL
                    END AS SurchargePercent
                FROM
                    CLIENT_OPTION_ALL c WITH(NOLOCK)
                    LEFT JOIN CLIENT_OPTION_LOOKUP l WITH(NOLOCK) ON c.CLIENT_OPTION_ID = l.CLIENT_OPTION_ID
                WHERE c.CLIENT_ID = @CLIENT_ID AND c.CLIENT_OPTION_ID = 204";
            dictionary.Add("@CLIENT_ID", clientId);
            surchargePercent.Parameters = dictionary;
            return surchargePercent;
        }
        public static QueryT CalculateEligibilityEndDate(InfoResultModel searchModel)
        {
            QueryT eligibilityEndDate = new();
            Dictionary<string, object> dictionary = new();
            eligibilityEndDate.SelectFrom = "Exec P506_CalculateEligibilityEndDate @PaticipantId ,@EventType, @LastCoverDate, @EligibilityEndDate OUTPUT";
            dictionary.Add("@PaticipantId", searchModel.ParticipantId.ToString());
            dictionary.Add("@EventType", "16");
            dictionary.Add("@LastCoverDate", Convert.ToDateTime(searchModel.LastPrecobraCoveredDate));
            dictionary.Add("@EligibilityEndDate", "null");
            eligibilityEndDate.Parameters = dictionary;
            return eligibilityEndDate;
        }
    }
}
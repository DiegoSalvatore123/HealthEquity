﻿using Core.Model;
using Core.Util;

namespace DataAccess.Queries.GroupUpdate;
public class Select
{
    public static Query GetData(GroupUpdateModel groupUpdateModel, GroupUpdateSearchModel groupUpdateDataModel)
    {
        var divisionLevelAccess = groupUpdateDataModel.DivisionLevelAccess ?? string.Empty;
        var affiliateString = groupUpdateDataModel.AffiliateString ?? string.Empty;
        var criteria = groupUpdateModel.Criteria ?? string.Empty;
        var orderBy = groupUpdateModel.OrderBy ?? string.Empty;
        string? pageNumber = ((groupUpdateDataModel.PageNumber - 1) * groupUpdateDataModel.PageSize).ToString();
        var pageSize = groupUpdateDataModel.PageSize.ToString();
        var columnName = groupUpdateModel.ColumnName;
        var tableName = groupUpdateModel.TableName;

        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"WITH Main_CTE AS(SELECT isnull(P.PARTICIPANT_ID, '')PARTICIPANT_ID, 
                            isnull(P.EMPLOYEE_NUMBER, '')EMPLOYEE_NUMBER,
                            isnull(P.Student, '')Student, 
                            isnull(P.KEY_EMPLOYEE, '')KEY_EMPLOYEE,
                            isnull(P.SHARE_HOLDER5, '')SHARE_HOLDER5, 
                            isnull(P.HIGHLY_COMP_POP, '')HIGHLY_COMP_POP,
                            isnull(P.HIGHLY_COMP_MFSA, '')HIGHLY_COMP_MFSA,
                            isnull(P.SALARY_UNDER_25K, '')SALARY_UNDER_25K,
                            isnull(P.AFFILIATE_ID, '')AFFILIATE_ID,
                            isnull(P.HIRE_DATE, '')HIRE_DATE,
                            isnull(P.QUALIFIED_BENEFICIARY, '')QUALIFIED_BENEFICIARY,
                            isnull(P.PHONE_NUMBER, '')PHONE_NUMBER,
                            isnull(P.PAY_SCHEDULE_ID, '')PAY_SCHEDULE_ID, 
                            isnull(P.FIRST_NAME, '')FIRST_NAME, 
                            isnull(P.LAST_NAME, '')LAST_NAME, 
                            isnull(P.MIDDLE_INITIAL, '')MIDDLE_INITIAL, 
                            isnull(P.SOCIAL_SECURITY_NUMBER, '')SOCIAL_SECURITY_NUMBER, 
                            ssnmask.LabelValue, ssnmask.DisplayValue, ssnmask.ClientOptionValue " +
                           " FROM Participant AS P WITH (NOLOCK) CROSS APPLY [dbo].[SSNMask](P.PARTICIPANT_ID)  WHERE P.CLIENT_ID = @CLIENT_ID  AND P.PARTICIPANT_STATUS <> 'V'";

        if (divisionLevelAccess == "Yes" & !string.IsNullOrEmpty(affiliateString))
        {
            query.SelectFrom += " AND P.AFFILIATE_ID in (' + @AffiliateString + ') ";
            dictionary.Add("@AffiliateString", affiliateString);
        }
        if (!string.IsNullOrEmpty(criteria))
        {
            query.SelectFrom += " AND (' + @Criteria + ') ";
            dictionary.Add("@Criteria", criteria);
        }

        query.SelectFrom += "), Count_CTE AS (SELECT COUNT(*) AS [TotalRecords] FROM Main_CTE ) SELECT  Subquery.*, (SELECT [TotalRecords] FROM Count_CTE) AS TotalRecords ";
        if (groupUpdateDataModel.GroupUpdateIdNumber == "7")
            query.SelectFrom += ", a.AFFILIATE_NAME ";
        else
            query.SelectFrom += ", null as AFFILIATE_NAME ";
        query.SelectFrom += " FROM (SELECT * FROM Main_CTE) AS Subquery ";
        if (groupUpdateDataModel.GroupUpdateIdNumber == "7")
            query.SelectFrom += " INNER JOIN AFFILIATE a ON a.AFFILIATE_ID = Subquery.AFFILIATE_ID ";
        if (!string.IsNullOrEmpty(orderBy))
        { 
            query.SelectFrom += orderBy switch
            {
                "LAST_NAME ASC" => " ORDER BY Subquery.LAST_NAME ASC",
                "LAST_NAME DESC" => " ORDER BY Subquery.LAST_NAME DESC",
                "FIRST_NAME ASC" => " ORDER BY Subquery.FIRST_NAME ASC",
                "FIRST_NAME DESC" => " ORDER BY Subquery.FIRST_NAME DESC",
                "DisplayValue ASC" => " ORDER BY Subquery.DisplayValue ASC",
                "DisplayValue DESC" => " ORDER BY Subquery.DisplayValue DESC",
                "STUDENT ASC" => " ORDER BY Subquery.STUDENT ASC",
                "STUDENT DESC" => " ORDER BY Subquery.STUDENT DESC",
                "AFFILIATE_ID ASC" => " ORDER BY Subquery.AFFILIATE_ID ASC",
                "AFFILIATE_ID DESC" => " ORDER BY Subquery.AFFILIATE_ID DESC",
                "HIRE_DATE ASC" => " ORDER BY Subquery.HIRE_DATE ASC",
                "HIRE_DATE DESC" => " ORDER BY Subquery.HIRE_DATE DESC",
                "EMPLOYEE_NUMBER ASC" => " ORDER BY Subquery.EMPLOYEE_NUMBER ASC",
                "EMPLOYEE_NUMBER DESC" => " ORDER BY Subquery.EMPLOYEE_NUMBER DESC",
                "PHONE_NUMBER ASC" => " ORDER BY Subquery.PHONE_NUMBER ASC",
                "PHONE_NUMBER DESC" => " ORDER BY Subquery.PHONE_NUMBER DESC",
                "QUALiFIED_BENEFICIARY ASC" => " ORDER BY Subquery.QUALiFIED_BENEFICIARY ASC",
                "QUALiFIED_BENEFICIARY DESC" => " ORDER BY Subquery.QUALiFIED_BENEFICIARY DESC",
                _ => " ORDER BY Subquery.LAST_NAME ASC ",
            };
        }
        query.SelectFrom += " OFFSET CONVERT(INT, @PageNumber) ROWS FETCH NEXT CONVERT(INT, @PageSize) ROWS ONLY";
        dictionary.Add("@CLIENT_ID", groupUpdateDataModel.ClientId.ToString());
        dictionary.Add("@pageSize", pageSize!);
        dictionary.Add("@pageNumber", pageNumber!);
        query.Parameters = dictionary;
        return query;
    }
    public static Query GetByIdNumber(string IdNumber)
    {
        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"SELECT * FROM GROUP_UPDATE WITH (NOLOCK) 
        WHERE ID_NUMBER = @ID_NUMBER ";
        dictionary.Add("@ID_NUMBER", IdNumber);
        query.Parameters = dictionary;
        return query;
    }
    public static Query GetDataTotalCount(string ClientID, string TableName)
    {
        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"SELECT count(*) 
                            FROM "+ TableName + " WITH (NOLOCK) WHERE CLIENT_ID = @CLIENT_ID AND PARTICIPANT_STATUS <> ''V'' ' ";
        dictionary.Add("@CLIENT_ID", ClientID);
        query.Parameters = dictionary;
        return query;
    }
}
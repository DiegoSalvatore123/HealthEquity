﻿using Core.Util;

namespace DataAccess.Queries.GroupUpdate;

public class DropDownList
{
    public static Query GetBoolean(string tableName, string colName)
    {
        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"SELECT LOOKUP_CODE as CODE, LOOKUP_DESCRIPTION as DESCRIPTION 
                                FROM LOOKUP WITH (NOLOCK)
                WHERE ACTIVE = 'Y' AND LOOKUP_TBL = @TABLE_NAME AND LOOKUP_COL = @COL_NAME
        ORDER BY DISPLAY_ORDER";
        dictionary.Add("@TABLE_NAME", tableName);
        dictionary.Add("@COL_NAME", colName);
        query.Parameters = dictionary;
        return query;
    }
    public static Query GetAffiliate(string clientId, string divisionLevelAccess, string affiliateString)
    {
        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"SELECT  CONVERT(varchar(10), AFFILIATE_ID) AS CODE, AFFILIATE_NAME AS DESCRIPTION 
                            FROM AFFILIATE WITH (NOLOCK)  WHERE CLIENT_ID = @CLIENT_ID ";

        if (divisionLevelAccess == "Yes" & !string.IsNullOrEmpty(affiliateString))
        {
            query.SelectFrom += " AND AFFILIATE_ID in (' + @AffiliateString + ') ";
            dictionary.Add("@AffiliateString", affiliateString);
        }
        query.SelectFrom += " ORDER BY AFFILIATE_NAME";
        dictionary.Add("@CLIENT_ID", clientId);
        query.Parameters = dictionary;
        return query;
    }
    public static Query GetSchedule(string clientId)
    {
        Query query = new();
        Dictionary<string, string> dictionary = new();
        query.SelectFrom = @"SELECT CONVERT(varchar(10), PAY_SCHEDULE_ID) as CODE, SCHEDULE_NAME as DESCRIPTION 
                            FROM PAY_SCHEDULE WITH (NOLOCK) 
                WHERE CLIENT_ID = @CLIENT_ID 
                ORDER BY SCHEDULE_NAME ";
        dictionary.Add("@CLIENT_ID", clientId);
        query.Parameters = dictionary;
        return query;
    }
}
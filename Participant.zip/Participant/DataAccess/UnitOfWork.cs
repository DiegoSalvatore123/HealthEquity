﻿using Core.Interfaces;
using Core.Model;
using DataAccess.Repositories;
using Microsoft.Extensions.Logging;

namespace DataAccess
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ILogger<TransactionRepository> _logger;
        private readonly CobraDbContext _db;
        private readonly ICobraConfig _cobraConfig;
        private readonly IPlanBenefitRepository _planBenefit;
        private readonly ISubsidyDataRepository _subsidyData;
        public UnitOfWork(ILogger<TransactionRepository> logger, CobraDbContext db, ICobraConfig cobraConfig, IPlanBenefitRepository planBenefit, ISubsidyDataRepository subsidyData)
        {
            _logger = logger;
            _db = db;
            _cobraConfig = cobraConfig;
            _planBenefit = planBenefit;
            _subsidyData = subsidyData;
            Activity = new ActivityRepository(_db, _cobraConfig);
            BillingDetail = new BillingRepository(_db, _cobraConfig);
            Coverage = new CoverageRepository(_db, _cobraConfig);
            DependentDetail = new DependentDetailRepository(_db, _cobraConfig);
            Dependent = new DependentRepository(_db, _cobraConfig);
            Info = new InfoRepository(_db, _cobraConfig);
            CarrierRemittance = new CarrierRemittanceRepository(_db, _cobraConfig);
            PaymentHistory = new PaymentHistoryRepository(_db, _cobraConfig);
            Participant = new ParticipantRepository(_db, _cobraConfig);
            Document = new DocumentRepository(_db, _cobraConfig);
            QE = new QERepository(_db, _cobraConfig);
            RemoveQE = new RemoveQERepository(_db, _cobraConfig);
            RemoveQEDetail = new RemoveQEDetailRepository(_db, _cobraConfig);
            SystemSetting = new SystemSettingRepository(_db, _cobraConfig);
            EmailNotification = new EmailNotificationRepository(_db, _cobraConfig);
            SpecificField = new SpecificFieldsRepository(_db, _cobraConfig);
            Subsidy = new SubsidyRepository(_db, _cobraConfig);
            Affiliate = new AffiliateRepository(_db, _cobraConfig);
            ParticipantPromoted = new ParticipantPromotedRepository(_db, _cobraConfig);
            QualifyingEventType = new QualifyingEventTypeRepository(_db, _cobraConfig);
            State = new StateRepository(_db, _cobraConfig);
            Relation = new RelationRepository(_db, _cobraConfig);
            EmployeeClass = new EmployeeClassRepository(_db, _cobraConfig);
            Cases = new CasesRepository(_db, _cobraConfig);
            BankCheck = new BankCheckRepository(_db, _cobraConfig);
            Payments = new PaymentRepository(_db, _cobraConfig);
            Void = new VoidRepository(_db, _cobraConfig);
            VoidCheck = new VoidValidationRepository(_db, _cobraConfig);
            RehireValidator = new ValidatorRepository(_db, _cobraConfig);
            ClientOptionAll = new ClientOptionAllRepository(_db, _cobraConfig);
            ParticipantTransaction = new TransactionRepository(_logger, _db, _cobraConfig, _planBenefit, _subsidyData);
            SurchargePercent = new SurchargePercentRepository(_db, _cobraConfig);
            EligibilityEnd = new EligibilityEndRepository(_db, _cobraConfig);
            Client = new ClientRepository(_db, _cobraConfig);
            CustomFieldDomain = new CustomFieldDomainRepository(_db, _cobraConfig);
            ParticipantCoverage = new ParticipantCoverageRepository(_db, _cobraConfig);
            DocQueue = new DocQueueRepository(_db, _cobraConfig);
            AvailablePlan = new AvailablePlanRepository(_db, _cobraConfig);
            GenericUniqueValue = new GenericUniqueValueRepository(_db, _cobraConfig);
            GenericPaireValue = new CoverageAvailablePlanRepository(_db, _cobraConfig);
            QEPlanComponent = new QEPlanComponentRepository(_db, _cobraConfig);
            SCCobraElig = new SCCobraEligRepository(_db, _cobraConfig);
            CobraHipaa = new CobraHipaaRepository(_db, _cobraConfig);
            DependentCoverage = new DependentCoverageRepository(_db, _cobraConfig);
            ParticipantCoveragePlanOption = new ParticipantCoveragePlanOptionRepository(_db, _cobraConfig);
            ParticipantDependentAddress = new ParticipantDependentAddressRepository(_db, _cobraConfig);
            EligibilityTransmission = new EligibilityTransmissionRepository(_db, _cobraConfig);
            QEExtension = new QEExtensionRepository(_db, _cobraConfig);
            AdminFee = new AdminFeeRepository(_db, _cobraConfig);
            CoverageCost = new CoverageCostRepository(_db, _cobraConfig);
            ParticipantInfo = new ParticipantInfoRepository(_db, _cobraConfig);
            PlanBenefit = new PlanBenefitRepository(_db, _cobraConfig);
            SubsidyData = new SubsidyDataRepository(_db, _cobraConfig);
            GroupUpdate = new GroupUpdateRepository(_db, _cobraConfig);
            GroupUpdateData = new GroupUpdateDataRepository(_db, _cobraConfig);
            GroupUpdateDropDownList = new GroupUpdateDropDownListRepository(_db, _cobraConfig);
            EmailQueue = new EmailQueueRepository(_db, _cobraConfig);
            DocumentOption = new DocumentOptionRepository(_db, _cobraConfig);
            ClientPlans = new ClientPlansRepository(_db, _cobraConfig);
            DBPastDue = new DBPastDueRepository(_db, _cobraConfig);
            DBImpendingMedicareReport = new DBImpendingMedicareReportRepository(_db, _cobraConfig);
            GenericUniquePairValue = new GenericUniquePairValueRepository(_db, _cobraConfig);
            CoverageError = new CoverageErrorRepository(_db, _cobraConfig);
            MLRQuoteRate = new MLRQuoteRateRepository(_db, _cobraConfig);
            MLRQuoteNewRate = new MLRQuoteNewRateRepository(_db, _cobraConfig);
            CoveragePlans= new CoveragePlansRepository(_db, _cobraConfig);
            DependentSearch = new DependentSearchRepository(_db, _cobraConfig);
            GenericGuidValue = new GenericGuidValueRepository(_db, _cobraConfig);
        }
        public IActivityRepository Activity { get; private set; }
        public IBillingDetailRepository BillingDetail { get; private set; }
        public ICoverageRepository Coverage { get; private set; }
        public IDependentDetailRepository DependentDetail { get; private set; }
        public IDependentRepository Dependent { get; private set; }
        public IInfoRepository Info { get; private set; }
        public ICarrierRemittanceRepository CarrierRemittance { get; private set; }
        public IPaymentHistory PaymentHistory { get; private set; }
        public IParticipantRepository Participant { get; private set; }
        public IDocumentRepository Document { get; private set; }
        public IQERepository QE { get; private set; }
        public IRemoveQERepository RemoveQE { get; private set; }
        public IRemoveQEDetailRepository RemoveQEDetail { get; private set; }
        public ISystemSettingRepository SystemSetting { get; private set; }
        public IEmailNotificationRepository EmailNotification { get; private set; }
        public ISpecificFieldsRepository SpecificField { get; private set; }
        public ISubsidyRepository Subsidy { get; private set; }
        public IAffiliateRepository Affiliate { get; private set; }
        public IParticipantPromotedRepository ParticipantPromoted { get; private set; }
        public IQualifyingEventTypeRepository QualifyingEventType { get; private set; }
        public IStateRepository State { get; private set; }
        public IRelationRepository Relation { get; private set; }
        public IEmployeeClassRepository EmployeeClass { get; private set; }
        public IBankCheckRepository BankCheck { get; private set; }
        public IPaymentRepository Payments { get; private set; }
        public ICasesRepository Cases { get; private set; }
        public IVoidRepository Void { get; private set; }
        public IVoidValidationRepository VoidCheck { get; private set; }
        public IValidatorRepository RehireValidator { get; private set; }
        public IClientOptionAllRepository ClientOptionAll { get; private set; }
        public ITransactionRepository ParticipantTransaction { get; private set; }
        public ISurchargePercentRepository SurchargePercent { get; private set; }
        public IEligibilityEndRepository EligibilityEnd { get; private set; }
        public IClientRepository Client { get; private set; }
        public ICustomFieldDomainRepository CustomFieldDomain { get; private set; }
        public IParticipantCoverageRepository ParticipantCoverage { get; private set; }
        public IDocQueueRepository DocQueue { get; private set; }
        public IAvailablePlanRepository AvailablePlan { get; private set; }
        public IGenericUniqueValueRepository GenericUniqueValue { get; private set; }
        public ICoverageAvailablePlanRepository GenericPaireValue { get; private set; }
        public IQEPlanComponentRepository QEPlanComponent { get; private set; }
        public ISCCobraEligRepository SCCobraElig { get; private set; }
        public ICobraHipaaRepository CobraHipaa { get; private set; }
        public IDependentCoverageRepository DependentCoverage { get; set; }
        public IParticipantCoveragePlanOptionRepository ParticipantCoveragePlanOption { get; set; }
        public IParticipantDependentAddressRepository ParticipantDependentAddress { get; set; }
        public IQEExtensionRepository QEExtension { get; set; }
        public IEligibilityTransmissionRepository EligibilityTransmission { get; set; }
        public IAdminFeeRepository AdminFee { get; set; }
        public ICoverageCostRepository CoverageCost { get; set; }
        public IPlanBenefitRepository PlanBenefit { get; set; }
        public IParticipantInfoRepository ParticipantInfo { get; set; }
        public ISubsidyDataRepository SubsidyData { get; set; }
        public IGroupUpdateDataRepository GroupUpdateData { get; set; }
        public IGroupUpdateRepository GroupUpdate { get; set; }
        public IGroupUpdateDropDownListRepository GroupUpdateDropDownList { get; set; }
        public IEmailQueueRepository EmailQueue { get; set; }
        public IDocumentOptionRepository DocumentOption { get; set; }
        public IClientPlansRepository ClientPlans { get;  set; }
        public IDBPastDueRepository DBPastDue { get; set; }
        public IDBImpendingMedicareReportRepository DBImpendingMedicareReport { get; set; }
        public IGenericUniquePairValueRepository GenericUniquePairValue { get; set; }
        public ICoverageErrorRepository CoverageError { get; set; }
        public IMLRQuoteRateRepository MLRQuoteRate { get; set; }
        public IMLRQuoteNewRateRepository MLRQuoteNewRate { get; set; }
        public IDependentSearchRepository DependentSearch { get; set; }
        public ICoveragePlansRepository CoveragePlans { get; set; }
        public IGenericGuidValueRepository GenericGuidValue { get; set; }
        public void Dispose() => _db.Dispose();
        public void Save()
        {
            _db.SaveChanges();
        }
    }
}

﻿using Core;
using Core.Interfaces;
using DataAccess.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace DataAccess
{
    public static class ServiceCollectionExtensions
    {
        public static void AddDataAccessServices(this IServiceCollection services)
        {
            services
                 .AddDbContext<CobraDbContext>(options => options.UseSqlServer(string.Empty));

            #region "Services DI"
            
            services.AddScoped<IInnerService, InnerService>();
            services.AddScoped<ISearchService, SearchService>();
            services.AddScoped<IPartialService, PartialService>();
            services.AddScoped<ICollectionService, CollectionService>();
            services.AddScoped<ISPService, SPService>();
            services.AddScoped<IParticipantService, ParticipantService>();
            services.AddScoped<IDocumentService, DocumentService>();
            services.AddScoped<IValidatorService, ValidatorService>();
            services.AddScoped<ITransactionService, TransactionService>();
            services.AddScoped<ICobraService, CobraService>();
            services.AddScoped<IDirectBillService, DirectBillService>();
            services.AddScoped<IDirectBillSPService, DirectBillSPService>();
            services.AddScoped<ICoverageService, CoverageService>();

            #endregion

            #region "Repositories DI"

            services.AddScoped<IInfoRepository, InfoRepository>();
            services.AddScoped<IQERepository, QERepository>();
            services.AddScoped<IRemoveQERepository, RemoveQERepository>();
            services.AddScoped<IRemoveQEDetailRepository, RemoveQEDetailRepository>();
            services.AddScoped<IEmailNotificationRepository, EmailNotificationRepository>();
            services.AddScoped<ISystemSettingRepository, SystemSettingRepository>();
            services.AddScoped<ISubsidyRepository, SubsidyRepository>();
            services.AddScoped<IActivityRepository, ActivityRepository>();
            services.AddScoped<ICarrierRemittanceRepository, CarrierRemittanceRepository>();
            services.AddScoped<IPaymentHistory, PaymentHistoryRepository>();
            services.AddScoped<IDependentRepository, DependentRepository>();
            services.AddScoped<IDependentDetailRepository, DependentDetailRepository>();
            services.AddScoped<IBillingDetailRepository, BillingRepository>();
            services.AddScoped<ICoverageRepository, CoverageRepository>();
            services.AddScoped<ISpecificFieldsRepository, SpecificFieldsRepository>();
            services.AddScoped<IParticipantRepository, ParticipantRepository>();
            services.AddScoped<IDocumentRepository, DocumentRepository>();
            services.AddScoped<IAffiliateRepository, AffiliateRepository>();
            services.AddScoped<IEmployeeClassRepository, EmployeeClassRepository>();
            services.AddScoped<IStateRepository, StateRepository>();
            services.AddScoped<IRelationRepository, RelationRepository>();
            services.AddScoped<ISurchargePercentRepository, SurchargePercentRepository>();
            services.AddScoped<IEligibilityEndRepository, EligibilityEndRepository>();
            services.AddScoped<ITransactionRepository, TransactionRepository>();
            services.AddScoped<IClientRepository, ClientRepository>();
            services.AddScoped<ICustomFieldDomainRepository, CustomFieldDomainRepository>();
            services.AddScoped<IAvailablePlanRepository, AvailablePlanRepository>();
            services.AddScoped<IGenericUniqueValueRepository, GenericUniqueValueRepository>();
            services.AddScoped<ICoverageAvailablePlanRepository, CoverageAvailablePlanRepository>();
            services.AddScoped<ISCCobraEligRepository, SCCobraEligRepository>();
            services.AddScoped<ICobraHipaaRepository, CobraHipaaRepository>();
            services.AddScoped<IParticipantDependentAddressRepository, ParticipantDependentAddressRepository>();
            services.AddScoped<IQEExtensionRepository, QEExtensionRepository>();
            services.AddScoped<IPlanBenefitRepository, PlanBenefitRepository>();
            services.AddScoped<ISubsidyDataRepository, SubsidyDataRepository>();
            services.AddScoped<IEmailQueueRepository, EmailQueueRepository>();
            services.AddScoped<IDocumentOptionRepository, DocumentOptionRepository>();
            services.AddScoped<IClientPlansRepository, ClientPlansRepository>();
            services.AddScoped<IDBPastDueRepository, DBPastDueRepository>();
            services.AddScoped<IDBImpendingMedicareReportRepository, DBImpendingMedicareReportRepository>();
            services.AddScoped<IGenericUniquePairValueRepository, GenericUniquePairValueRepository>();
            services.AddScoped<ICoverageErrorRepository, CoverageErrorRepository>();
            services.AddScoped<IMLRQuoteRateRepository, MLRQuoteRateRepository>();
            services.AddScoped<IGenericGuidValueRepository, GenericGuidValueRepository>();

            #endregion

            #region "Generals"

            services.AddScoped<ICobraConfig, CobraConfig>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            #endregion

        }
    }
}

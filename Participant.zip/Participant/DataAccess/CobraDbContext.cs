﻿using Core.Model;
using Microsoft.EntityFrameworkCore;
namespace DataAccess
{
    public class CobraDbContext : DbContext
    {
        public CobraDbContext(DbContextOptions<CobraDbContext> options)
        : base(options)
        {
            this.Database.SetCommandTimeout(TimeSpan.FromSeconds(180));
        }

        public DbSet<SearchResultModel> ParticipantSearch { get; set; } = null!;
        public DbSet<InfoResultModel> ParticipantInfoSearch { get; set; } = null!;
        public DbSet<PlanModel> PlanModel { get; set; } = null!;
        public DbSet<RemoveQEInfoModel> RemoveQEResult { get; set; } = null!;
        public DbSet<SystemSettingModel> SystemSettings { get; set; } = null!;
        public DbSet<EmailNotificationModel> EmailNotification { get; set; }
        public DbSet<RemoveQEDetail> RemoveQEDetail { get; set; } = null!;
        public DbSet<SubsidyResultModel> ParticipantISubsidy { get; set; } = null!;
        public DbSet<ActivityModel> ParticipantActivity { get; set; } = null!;
        public DbSet<CarrierRemittanceModel> CarrierRemittance { get; set; }
        public DbSet<PaymentHistoryModel> PaymenHistory { get; set; }
        public DbSet<DependentModel> ParticipantDependent { get; set; }
        public DbSet<DocumentResultModel> DocumentResult { get; set; }
        public DbSet<DependentDetailModel> ParticipantDependentDetail { get; set; }
        public DbSet<BillingModel> Billing { get; set; }
        public DbSet<CoverageModel> Coverage { get; set; }
        public DbSet<SpecificFieldsResultModel> ParticipantSpecificFields { get; set; }
        public DbSet<AffiliateModel> Affiliate { get; set; }
        public DbSet<ParticipantPromotedModel> ParticipantPromoted { get; set; }
        public DbSet<QeMetaDatas> QualifyingEventType { get; set; }
        public DbSet<EmployeeClassModel> EmployeeClass { get; set; }
        public DbSet<StateModel> State { get; set; }
        public DbSet<RelationModel> Relation { get; set; }
        public DbSet<Participant> Participant { get; set; }
        public DbSet<BankCheck> BankCheck { get; set; }
        public DbSet<CasesModel> Cases { get; set; }
        public DbSet<PaymentModel> Payment { get; set; }
        public DbSet<VoidCheckModel> VoidModel { get; set; }
        public DbSet<RehireValidatorResultModel> RehireValidator { get; set; }
        public DbSet<ClientOptionResultModel> ClientOptionResult { get; set; }
        public DbSet<DisabilityModel> Disability { get; set; }
        public DbSet<SurchargePercentModel> SurchargePercent { get; set; }
        public DbSet<EligibilityEndModel> EligibilityEnd { get; set; }
        public DbSet<ClientModel> Client { get; set; } = null!;
        public DbSet<CustomFieldDomain> CustomField { get; set; }
        public DbSet<ParticipantCoverageModel> ParticipantCoverage { get; set; }
        public DbSet<DocQueueModel> DocQueue { get; set; }
        public DbSet<GenericUniqueValue> UniqueValue { get; set; }
        public DbSet<AvailablePlansClientResult> AvailablePlansClient { get; set; }
        public DbSet<CoverageAvailablePlan> CoverageAvailablePlan { get; set; }
        public DbSet<QEPlanComponentModel> QEPlanComponent { get; set; }
        public DbSet<SCCobraEligViewModel> SccCobra { get; set; }
        public DbSet<CobraHipaaViewModel> CobraHipaa { get; set; }
        public DbSet<ParticipantDependentCoverageResultModel> ParticipantDependentCoverageResult { get; set; }
        public DbSet<ParticipantCoveragePlanOptionResultModel> ParticipantCoveragePlanOptionResult { get; set; }
        public DbSet<CurrentParticipantAddressModel> CurrentParticipantDependentAddress { get; set; }
        public DbSet<EligibilityTransmissionModel> EligibilityTransmission { get; set; }
        public DbSet<AdminFeeModel> AdminFeeModel { get; set; }
        public DbSet<CoverageCostResultModel> CoverageCostModel { get; set; }
        public DbSet<ParticipantInfoResultModel> ParticipantInfoResultModel { get; set; }
        public DbSet<QEExtensionModel> QEExtensionModel { get; set; }
        public DbSet<PlanBenefitTypeModel> PlanBenefitTypeModel { get; set; }
        public DbSet<SubsidyDataModel> SubsidyDataModel { get; set; }
        public DbSet<GroupUpdateModel> GroupUpdate { get; set; }
        public DbSet<GroupUpdateDataModel> GroupUpdateData { get; set; }
        public DbSet<GroupUpdateDataResultModel> GroupUpdateDataResult { get; set; }
        public DbSet<GroupUpdateDropDownListModel> GroupUpdateDropDownList { get; set; }
        public DbSet<EmailModel> EmailQueue { get; set; }
        public DbSet<DocumentOptionModel> DocumentOption { get; set; }
        public DbSet<ClientPlansModel> ClientPlans { get; set; }
        public DbSet<DBPastDueModel> dBPastDue { get; set; }
        public DbSet<DBImpendingMedicareReportModel> dBImpendingMedicareReport { get; set; }
        public DbSet<GenericUniquePairValue> dbGenericUniquePairValue { get; set; }
        public DbSet<CoverageErrorModel> CoverageErrorModel { get; set; }
        public DbSet<MLRQuoteGetRateModel> MLRQuoteGetRateModel { get; set; }
        public DbSet<MLRQuoteGetRateModel> MLRQuoteGetNewRateModel { get; set; }
        public DbSet<DependentResultModel> DependentResultModel { get; set; }
        public DbSet<CoveragePlansModel> CoveragePlansModel { get; set; }
        public DbSet<GenericGuidValue> GenericGuidValue { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Participant>().HasKey(table => new
            {
                table.ParticipantId
            });
            modelBuilder.Entity<BankCheck>().HasKey(table => new
            {
                table.CheckId
            });
            modelBuilder.Entity<CasesModel>().HasKey(table => new
            {
                table.CaseNumber
            });
            modelBuilder.Entity<PaymentModel>().HasKey(table => new
            {
                table.ParymentId
            });
            modelBuilder.Entity<ParticipantCoverageModel>().HasKey(table => new
            {
                table.ParticipantCoverageId
            });
            modelBuilder.Entity<DocQueueModel>().HasKey(table => new
            {
                table.DocId
            });
            modelBuilder.Entity<ActivityModel>().HasNoKey();
            modelBuilder.Entity<BillingModel>().HasNoKey();
            modelBuilder.Entity<CarrierRemittanceModel>().HasNoKey();
            modelBuilder.Entity<VoidCheckModel>().HasNoKey();
            modelBuilder.Entity<DisabilityModel>().HasNoKey();
            modelBuilder.Entity<SurchargePercentModel>().HasNoKey();
            modelBuilder.Entity<EligibilityEndModel>().HasNoKey();
            modelBuilder.Entity<CustomFieldDomain>().HasNoKey();
            modelBuilder.Entity<AvailablePlansClientResult>().HasNoKey();
            modelBuilder.Entity<QEPlanComponentModel>().HasNoKey();
            modelBuilder.Entity<EligibilityTransmissionModel>().HasNoKey();
            modelBuilder.Entity<AdminFeeModel>().HasNoKey();
            modelBuilder.Entity<CoverageCostResultModel>().HasNoKey();
            modelBuilder.Entity<ParticipantInfoResultModel>().HasNoKey();
            modelBuilder.Entity<GroupUpdateModel>().HasNoKey();
            modelBuilder.Entity<GroupUpdateDataModel>().HasNoKey();
            modelBuilder.Entity<GroupUpdateDataResultModel>().HasNoKey();
            modelBuilder.Entity<GroupUpdateDropDownListModel>().HasNoKey();
            modelBuilder.Entity<DBPastDueModel>().HasNoKey();
            modelBuilder.Entity<DBImpendingMedicareReportModel>().HasNoKey();
            modelBuilder.Entity<SubsidyResultModel>().HasNoKey();
            modelBuilder.Entity<CoveragePlansModel>().HasNoKey();
        }
    }
}
﻿using API.Controllers;
using Core;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantControllerSPTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private ISPService? _participantService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantSPController TestArrange(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<ISPService>();
            _participantService.Setup(p => p.GetSubsidybyPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            _participantService.Setup(c => c.CheckForBadRequestRemoveQE(It.IsAny<RemoveQEModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantSPController>>();
            var participantController = new ParticipantSPController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantSPController TestArrangeMocked(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<ISPService>();
            _participantService.Setup(p => p.GetBilling(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantSPController>>();
            var participantController = new ParticipantSPController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantSPController TestArrangeRemoveQE(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<ISPService>();
            _participantService.Setup(p => p.RemoveQE(It.IsAny<RemoveQEModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequestRemoveQE(It.IsAny<RemoveQEModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantSPController>>();
            var participantController = new ParticipantSPController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        [Fact]
        public async Task GetSubsidybyPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetSubsidybyPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetSubsidyByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetSubsidyByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetBilling_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetBilling_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Billing(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetBilling_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeMocked(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Billing(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetBilling_GivenResponseIsNull_ReturnsContentNotAvailable()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Billing(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task Billing_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Billing(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task SubsidyByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SubsidyByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetRemoveQE_GivenRemoveQEModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeRemoveQE(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new RemoveQEModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.RemoveQE(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetRemoveQE_GivenRemiveQEModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeRemoveQE(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISPService>().Object;
            var model = new RemoveQEModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.RemoveQE(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetRemoveQE_GivenRemiveQEModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeRemoveQE(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new RemoveQEModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.RemoveQE(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetRemoveQE_GivenRemiveQEModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeRemoveQE(httpResponse, new List<string>());
            _participantService = new Mock<ISPService>().Object;
            var model = new RemoveQEModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.RemoveQE(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetRemoveQE_GivenRemiveQEModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeRemoveQE(httpResponse, lstErrors);
            var model = new RemoveQEModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.RemoveQE(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
    }
}

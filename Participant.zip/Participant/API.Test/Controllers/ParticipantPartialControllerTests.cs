﻿using API.Controllers;

using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantPartialControllerTests
    {
        public static ParticipantPartialController TestArrangeGetSpecificFieldsById(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetSpecificFieldsByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestArrangeGetActivityByPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetActivityByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public ParticipantPartialController TestArrangeGetActivityFilteringByPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetActivityFilteringByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public ParticipantPartialController TestArrangeGetCoverageByPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetCoverageByPid(It.IsAny<ParticipantGetCoverageModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantGetCoverageModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestArrangeGetDependentByParentPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetDependentByParentPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestCarrierRemittanceByPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetCarrierRemittanceByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestPaymentHistoryByPid(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetPaymentHistoryByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestParticipantDependentAddress(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetParticipantDependentAddress(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<InfoModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestEligibilityTransmissionDetail(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetEligibilityTransmissionDetailByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantPartialController TestGetCoverageCost(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IPartialService>();
            _participantService.Setup(p => p.GetCoverageCost(It.IsAny<CoverageCostModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<CoverageCostModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantPartialController>>();
            var participantController = new ParticipantPartialController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetActivityByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestArrangeGetActivityByPid(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityFilteringByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityFilteringByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityActivityFilteringByPidByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityFilteringByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityActivityFilteringByPidByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityFilteringByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityActivityFilteringByPidByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityFilteringByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetActivityActivityFilteringByPidByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };

            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ActivityByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetCoverageByPid(httpResponse, new List<string>());
            var model = new ParticipantGetCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetCoverageByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantGetCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetCoverageByPid(httpResponse, new List<string>());
            var model = new ParticipantGetCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetCoverageByPid(httpResponse, new List<string>());
            var model = new ParticipantGetCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestArrangeGetCoverageByPid(httpResponse, lstErrors);
            var model = new ParticipantGetCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDependentByParentPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DependentByParentPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetDependentByParentPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DependentByParentPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDependentByParentPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DependentByParentPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDependentByParentPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DependentByParentPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetDependentByPPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestArrangeGetDependentByParentPid(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DependentByParentPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFeildsByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetSpecificFieldsById(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SpecificFieldsByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFeildsByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetSpecificFieldsById(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SpecificFieldsByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFeildsByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetSpecificFieldsById(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SpecificFieldsByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFeildsByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetSpecificFieldsById(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SpecificFieldsByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetSpecificFeildsByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestArrangeGetSpecificFieldsById(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SpecificFieldsByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestCarrierRemittanceByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CarrierRemittanceByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestCarrierRemittanceByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CarrierRemittanceByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestCarrierRemittanceByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CarrierRemittanceByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestCarrierRemittanceByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CarrierRemittanceByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetCarrierRemittanceByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestCarrierRemittanceByPid(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CarrierRemittanceByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestPaymentHistoryByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.PaymentHistoryByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestPaymentHistoryByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.PaymentHistoryByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestPaymentHistoryByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.PaymentHistoryByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestPaymentHistoryByPid(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.PaymentHistoryByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetPaymentHistoryByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestPaymentHistoryByPid(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.PaymentHistoryByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestParticipantDependentAddress(httpResponse, new List<string>());
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ParticipantDependentAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestParticipantDependentAddress(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ParticipantDependentAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestParticipantDependentAddress(httpResponse, new List<string>());
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ParticipantDependentAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestParticipantDependentAddress(httpResponse, new List<string>());
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ParticipantDependentAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetParticipantDependentAddress_GivenInfoModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestParticipantDependentAddress(httpResponse, lstErrors);
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ParticipantDependentAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestEligibilityTransmissionDetail(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestEligibilityTransmissionDetail(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
            var testArrange = TestEligibilityTransmissionDetail(httpResponse: null!, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetEligibilityTransmissionDetailByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestEligibilityTransmissionDetail(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEligibilityTransmissionDetailByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageCost_GivenCoverageCostModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestGetCoverageCost(httpResponse, new List<string>());
            var model = new CoverageCostModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetCoverageCost(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoverageCost_GivenCoverageCostModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestGetCoverageCost(httpResponse, lstErrors);
            var model = new CoverageCostModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetCoverageCost(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }


        [Fact]
        public async Task GetCoveragesPlans_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, new List<string>());
            var model = new ParticipantDependentCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
                ParticipantCoverageId= "6791521",
            };

            //act
            var result = await testArrange.CoveragesPlans(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoveragesPlans_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new ParticipantDependentCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
                ParticipantCoverageId = "67911",
            };

            //act
            var result = await testArrange.CoveragesPlans(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetCoveragesPlans_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetActivityFilteringByPid(httpResponse, new List<string>());
            var model = new ParticipantDependentCoverageModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
                ParticipantCoverageId = "67911",
            };
            //act
            var result = await testArrange.CoveragesPlans(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
    }
}
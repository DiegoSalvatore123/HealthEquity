﻿using API.Controllers;
using Core;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantCollectionControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private ICollectionService? _collectionService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantCollectionController TestArrangeGetStates(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _collectionService = new Mock<ICollectionService>();
            _collectionService.Setup(p => p.GetStates(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _collectionService.Setup(c => c.CheckForBadRequest(It.IsAny<InfoModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantCollectionController>>();
            var statesDdlController = new ParticipantCollectionController(_collectionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return statesDdlController;
        }
        public static ParticipantCollectionController TestArrangeGetEmployeeClasses(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _collectionService = new Mock<ICollectionService>();
            _collectionService.Setup(p => p.GetEmployeeClasses(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _collectionService.Setup(c => c.CheckForBadRequest(It.IsAny<InfoModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantCollectionController>>();
            var employeeClassesDdlController = new ParticipantCollectionController(_collectionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return employeeClassesDdlController;
        }
        public static ParticipantCollectionController TestArrangeGetDivisionLocations(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _collectionService = new Mock<ICollectionService>();
            _collectionService.Setup(p => p.GetDivisionLocations(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _collectionService.Setup(c => c.CheckForBadRequest(It.IsAny<InfoModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantCollectionController>>();
            var divisionLocationsDdlController = new ParticipantCollectionController(_collectionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return divisionLocationsDdlController;
        }
        public static ParticipantCollectionController TestArrangeGetQualifyingEventType(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _collectionService = new Mock<ICollectionService>();
            _collectionService.Setup(p => p.GetQualifyingEventType(It.IsAny<QualifyingEventTypeModel>())).ReturnsAsync(httpResponse);
            _collectionService.Setup(c => c.CheckForBadRequest(It.IsAny<QualifyingEventTypeModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantCollectionController>>();
            var qualifyingEventTypeController = new ParticipantCollectionController(_collectionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return qualifyingEventTypeController;
        }

        [Fact]
        public async Task GetStates_GivenModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetStates(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchState(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetStates_GivenModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetStates(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchState(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetStates_GivenModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetStates(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchState(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetStates_GivenModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetStates(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchState(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmployeeClasses_GivenModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetEmployeeClasses(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchEmployeeClass(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmployeeClasses_GivenModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetEmployeeClasses(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchEmployeeClass(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmployeeClasses_GivenModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetEmployeeClasses(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchEmployeeClass(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmployeeClasses_GivenModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetEmployeeClasses(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchEmployeeClass(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }

        [Fact]
        public async Task GetDivisionLocations_GivenModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDivisionLocations(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchDivision(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetDivisionLocations_GivenModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDivisionLocations(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchDivision(model) as ObjectResult;

            //assert
            Assert.Equal(500, result?.StatusCode);
        }
        [Fact]
        public async Task GetDivisionLocations_GivenModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetDivisionLocations(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchDivision(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetDivisionLocations_GivenModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetDivisionLocations(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchDivision(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetQualifyingEventType_GivenModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetQualifyingEventType(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new QualifyingEventTypeModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetQualifyingEventType(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetQualifyingEventType_GivenModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetQualifyingEventType(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new QualifyingEventTypeModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetQualifyingEventType(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetQualifyingEventType_GivenModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeGetQualifyingEventType(httpResponse, new List<string>());
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new QualifyingEventTypeModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetQualifyingEventType(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetQualifyingEventType_GivenModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeGetQualifyingEventType(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _collectionService = new Mock<ICollectionService>().Object;
            var model = new QualifyingEventTypeModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetQualifyingEventType(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
    }
}

﻿using API.Controllers;
using Core;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class DirectBillSPControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private IDirectBillSPService? _directBillSPService;
#pragma warning restore IDE0052 // Remove unread private members

        public static DirectBillSPController TestArrange(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _directBillSPService = new Mock<IDirectBillSPService>();
            _directBillSPService.Setup(p => p.GetImpendingMedicareReport(It.IsAny<PlatformModel>())).ReturnsAsync(httpResponse);
            _directBillSPService.Setup(c => c.CheckForClientBadRequest(It.IsAny<PlatformModel>())).Returns(listErrors);

            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<DirectBillSPController>>();
            var directBillController = new DirectBillSPController(_directBillSPService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return directBillController;
        }

        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _directBillSPService = new Mock<IDirectBillSPService>().Object;
            var model = new PlatformModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetImpendingMedicareReport(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _directBillSPService = new Mock<IDirectBillSPService>().Object;
            var model = new PlatformModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetImpendingMedicareReport(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _directBillSPService = new Mock<IDirectBillSPService>().Object;
            var model = new PlatformModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetImpendingMedicareReport(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _directBillSPService = new Mock<IDirectBillSPService>().Object;
            var model = new PlatformModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetImpendingMedicareReport(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetImpendingMedicareReport_GivenPlatformModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new PlatformModel()
            {
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetImpendingMedicareReport(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
    }
}

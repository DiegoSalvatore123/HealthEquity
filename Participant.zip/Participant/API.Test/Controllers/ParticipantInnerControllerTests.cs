﻿using API.Controllers;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantInnerControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private IInnerService? _participantService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantInnerController TestArrange(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<IInnerService>();
            _participantService.Setup(p => p.SearchPlanNameByPid(It.IsAny<ParticipantIdModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantIdModel>())).Returns(listErrors);
            _participantService.Setup(p => p.GetEmailQueue(It.IsAny<DocumentModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<DocumentModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantInnerController>>();
            var participantController = new ParticipantInnerController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<IInnerService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<IInnerService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<IInnerService>().Object;
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task SearchPlanNameByPid_GivenParticipantIdModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new ParticipantIdModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchPlanNameByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }


        [Fact]
        public async Task GetEmailQueue_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<IInnerService>().Object;
            var model = new DocumentModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEmailQueue(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmailQueue_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<IInnerService>().Object;
            var model = new DocumentModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEmailQueue(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmailQueue_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<IInnerService>().Object;
            var model = new DocumentModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEmailQueue(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmailQueue_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            var model = new DocumentModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEmailQueue(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetEmailQueue_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new DocumentModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetEmailQueue(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
    }
}

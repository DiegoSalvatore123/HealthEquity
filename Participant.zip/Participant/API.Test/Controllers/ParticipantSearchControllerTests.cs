﻿using API.Controllers;
using Core;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantSearchControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private ISearchService? _participantService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantSearchController TestArrange(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<ISearchService>();
            _participantService.Setup(p => p.SearchByPid(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(p => p.SearchInfoComponent(It.IsAny<InfoModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<InfoModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantSearchController>>();
            var participantController = new ParticipantSearchController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }

        public static ParticipantSearchController TestGetUpdateGroupData(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _participantService = new Mock<ISearchService>();
            _participantService.Setup(p => p.GetUpdateGroupData(It.IsAny<GroupUpdateSearchModel>())).ReturnsAsync(httpResponse);
            _participantService.Setup(c => c.CheckForBadRequest(It.IsAny<GroupUpdateSearchModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantSearchController>>();
            var participantController = new ParticipantSearchController(_participantService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }

        [Fact]
        public async Task SearchByPid_GivenParticipantInfoModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByPid_GivenParticipantInfoModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByPid_GivenParticipantInfoModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByPid_GivenParticipantInfoModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task SearchForUpdateByPid_GivenParticipantInfoModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByPid_GivenParticipantInfoModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchByPid(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task SearchInfoComponent_GivenParticipantInfoModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchInfoComponent(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchInfoComponent_GivenParticipantInfoModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchInfoComponent(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchInfoComponent_GivenParticipantInfoModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchInfoComponent(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task SearchInfoComponent_GivenParticipantInfoModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _participantService = new Mock<ISearchService>().Object;
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchInfoComponent(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task SearchInfoComponent_GivenParticipantInfoModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrange(httpResponse, lstErrors);
            var model = new InfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchInfoComponent(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetUpdateGroupData_GivenGroupUpdateDataModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestGetUpdateGroupData(httpResponse, new List<string>());
            var model = new GroupUpdateSearchModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetUpdateGroupData(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task GetUpdateGroupData_GivenGroupUpdateDataModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestGetUpdateGroupData(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            var model = new GroupUpdateSearchModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetUpdateGroupData(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task GetUpdateGroupData_GivenGroupUpdateDataModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestGetUpdateGroupData(httpResponse, new List<string>());
            var model = new GroupUpdateSearchModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetUpdateGroupData(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task GetUpdateGroupData_GivenGroupUpdateDataModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestGetUpdateGroupData(httpResponse, new List<string>());
            var model = new GroupUpdateSearchModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetUpdateGroupData(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task GetUpdateGroupData_GivenGroupUpdateDataModel_BadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new() { "There was an error in the Application. Try again." };

            var testArrange = TestGetUpdateGroupData(httpResponse, lstErrors);
            var model = new GroupUpdateSearchModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.GetUpdateGroupData(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
    }
}
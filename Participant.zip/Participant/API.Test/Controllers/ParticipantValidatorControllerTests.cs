﻿using API.Controllers;
using Core;
using Core.Interfaces;
using Core.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantValidatorControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private IValidatorService? _validatorService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantValidatorController TestArrange(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _validatorService = new Mock<IValidatorService>();
            _validatorService.Setup(p => p.SearchBySSNHireDate(It.IsAny<ValidateHireDataModel>())).ReturnsAsync(httpResponse);
            _validatorService.Setup(p => p.SearchClientOption(It.IsAny<ClientOptionModel>())).ReturnsAsync(httpResponse);
            _validatorService.Setup(c => c.CheckForBadRequest(It.IsAny<ValidateHireDataModel>())).Returns(listErrors);
            _validatorService.Setup(c => c.CheckForBadRequest(It.IsAny<ClientOptionModel>())).Returns(listErrors);
            _validatorService.Setup(c => c.CheckForBadRequest(It.IsAny<Object>())).Returns(listErrors);
            _validatorService.Setup(p => p.SearchClientOptionLookup(It.IsAny<ClientOptionModel>())).ReturnsAsync(httpResponse);
            _validatorService.Setup(c => c.CheckForBadRequestSCC(It.IsAny<SCCobraEligModel>())).Returns(listErrors);
            _validatorService.Setup(c => c.CheckForCLientBadRequest(It.IsAny<UserClientModel>())).Returns(listErrors);
            _validatorService.Setup(c => c.CheckForCLientQEBadRequest(It.IsAny<QeCodeExtensionModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantValidatorController>>();
            var participantController = new ParticipantValidatorController(_validatorService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        [Fact]
        public async Task SearchByHireDate_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ValidateHireDataModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchBySSNHireDate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchByHireDate_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ValidateHireDataModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchBySSNHireDate(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchClientOption_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ClientOptionModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchClientOption(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task SearchClientOption_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ClientOptionModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.SearchClientOption(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task SearchClientOptionLookup_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ClientOptionModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ClientOptionLookup(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }

        [Fact]
        public async Task SearchClientOptionLookup_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ClientOptionModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.ClientOptionLookup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }

        [Fact]
        public async Task IncludeSCCobraElig_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new SCCobraEligModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.IncludeSCCobraElig(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task IncludeSCCobraElig_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new SCCobraEligModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.IncludeSCCobraElig(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task CobraHipaaNotice_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new UserClientModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CobraHipaaNotice(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task CobraHipaaNotice_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new UserClientModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CobraHipaaNotice(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }

        [Fact]
        public async Task CoveragExisting_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrange(httpResponse, new List<string>());
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ParticipantInfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
                ParticipantId = "5596715",
            };

            //act
            var result = await testArrange.CoveragExisting(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task CoveragExisting_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrange(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _validatorService = new Mock<IValidatorService>().Object;
            var model = new ParticipantInfoModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
                ParticipantId = "5596715",
            };

            //act
            var result = await testArrange.CoveragExisting(model) as ObjectResult;
            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }

    
    }
}

﻿using API.Controllers;
using Core.Interfaces;
using Core.Model;
using log4net.Repository.Hierarchy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Security.Claims;

namespace API.Test.Controllers
{
    public class ParticipantTransactionControllerTests
    {
#pragma warning disable IDE0052 // Remove unread private members
        private ITransactionService? _transactionService;
#pragma warning restore IDE0052 // Remove unread private members
        public static ParticipantTransactionController TestArrangeInsert(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.Insert(It.IsAny<ParticipantInsertModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<ParticipantInsertModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeDisabilityUpdate(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.UpdateDisability(It.IsAny<DisabilityUpdateModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<DisabilityUpdateModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeInsertAddress(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.InsertAddress(It.IsAny<AddressModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<AddressModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeEmployerChangeUpdate(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.UpdateEmployerChange(It.IsAny<EmployerChangeUpdateModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<EmployerChangeUpdateModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeCoverageChangeUpdate(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.UpdateCoverageChange(It.IsAny<CoverageChangeAvailablePlansModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<CoverageChangeAvailablePlansModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeChangeUpdate(HttpResponseMessage httpResponse, List<string> listErrors)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.UpdateGroup(It.IsAny<UpdateModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForBadRequest(It.IsAny<UpdateModel>())).Returns(listErrors);
            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        public static ParticipantTransactionController TestArrangeVoid(HttpResponseMessage httpResponse, Task<OperationResultModel?> ResultDescription)
        {
            var _transactionService = new Mock<ITransactionService>();
            _transactionService.Setup(p => p.VoidParticipant(It.IsAny<VoidModel>())).ReturnsAsync(httpResponse);
            _transactionService.Setup(c => c.CheckForOpenCases(It.IsAny<int>(), It.IsAny<string>())).Returns(ResultDescription);
            _transactionService.Setup(c => c.CheckForPayment(It.IsAny<int>(), It.IsAny<string>())).Returns(ResultDescription);
            _transactionService.Setup(c => c.CheckForBankCheck(It.IsAny<int>(), It.IsAny<string>())).Returns(ResultDescription);
            _transactionService.Setup(c => c.CheckForParticipantNotFound(It.IsAny<VoidModel>())).Returns(ResultDescription);

            var claims = new List<Claim>
            {
                new Claim("sid", "CXO"),
                new Claim("cid", "1"),
                new Claim("CXO", "1"),
            };
            var identity = new ClaimsIdentity(claims, "TestAuthentication");
            var user = new ClaimsPrincipal(identity);
            var _logger = new Mock<ILogger<ParticipantTransactionController>>();
            var participantController = new ParticipantTransactionController(_transactionService.Object, _logger.Object)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext { User = user }
                }
            };
            return participantController;
        }
        [Fact]
        public async Task DisabilityUpdate_GivenDisabilityUpdateModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeDisabilityUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new DisabilityUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DisabilityUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task DisabilityUpdate_GivenDisabilityUpdateModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeDisabilityUpdate(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new DisabilityUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DisabilityUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task DisabilityUpdate_GivenDisabilityUpdateModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeDisabilityUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new DisabilityUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DisabilityUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task DisabilityUpdate_GivenDisabilityUpdateModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeDisabilityUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new DisabilityUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DisabilityUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task DisabilityUpdate_GivenDisabilityUpdateModelWithError_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeDisabilityUpdate(httpResponse, lstErrors);
            var model = new DisabilityUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.DisabilityUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task InsertAddress_GivenAddressModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsertAddress(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new AddressModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.InsertAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task InsertAddress_GivenAddressModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeInsertAddress(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new AddressModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.InsertAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task InsertAddress_GivenAddressModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsertAddress(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new AddressModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.InsertAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task InsertAddress_GivenAddressModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsertAddress(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new AddressModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.InsertAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task InsertAddress_GivenAddressModelWithError_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeInsertAddress(httpResponse, lstErrors);
            var model = new AddressModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.InsertAddress(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task EmployerChangeUpdate_GivenEmployerChangeUpdateModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeEmployerChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new EmployerChangeUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.EmployerChangeUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task EmployerChangeUpdate_GivenEmployerChangeUpdateModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeEmployerChangeUpdate(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new EmployerChangeUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.EmployerChangeUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task EmployerChangeUpdate_GivenEmployerChangeyUpdateModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeEmployerChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new EmployerChangeUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.EmployerChangeUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task EmployerChangeUpdate_GivenEmployerChangeUpdateModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeEmployerChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new EmployerChangeUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.EmployerChangeUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task EmployerChangeUpdate_GivenEmployerChangeUpdateModelWithError_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeEmployerChangeUpdate(httpResponse, lstErrors);
            var model = new EmployerChangeUpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.EmployerChangeUpdate(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task Insert_GivenInfoHireModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsert(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new ParticipantInsertModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Insert(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task Insert_GivenInfoHireModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeInsert(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new ParticipantInsertModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Insert(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task Insert_GivenInfoHireModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsert(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new ParticipantInsertModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Insert(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task Insert_GivenInfoHireModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeInsert(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new ParticipantInsertModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Insert(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task Insert_GivenInfoHireModelWithError_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeInsert(httpResponse, lstErrors);
            var model = new ParticipantInsertModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.Insert(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task CoverageChangeUpdate_GivenCoverageChangeUpdateModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeCoverageChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new CoverageChangeAvailablePlansModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageChange(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task CoverageChangeUpdate_GivenCoverageChangeUpdateModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeCoverageChangeUpdate(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new CoverageChangeAvailablePlansModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageChange(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task CoverageChangeUpdate_GivenCoverageChangeyUpdateModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeCoverageChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new CoverageChangeAvailablePlansModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageChange(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task CoverageChangeUpdate_GivenCoverageChangeUpdateModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeCoverageChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new CoverageChangeAvailablePlansModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.CoverageChange(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task ChangeUpdate_GivenUpdateModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new UpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateGroup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task ChangeUpdate_GivenUpdateModel_ReturnsNoContent()
        {
            //arrange
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeChangeUpdate(httpResponse: null, new List<string>());
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new UpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateGroup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task ChangeUpdate_GivenUpdateModel_ReturnsBadRequest()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new UpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateGroup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        [Fact]
        public async Task ChangeUpdate_GivenUpdateModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            var testArrange = TestArrangeChangeUpdate(httpResponse, new List<string>());
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new UpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateGroup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }
        [Fact]
        public async Task ChangeUpdate_GivenUpdateModelWithError_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.BadRequest) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            List<string> lstErrors = new()
            {
                "There was an error in the Application. Try again."
            };
            var testArrange = TestArrangeChangeUpdate(httpResponse, lstErrors);
            var model = new UpdateModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.UpdateGroup(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status400BadRequest, result?.StatusCode);
        }
        //        #region Void Participant

        [Fact]
        public async Task VoidParticipant_GivenVoidModel_ReturnsOK()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            OperationResultModel? OperationResultModel = null;
            var testArrange = TestArrangeVoid(httpResponse, Task.Run(() => OperationResultModel));
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new VoidModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.VoidParticipant(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status200OK, result?.StatusCode);
        }
        [Fact]
        public async Task VoidParticipant_GivenVoidModel_ReturnsNoContent()
        {
            //arrange
            OperationResultModel? OperationResultModel = null;
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
            var testArrange = TestArrangeVoid(httpResponse: null, Task.Run(() => OperationResultModel));
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new VoidModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.VoidParticipant(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status204NoContent, result?.StatusCode);
        }
        [Fact]
        public async Task VoidParticipant_GivenVoidModel_ReturnsNotFound()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.NotFound) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            OperationResultModel? OperationResultModel = null;
            var testArrange = TestArrangeVoid(httpResponse, Task.Run(() => OperationResultModel));
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new VoidModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.VoidParticipant(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status404NotFound, result?.StatusCode);
        }
        [Fact]
        public async Task VoidParticipant_GivenVoidModel_ReturnsInternalServerError()
        {
            //arrange
            var httpResponse = new HttpResponseMessage(HttpStatusCode.InternalServerError) { Content = new StringContent("{}", System.Text.Encoding.UTF8, "application/json") };
            OperationResultModel? OperationResultModel = null;
            var testArrange = TestArrangeVoid(httpResponse, Task.Run(() => OperationResultModel));
            _transactionService = new Mock<ITransactionService>().Object;
            var model = new VoidModel()
            {
                ClientId = "1",
                PlatformName = "CXO",
                UserId = "1",
            };

            //act
            var result = await testArrange.VoidParticipant(model) as ObjectResult;

            //assert
            Assert.Equal(StatusCodes.Status500InternalServerError, result?.StatusCode);
        }

    }
}
